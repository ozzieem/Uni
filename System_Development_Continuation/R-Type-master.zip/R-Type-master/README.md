# R-Type

A remake of the famous game R-Type. It is coded using the Entity-Component-System pattern, can be played up to 4 players through network and is cross-platform Linux/Windows.
