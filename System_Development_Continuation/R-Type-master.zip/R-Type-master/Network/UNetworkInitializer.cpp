#ifdef __linux__

# include "NetworkInitializer.hh"

NetworkInitializer::NetworkInitializer()
{
}

NetworkInitializer::~NetworkInitializer()
{
}

#endif