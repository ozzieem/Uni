///<reference path="../definitions/phaser.d.ts"/>

class HUD {
    private game:Phaser.Game;
    public sprite:Phaser.Sprite;
    public minimap:Phaser.Sprite;
    public skillbar:Phaser.Sprite;
    public healthbar:Phaser.Sprite;
    public healthbarBackground:Phaser.Sprite;
    public inventory:Phaser.Sprite;

    labelMinimap:any;
    displayActionText:any;

    public constructor(game:Phaser.Game) {

        this.game = game;
        this.create();

    }

    open = false;
    private listener() {
        if (!this.open) {
            console.log("Inventory open");
            this.displayActionText.alpha = 0;
            this.game.add.tween(this.displayActionText).to( { alpha: 1 }, 1000, Phaser.Easing.Linear.None, true, 0, 0, false);
            this.displayActionText.text = "Inventory open";
            this.inventory.visible = true;
            this.open = true;
        }
        else {
            console.log("Inventory closed");
            this.displayActionText.text = "Inventory closed";
            this.game.add.tween(this.displayActionText).to( { alpha: 0 }, 1000, Phaser.Easing.Linear.None, true, 0, 0, false);
            this.inventory.visible = false;
            this.open = false;
        }
    }

    public preload() {
    }

    public create() {
        var style = {font: "35px Calibri", fill: "#ffffff", wordWrap: true, align: "center"};

        this.CreateTestHUD();
        this.CreateMinimap(style);
        this.CreateSkillbar(style);
        this.CreateInventory();
    }

    private CreateTestHUD() {
        this.sprite = this.game.add.sprite(0, 0, 'testHUD', 0);
        this.sprite.height = this.game.height;
        this.sprite.width = this.game.width;
        this.sprite.fixedToCamera = true; //keep anchored to screen when camera moves
        this.sprite.visible = false;
    }

    private CreateInventory() {
        this.inventory = this.game.add.sprite(0, 0, 'testBag', 0);
        this.inventory.fixedToCamera = true;
        this.inventory.inputEnabled = true;
        this.inventory.input.enableDrag();
        this.inventory.visible = false;
    }

    private CreateSkillbar(style:{font:string; fill:string; wordWrap:boolean; align:string}) {
        this.skillbar = this.game.add.sprite(0, 0, 'testSkillbar', 0);
        this.skillbar.x = this.game.width / 5;
        this.skillbar.y = this.game.height - this.game.height / 5;
        this.skillbar.fixedToCamera = true;
        this.skillbar.inputEnabled = true;
        this.skillbar.input.enableDrag();
        this.skillbar.visible = true;
        this.displayActionText = this.game.add.text(this.skillbar.width, 0, '', style);
        this.skillbar.addChild(this.displayActionText);
        this.skillbar.events.onInputDown.add(this.listener, this);
    }

    private CreateMinimap(style:{font:string; fill:string; wordWrap:boolean; align:string}) {
        this.minimap = this.game.add.sprite(0, 0, 'testMinimap', 0);
        this.minimap.scale.setTo(0.5, 0.5);
        this.minimap.x = this.game.width - this.game.width / 4;
        this.minimap.fixedToCamera = true;
        this.minimap.inputEnabled = true;
        this.minimap.input.enableDrag();
        this.minimap.visible = true;
        this.labelMinimap = this.game.add.text(this.minimap.x - this.minimap.width * 2, this.minimap.y, "Minimap", style);
        this.minimap.addChild(this.labelMinimap);
    }

    public update() {
    }

    public render() {
        this.game.debug.body(this.sprite);
    }
}
/**
 * Created by Oz on 15/04/2016.
 */
