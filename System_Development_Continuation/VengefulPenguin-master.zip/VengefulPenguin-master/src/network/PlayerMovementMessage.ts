/// <reference path = "../ecs/components/PlayerControlComponent.ts"/>

class PlayerMovementMessage {
    public id:string;
    public playerControlComponent:PlayerControlComponent;

    constructor(playerControlComponent:PlayerControlComponent) {
        this.playerControlComponent = playerControlComponent;
    }
}