export class PlayerData {
    constructor(public id:string, public name:string, public team:number = -1, public ready: boolean) {}
}