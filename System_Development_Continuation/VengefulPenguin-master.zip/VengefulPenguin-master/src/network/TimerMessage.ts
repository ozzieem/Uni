export class TimerMessage {
    constructor(public startMinute: number, public startSecond: number) {}
}
