///<reference path="PlayerPositionMessage.ts"/>
class AttackMessage{
    public cursor: Phaser.Plugin.Isometric.Point3;
    public syncMsg: PlayerPositionMessage;
    constructor(cursor: Phaser.Plugin.Isometric.Point3, x, y, z, lookDir, timeStamp){
        this.cursor = cursor;
        this.syncMsg = new PlayerPositionMessage(x, y, z, lookDir, timeStamp);
    }
}