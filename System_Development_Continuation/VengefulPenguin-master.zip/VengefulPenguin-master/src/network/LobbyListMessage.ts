import {LobbyData} from "./LobbyData";
export class LobbyListMessage {
    public list:LobbyData[] = [];

    add(id:number, name:string, size:number, nrPlayers:number, state:any) {
        this.list.push(new LobbyData(id, name, size, nrPlayers, state));
    }
}
