///<reference path="../ScoreKeeper.ts"/>
import {ScoreKeeper} from "../ScoreKeeper";
export class ScoreMessage{
    scoreKeeper: ScoreKeeper;
    constructor(scoreKeeper: ScoreKeeper){
        this.scoreKeeper = scoreKeeper;
    }
}