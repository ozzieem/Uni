class DeathMessage {
    public killedBy: string;

    constructor(killedBy:string){
        this.killedBy = killedBy;
    }
}