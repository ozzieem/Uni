export class LobbyData {
    constructor(public id:number, public name:string, public size:number, public nrPlayers, public state = 0) {}
}
