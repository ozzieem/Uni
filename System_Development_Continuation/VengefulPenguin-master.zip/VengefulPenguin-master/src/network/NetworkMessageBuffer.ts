///<reference path="PlayerMovementMessage.ts"/>

class NetworkMessageBuffer {
    public messages:{[socketID:string]:any[]};

    constructor() {
        this.messages = {};
    }

    public onReceivedMessage(socketID:number, message:any) {
        if (!(socketID in this.messages)) {
            this.messages[socketID] = [];
        }
        this.messages[socketID].push(message);
    }

}