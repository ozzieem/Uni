///<reference path="../ecs/components/PositionComponent.ts"/>
///<reference path="../ecs/components/SpriteComponent.ts"/>

class PlayerPositionMessage{
    constructor(public x: number, public y:number, public z:number, public lookDir:number, public timeStamp:number) {
    }
}