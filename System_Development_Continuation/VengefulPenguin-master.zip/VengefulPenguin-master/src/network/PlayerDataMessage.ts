import {PlayerData} from "./PlayerData";
export class PlayerDataMessage {
    public list: PlayerData[] = [];

    add(playerID: string, playerName: string, team:number=-1, ready=false) {
        this.list.push(new PlayerData(playerID, playerName, team, ready));
    }
}
