///<reference path="../base/System.ts"/>
///<reference path="../base/EcsWorld.ts"/>
///<reference path="../../states/Play.ts"/>
///<reference path="../../client/app.ts"/>
///<reference path="../../network/PlayerMovementMessage.ts"/>

class RemotePlayerInputSystem extends System {
    
    syncBuffer:NetworkMessageBuffer;
    attackBuffer:NetworkMessageBuffer;
    itemSwitchBuffer:NetworkMessageBuffer;
    lastSyncNr: {[socketID: string]: number};

    constructor(state:Phaser.State, game:Phaser.Game, world:EcsWorld) {
        super(state, game, world)
        this.registerComponent(this.getComponent(NetworkPlayerComponent));
        this.registerComponent(this.getComponent(PlayerControlComponent));
        this.registerComponent(this.getComponent(SpriteComponent));
        this.syncBuffer = (<Play>this.state).syncBuffer;
        this.attackBuffer = (<Play>this.state).attackBuffer;
        this.itemSwitchBuffer = (<Play>this.state).itemSwitchBuffer;
        this.lastSyncNr = {};
    }

    public inOctant(angle: number, octant: number): boolean{
        if (angle < 0)
            angle += 2 * Math.PI;
        if (octant == 0)
            if (angle > (2 * Math.PI - Math.PI / 8) && angle < (Math.PI / 8))
                return true;
        if (angle > (octant - Math.PI / 8) && angle < (octant + Math.PI / 8))
            return true;
        return false;
    }

    public process(entity:Entity, elapsed:number) {
        var network:NetworkPlayerComponent = <NetworkPlayerComponent>
            entity.get(this.getComponent(NetworkPlayerComponent));
        var control:PlayerControlComponent = <PlayerControlComponent>
            entity.get(this.getComponent(PlayerControlComponent));
        var sprite:SpriteComponent = <SpriteComponent> entity.get(this.getComponent(SpriteComponent));

        if (typeof this.attackBuffer.messages[network.socketId] !== 'undefined') {
            var message = this.attackBuffer.messages[network.socketId].shift();
            if (message) {
                control.isFiring = true;
                control.cursor = message.cursor;
                var dx = control.cursor.x - sprite.sprite.isoX;
                var dy = control.cursor.y - sprite.sprite.isoY;
                var angle = Math.atan2(dy, dx);
                control.angleOfPointer = angle;
                this.syncBuffer.messages[network.socketId].push(message.syncMsg);
            }
            else {
                control.isFiring = false;
            }
        }

        if (!(network.socketId in this.lastSyncNr)) {
            this.lastSyncNr[network.socketId] = 0;
        }
        network.currPosX = sprite.sprite.isoX;
        network.currPosY = sprite.sprite.isoY;
        if (typeof this.syncBuffer.messages[network.socketId] !== 'undefined') {
            var message: PlayerPositionMessage = this.syncBuffer.messages[network.socketId].pop();
            while (this.syncBuffer.messages[network.socketId].length > 0) {
                message = this.syncBuffer.messages[network.socketId].shift();
            }

            if (message) {
                this.lastSyncNr[network.socketId] = message.timeStamp;

                if (message.x) {
                    network.prevPosX = network.prevSyncX;
                    network.prevPosY = network.prevSyncY;
                    network.prevSyncX = message.x;
                    network.prevSyncY = message.y;
                    network.currPosX = message.x;
                    network.currPosY = message.y;
                    sprite.sprite.body.x = message.x;
                    sprite.sprite.body.y = message.y;
                    control.lookDirection = message.lookDir;

                    if (network.prevPosX && network.prevPosY) {
                        var deltaX = network.currPosX - network.prevPosX;
                        var deltaY = network.currPosY - network.prevPosY;
                        var angle = Math.atan2(deltaY, deltaX);
                        if (this.inOctant(angle, Math.PI)) {
                            control.movementState = MovementState.NW;
                        }
                        else if (this.inOctant(angle, Math.PI / 2)) {
                            control.movementState = MovementState.SW;
                        }
                        else if (this.inOctant(angle, 0)) {
                            control.movementState = MovementState.SE;
                        }
                        else if (this.inOctant(angle, 3 * Math.PI / 2)) {
                            control.movementState = MovementState.NE;
                        }
                        else if (this.inOctant(angle, 7 * Math.PI / 4)) {
                            control.movementState = MovementState.E;
                        }
                        else if (this.inOctant(angle, 2 * Math.PI / 3)) {
                            control.movementState = MovementState.W;
                        }
                        else if (this.inOctant(angle, Math.PI / 4)) {
                            control.movementState = MovementState.S;
                        }
                        else if (this.inOctant(angle, 5 * Math.PI / 4)) {
                            control.movementState = MovementState.N;
                        }
                        else {
                            control.movementState = MovementState.NONE;
                        }
                    }
                }
                if (network.prevSyncX == network.prevPosX && network.prevSyncY == network.prevPosY) {
                    control.movementState = MovementState.NONE;
                }
            }
        }

        if(typeof this.itemSwitchBuffer.messages[network.socketId] !== 'undefined')
        {
            var remoteItemSlot = this.itemSwitchBuffer.messages[network.socketId].shift();
            if(remoteItemSlot !== undefined)
            {
                control.itemSlot = remoteItemSlot;
            }
            else
            {
                control.itemSlot = ItemSlot.NONE;
            }
        }
        
        network.prevPosX = network.currPosX;
        network.prevPosY = network.currPosY;
    }
}