///<reference path="../base/System.ts"/>
///<reference path="../base/EcsWorld.ts"/>
///<reference path="../components/SpriteComponent.ts"/>
///<reference path="../components/VelocityComponent.ts"/>
/**
 * Created by marti on 2016-05-16.
 */
class PlayerPhysicsSystem extends System {

    constructor(state:Phaser.State, game:Phaser.Game, world:EcsWorld) {
        super(state, game, world)
        this.registerComponent(this.getComponent(SpriteComponent));
        this.registerComponent(this.getComponent(VelocityComponent));
    }

    public process(entity:Entity, elapsed:number) {
        var spriteComp:SpriteComponent =
            <SpriteComponent> entity.get(this.getComponent(SpriteComponent));
        var velocity:VelocityComponent = <VelocityComponent> entity.get(this.getComponent(VelocityComponent));
        spriteComp.sprite.body.velocity.x = velocity.x;
        spriteComp.sprite.body.velocity.y = velocity.y;
    }


}
