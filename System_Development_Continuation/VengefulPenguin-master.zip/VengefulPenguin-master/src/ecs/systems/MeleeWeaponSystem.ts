///<reference path="../base/System.ts"/>
///<reference path="../base/EcsWorld.ts"/>
///<reference path="../components/PositionComponent.ts"/>
///<reference path="../components/DisplayComponent.ts"/>
///<reference path="../components/VelocityComponent.ts"/>
///<reference path="../components/MeleeWeaponComponent.ts"/>
///<reference path="ShadowSystem.ts"/>
///<reference path="../components/SoundComponent.ts"/>

class MeleeWeaponSystem extends System {

    private items: any;
    constructor(state:Phaser.State, game:Phaser.Game, world:EcsWorld) {
        super(state, game, world)
        this.registerComponent(this.getComponent(MeleeWeaponComponent));
        this.registerComponent(this.getComponent(VelocityComponent));
        this.registerComponent(this.getComponent(SpriteComponent));
        this.registerComponent(this.getComponent(InventoryComponent));

        this.items = this.game.cache.getJSON('items');
    }

    public process(entity:Entity, elapsed:number) {
        var spriteComponent:SpriteComponent = <SpriteComponent> entity.get(this.getComponent(SpriteComponent));
        var playerControl:PlayerControlComponent = <PlayerControlComponent> entity.get(this.getComponent(PlayerControlComponent));
        var inventory:InventoryComponent = <InventoryComponent> entity.get(this.getComponent(InventoryComponent));
        var networkPlayer:NetworkPlayerComponent = <NetworkPlayerComponent> entity.get(this.getComponent(NetworkPlayerComponent));

        playerControl.hasFired = false;
        if (!playerControl.isFiring) {
            return;
        }

        if(inventory.cooldownDict[inventory.activeItem] !== undefined && !networkPlayer) {
            return;
        }

        inventory.cooldownDict[inventory.activeItem] = this.game.time.now;

        // Aim towards pointer
        playerControl.hasFired = true;
        var offset = this.items[inventory.activeItem].range;
        var dx = playerControl.cursor.x - spriteComponent.sprite.isoX;
        var dy = playerControl.cursor.y - spriteComponent.sprite.isoY;

        var angles = [];
        angles.push(Math.atan2(dy, dx));
        angles.push(angles[0] - Math.PI/5);
        angles.push(angles[0] + Math.PI/5);
        var velocity = new VelocityComponent(0, 0);

        if (this.game.state.getCurrentState().key == 'Play') {
            for (var i = 0; i < angles.length; i++) {
                this.world.prefab.createSwordHit(spriteComponent.sprite.isoX + Math.cos(angles[i]) * offset, spriteComponent.sprite.isoY + Math.sin(angles[i]) * offset,
                    spriteComponent.sprite.isoZ, this.game.state.getCurrentState().objectGroup, velocity,
                    entity, this.items[inventory.activeItem].lifespan, this.items[inventory.activeItem].damage);
            }
        }

        var soundComponent:SoundComponent = <SoundComponent> entity.get(this.getComponent(SoundComponent));
        if (soundComponent) {
            soundComponent.addSound('swordSwing', spriteComponent.sprite.position);
        }
    }
}