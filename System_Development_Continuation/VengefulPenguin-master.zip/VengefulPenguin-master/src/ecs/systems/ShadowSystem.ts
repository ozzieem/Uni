///<reference path="../base/System.ts"/>
///<reference path="../base/EcsWorld.ts"/>
///<reference path="../components/SpriteComponent.ts"/>
///<reference path="../components/ShadowComponent.ts"/>
import Point = Phaser.Point;
/**
 * Created by marti on 2016-05-16.
 */
class ShadowSystem extends System {
    private sprites : Phaser.Plugin.Isometric.IsoSprite[];

    constructor(state:Phaser.State, game:Phaser.Game, world:EcsWorld) {
        super(state, game, world)
        this.registerComponent(this.getComponent(SpriteComponent));
        this.registerComponent(this.getComponent(ShadowComponent));
        this.sprites = [];
    }

    public onAdded(entity:Entity) {
        var shadowComp:ShadowComponent = <ShadowComponent> entity.get(this.getComponent(ShadowComponent));
        this.sprites[entity.id] = shadowComp.sprite;
    }

    public onRemoved(entity:Entity) {
        this.sprites[entity.id].destroy();
        this.sprites[entity.id] = undefined;
    }

    public process(entity:Entity, elapsed:number) {
        var spriteComp:SpriteComponent =
            <SpriteComponent> entity.get(this.getComponent(SpriteComponent));
        var shadowComp:ShadowComponent = <ShadowComponent> entity.get(this.getComponent(ShadowComponent));
        
        // Shadow should be projected straight under the rock body
        shadowComp.sprite.isoX = spriteComp.sprite.isoX;
        shadowComp.sprite.isoY = spriteComp.sprite.isoY;
        
        // Add scaling depending on spriteComp.sprite.body.isoZ here
        shadowComp.sprite.scale.set(0.25 + spriteComp.sprite.isoZ/100,0.25 + spriteComp.sprite.isoZ/100);
    }



}