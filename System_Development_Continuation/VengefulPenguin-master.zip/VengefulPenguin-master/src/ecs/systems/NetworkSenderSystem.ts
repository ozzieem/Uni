///<reference path="../base/System.ts"/>
///<reference path="../base/EcsWorld.ts"/>
///<reference path="../../client/app.ts"/>
///<reference path="../../network/PlayerMovementMessage.ts"/>
///<reference path="../../network/PlayerPositionMessage.ts"/>
///<reference path="../../network/AttackMessage.ts"/>
///<reference path="../components/LifeStatusComponent.ts"/>
///<reference path="../../network/DeathMessage.ts"/>

class NetworkSenderSystem extends System {
    private counter = 0;

    constructor(state:Phaser.State, game:Phaser.Game, world:EcsWorld) {
        super(state, game, world);
        this.registerComponent(this.getComponent(PlayerControlComponent));
        this.registerComponent(this.getComponent(InputComponent));
        this.registerComponent(this.getComponent(SpriteComponent));
    }

    public process(entity:Entity, elapsed:number) {
        var playerControl:PlayerControlComponent = <PlayerControlComponent>
            entity.get(this.getComponent(PlayerControlComponent));
        
        if (playerControl.hasFired) {
            var sprite:SpriteComponent = <SpriteComponent> entity.get(this.getComponent(SpriteComponent));
            var x = sprite.sprite.isoX;
            var y = sprite.sprite.isoY;
            var z = sprite.sprite.isoZ;
            window.vengefulPenguin.socket.socket.emit('attack', new AttackMessage(playerControl.cursor,
                x, y, z, playerControl.lookDirection, this.counter));
            playerControl.hasFired = false;
        }
        
        else if (this.counter % 3 == 0) {
            var sprite:SpriteComponent = <SpriteComponent> entity.get(this.getComponent(SpriteComponent));
            var x = sprite.sprite.isoX;
            var y = sprite.sprite.isoY;
            var z = sprite.sprite.isoZ;
            window.vengefulPenguin.socket.socket.emit('syncPosition', new PlayerPositionMessage(x, y, z,
                playerControl.lookDirection, this.counter));
        }

        if (playerControl.itemSlot !== ItemSlot.NONE && playerControl.hasSwitchedItem) {
            window.vengefulPenguin.socket.socket.emit('itemSwitch', playerControl.itemSlot);
        }

        var lifeStatus:LifeStatusComponent = <LifeStatusComponent> entity.get(this.getComponent(LifeStatusComponent));
        if (lifeStatus.justDied) {
            window.vengefulPenguin.socket.socket.emit('iDied', new DeathMessage(lifeStatus.killedBy));
            lifeStatus.justDied = false;
        }

        if (lifeStatus.justSpawned) {
            window.vengefulPenguin.socket.socket.emit('iSpawned');
            lifeStatus.justSpawned = false;
        }
        this.counter++;
    }
}