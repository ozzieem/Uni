///<reference path="../base/System.ts"/>
///<reference path="../base/EcsWorld.ts"/>
///<reference path="../components/ItemAnimationComponent.ts"/>
///<reference path="../components/ItemSpriteComponent.ts"/>
///<reference path="../components/PlayerControlComponent.ts"/>
///<reference path="../components/PositionComponent.ts"/>
///<reference path="../components/InventoryComponent.ts"/>


class ItemAnimationSystem extends System {
    animations:Phaser.Animation[];

    constructor(state:Phaser.State, game:Phaser.Game, world:EcsWorld) {
        super(state, game, world)
        this.registerComponent(this.getComponent(ItemAnimationComponent));
        this.registerComponent(this.getComponent(ItemSpriteComponent));
        this.registerComponent(this.getComponent(PlayerControlComponent));
        this.registerComponent(this.getComponent(SpriteComponent));
        this.registerComponent(this.getComponent(InventoryComponent));
    }

    public onAdded(entity:Entity) {
        var itemAnimation:ItemAnimationComponent = <ItemAnimationComponent> entity.get(this.getComponent(ItemAnimationComponent));
        var itemSpriteComponent:ItemSpriteComponent = <ItemSpriteComponent> entity.get(this.getComponent(ItemSpriteComponent));

        itemAnimation.animations['MELEE-SWING'] = {speed: 200, frames: [0 ,1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]};
        itemAnimation.animations['RANGED-SHOOT'] = {speed: 120, frames: [0, 2, 4, 6, 8, 10, 12, 14,
        16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 39] };

        for (var key in itemAnimation.animations) {
            var value = itemAnimation.animations[key];
            var sort = key.split('-');
            if(sort[0] == 'MELEE'){
                itemSpriteComponent.sprite[0].animations.add(key, value.frames, value.speed);
                //itemSpriteComponent.sprite[0].alpha = 0.5;
            }
            else {
                itemSpriteComponent.sprite[1].animations.add(key, value.frames, value.speed);
            }
        }
    }

    public process(entity:Entity, elapsed:number){
        var itemSpriteComponent:ItemSpriteComponent = <ItemSpriteComponent> entity.get(this.getComponent(ItemSpriteComponent));
        var playerControlComponent:PlayerControlComponent = <PlayerControlComponent> entity.get(this.getComponent(PlayerControlComponent));
        var spriteComponent:SpriteComponent = <SpriteComponent> entity.get(this.getComponent(SpriteComponent));
        var inventoryComponent:InventoryComponent = <InventoryComponent> entity.get(this.getComponent(InventoryComponent));

        this.changeAngleByLookDirection(itemSpriteComponent.sprite[0], playerControlComponent);

        if (playerControlComponent.hasFired && inventoryComponent.activeItem == "sword") {
            itemSpriteComponent.sprite[0].visible = true;
            itemSpriteComponent.sprite[0].isoPosition.setTo(spriteComponent.sprite.isoX, spriteComponent.sprite.isoY, spriteComponent.sprite.isoZ);
            itemSpriteComponent.sprite[0].animations.play('MELEE-SWING');
            itemSpriteComponent.sprite[0].animations.currentAnim.onComplete.add(function(){itemSpriteComponent.sprite[0].visible = false;});
        }
        else if (playerControlComponent.hasFired && inventoryComponent.activeItem == "rock") {
            itemSpriteComponent.sprite[1].visible = true;
            // Semi hard coded smoke puff positions
            itemSpriteComponent.sprite[1].isoPosition.setTo(spriteComponent.sprite.isoX  +
                Math.cos(playerControlComponent.angleOfPointer) * 30, spriteComponent.sprite.isoY +
                Math.sin(playerControlComponent.angleOfPointer) * 30, spriteComponent.sprite.isoZ + 10);
            itemSpriteComponent.sprite[1].animations.play('RANGED-SHOOT');
            itemSpriteComponent.sprite[1].animations.currentAnim.onComplete.add(function(){itemSpriteComponent.sprite[1].visible = false;});
        }

    }
    private changeAngleByLookDirection(sprite:Phaser.Plugin.Isometric.IsoSprite, playerControl:PlayerControlComponent){
        if (playerControl.lookDirection == LookDirection.NW) {
            sprite.angle = 0;
        }
        else if (playerControl.lookDirection == LookDirection.N) {
            sprite.angle = 45;
        }
        else if (playerControl.lookDirection == LookDirection.NE) {
            sprite.angle = 90;
        }
        else if (playerControl.lookDirection == LookDirection.E) {
            sprite.angle = 135;
        }
        else if (playerControl.lookDirection == LookDirection.SE) {
            sprite.angle = 180;
        }
        else if (playerControl.lookDirection == LookDirection.S) {
            sprite.angle = 225;
        }
        else if (playerControl.lookDirection == LookDirection.SW) {
            sprite.angle = 270;
        }
        else if (playerControl.lookDirection == LookDirection.W) {
            sprite.angle = 315;
        }
        else{
            sprite.angle = 360;
        }
    }
}