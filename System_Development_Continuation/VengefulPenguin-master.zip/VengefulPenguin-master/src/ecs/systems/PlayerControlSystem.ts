///<reference path="../base/System.ts"/>
///<reference path="../base/EcsWorld.ts"/>
///<reference path="../components/VelocityComponent.ts"/>

class PlayerControlSystem extends System {

    horizontalFactor: number = 0.75;    // Makes player move slower in horizontal directions.

    constructor(state:Phaser.State, game:Phaser.Game, world:EcsWorld) {
        super(state, game, world)
        this.registerComponent(this.getComponent(PlayerControlComponent));
        this.registerComponent(this.getComponent(VelocityComponent));
    }

    // If a player is facing north but moves to the south, the speed will be slower by this function.
    calcuFacingPenalty(playerControl: PlayerControlComponent): number{
        if (playerControl.movementState == MovementState.N && (playerControl.lookDirection == LookDirection.N ||
            playerControl.lookDirection == LookDirection.NW || playerControl.lookDirection == LookDirection.NE) ||
            playerControl.movementState == MovementState.S && (playerControl.lookDirection == LookDirection.S ||
            playerControl.lookDirection == LookDirection.SW || playerControl.lookDirection == LookDirection.SE) ||
            playerControl.movementState == MovementState.E && (playerControl.lookDirection == LookDirection.E ||
            playerControl.lookDirection == LookDirection.SE || playerControl.lookDirection == LookDirection.NE) ||
            playerControl.movementState == MovementState.W && (playerControl.lookDirection == LookDirection.W ||
            playerControl.lookDirection == LookDirection.SW || playerControl.lookDirection == LookDirection.NW) ||
            playerControl.movementState == MovementState.SE && (playerControl.lookDirection == LookDirection.SE ||
            playerControl.lookDirection == LookDirection.S || playerControl.lookDirection == LookDirection.E) ||
            playerControl.movementState == MovementState.SW && (playerControl.lookDirection == LookDirection.SW ||
            playerControl.lookDirection == LookDirection.S || playerControl.lookDirection == LookDirection.W) ||
            playerControl.movementState == MovementState.NE && (playerControl.lookDirection == LookDirection.NE ||
            playerControl.lookDirection == LookDirection.N || playerControl.lookDirection == LookDirection.E) ||
            playerControl.movementState == MovementState.NW && (playerControl.lookDirection == LookDirection.NW ||
            playerControl.lookDirection == LookDirection.N || playerControl.lookDirection == LookDirection.W)){
            return 1;
        }
        return 0.5;     // Movement penalty factor
    }

    public process(entity:Entity, elapsed:number) {
        var playerControlComponent:PlayerControlComponent = <PlayerControlComponent> entity.get(
            this.getComponent(PlayerControlComponent));
        var velocityComponent:VelocityComponent = <VelocityComponent> entity.get(this.getComponent(VelocityComponent));
        var speedToSet = playerControlComponent.speed * this.calcuFacingPenalty(playerControlComponent);
        switch (playerControlComponent.movementState) {
            case MovementState.N:
                velocityComponent.x = -speedToSet;
                velocityComponent.y = -speedToSet;
                break;
            case MovementState.NE:
                velocityComponent.x = 0;
                velocityComponent.y = -speedToSet;
                break;
            case MovementState.NW:
                velocityComponent.x = -speedToSet;
                velocityComponent.y = 0;
                break;
            case MovementState.S:
                velocityComponent.x = speedToSet;
                velocityComponent.y = speedToSet;
                break;
            case MovementState.SE:
                velocityComponent.x = speedToSet;
                velocityComponent.y = 0;
                break;
            case MovementState.SW:
                velocityComponent.x = 0;
                velocityComponent.y = speedToSet;
                break;
            case MovementState.E:
                velocityComponent.x = speedToSet * this.horizontalFactor;
                velocityComponent.y = -speedToSet * this.horizontalFactor;
                break;
            case MovementState.W:
                velocityComponent.x = -speedToSet * this.horizontalFactor;
                velocityComponent.y = speedToSet * this.horizontalFactor;
                break;
            case MovementState.NONE:
                velocityComponent.x = 0;
                velocityComponent.y = 0;
                break;

        }
    }
}