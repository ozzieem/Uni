///<reference path="../base/System.ts"/>
///<reference path="../base/EcsWorld.ts"/>
///<reference path="../components/PositionComponent.ts"/>
///<reference path="../components/DisplayComponent.ts"/>
///<reference path="../components/VelocityComponent.ts"/>
///<reference path="../components/RangedWeaponComponent.ts"/>
///<reference path="../components/NetworkPlayerComponent.ts"/>
///<reference path="../components/SoundComponent.ts"/>

class RangedWeaponSystem extends System {

    private items: any;
    constructor(state:Phaser.State, game:Phaser.Game, world:EcsWorld) {
        super(state, game, world)
        this.registerComponent(this.getComponent(RangedWeaponComponent));
        this.registerComponent(this.getComponent(VelocityComponent));
        this.registerComponent(this.getComponent(SpriteComponent));
        this.registerComponent(this.getComponent(InventoryComponent));

        this.items = this.game.cache.getJSON('items');
    }

    public process(entity:Entity, elapsed:number) {
        var spriteComponent:SpriteComponent = <SpriteComponent> entity.get(this.getComponent(SpriteComponent));
        var playerControl:PlayerControlComponent = <PlayerControlComponent> entity.get(this.getComponent(PlayerControlComponent));
        var inventory:InventoryComponent = <InventoryComponent> entity.get(this.getComponent(InventoryComponent));
        var networkPlayer:NetworkPlayerComponent = <NetworkPlayerComponent> entity.get(this.getComponent(NetworkPlayerComponent));

        playerControl.hasFired = false;
        if (!playerControl.isFiring) {
            return;
        }

        if(inventory.cooldownDict[inventory.activeItem] !== undefined && !networkPlayer) {
            return;
        }

        inventory.cooldownDict[inventory.activeItem] = this.game.time.now;


          // Aim towards pointer
        playerControl.hasFired = true;
        var angle = playerControl.angleOfPointer;
        var offset = this.items[inventory.activeItem].offset;
        var velocity = new VelocityComponent(
            Math.cos(angle) * this.items[inventory.activeItem].speed + spriteComponent.sprite.body.velocity.x,
            Math.sin(angle) * this.items[inventory.activeItem].speed + spriteComponent.sprite.body.velocity.y,
            50);
        var x = spriteComponent.sprite.isoX + Math.cos(angle) * offset;
        var y = spriteComponent.sprite.isoY + Math.sin(angle) * offset;
        var z = spriteComponent.sprite.isoZ;

        this.world.prefab.createRock(x, y, z, this.game.state.getCurrentState().objectGroup, velocity,
            entity, this.items[inventory.activeItem].lifespan, this.items[inventory.activeItem].damage);

        var soundComponent:SoundComponent = <SoundComponent> entity.get(this.getComponent(SoundComponent));
        if (soundComponent){
            soundComponent.addSound('throwing', spriteComponent.sprite.position);
        }

    }
}