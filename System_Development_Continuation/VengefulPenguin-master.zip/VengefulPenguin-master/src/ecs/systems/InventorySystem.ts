///<reference path="../base/System.ts"/>
///<reference path="../base/EcsWorld.ts"/>
///<reference path="../components/InventoryComponent.ts"/>
///<reference path="../components/MeleeWeaponComponent.ts"/>
///<reference path="../components/RangedWeaponComponent.ts"/>

class InventorySystem extends System {

    private items: any;
    constructor(state:Phaser.State, game:Phaser.Game, world:EcsWorld) {
        super(state, game, world)
        this.registerComponent(this.getComponent(PlayerControlComponent));
        this.registerComponent(this.getComponent(InventoryComponent));
        this.items = this.game.cache.getJSON('items');
    }

    public onAdded(entity:Entity) {
        var inventoryComponent:InventoryComponent = <InventoryComponent> entity.get(
            this.getComponent(InventoryComponent));
        this.addActiveComponent(entity, inventoryComponent.activeItem);
    }
    public process(entity:Entity) {

        var playerControlComponent:PlayerControlComponent = <PlayerControlComponent> entity.get(
            this.getComponent(PlayerControlComponent));
        var inventoryComponent:InventoryComponent = <InventoryComponent> entity.get(
            this.getComponent(InventoryComponent));

        this.checkCooldown(inventoryComponent);
        this.checkItemSwap(entity, playerControlComponent, inventoryComponent);
    }

    private checkCooldown(inventoryComponent: InventoryComponent) {
        var currentTime = this.game.time.now;
        var cooldownComplete:string[] = [];
        for (var item in inventoryComponent.cooldownDict) {
            if (currentTime - inventoryComponent.cooldownDict[item] > this.items[inventoryComponent.activeItem].cooldown) 
            {
                cooldownComplete.push(item);

            }
        }
        for(var item in cooldownComplete) {
            inventoryComponent.cooldownDict[cooldownComplete[item]] = undefined;
        }
    }
    
    private checkItemSwap(entity: Entity, playerControlComponent: PlayerControlComponent, inventoryComponent: InventoryComponent)
    {
        playerControlComponent.hasSwitchedItem = false;
        
        if(playerControlComponent.itemSlot != ItemSlot.NONE && inventoryComponent.cooldownDict[inventoryComponent.activeItem] == undefined)
        {

            inventoryComponent.lastActiveItem = inventoryComponent.activeItem;
            inventoryComponent.activeItem = inventoryComponent.inventory[playerControlComponent.itemSlot];

            // Check if trying to switch to same item
            if(inventoryComponent.lastActiveItem === inventoryComponent.activeItem) {
                return;
            }
            playerControlComponent.hasSwitchedItem = true;
            //Remove component for current active item
            if(this.items[inventoryComponent.lastActiveItem].itemtype == "MELEE"){
                entity.remove(this.getComponent(MeleeWeaponComponent));
            }
            else if (this.items[inventoryComponent.lastActiveItem].itemtype == "RANGED") {
                entity.remove(this.getComponent(RangedWeaponComponent));
            }

            this.addActiveComponent(entity, inventoryComponent.activeItem);
        }
    }

    private addActiveComponent(entity:Entity, activeItem:string) {
        //Add component for  current active item
        if (this.items[activeItem].itemtype == "MELEE") {
            entity.add(new MeleeWeaponComponent(), this.getComponent(MeleeWeaponComponent));

        }
        else if (this.items[activeItem].itemtype == "RANGED") {
            entity.add(new RangedWeaponComponent(), this.getComponent(RangedWeaponComponent));

        }
    }
}