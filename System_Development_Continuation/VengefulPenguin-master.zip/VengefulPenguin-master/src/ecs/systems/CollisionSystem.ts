///<reference path="../base/System.ts"/>
///<reference path="../base/EcsWorld.ts"/>
///<reference path="../components/ProjectileCollisionComponent.ts"/>
///<reference path="../components/SpriteComponent.ts"/>
///<reference path="../components/TeamComponent.ts"/>

class CollisionSystem extends System {

    constructor(state:Phaser.State, game:Phaser.Game, world:EcsWorld) {
        super(state, game, world)
        this.registerComponent(this.getComponent(SpriteComponent));
        this.registerComponent(this.getComponent(ProjectileCollisionComponent));
    }

    public process(entity:Entity, elapsed:number) {
        var collisionComponent:ProjectileCollisionComponent =
            <ProjectileCollisionComponent> entity.get(this.getComponent(ProjectileCollisionComponent));
        var spriteComponent:SpriteComponent = <SpriteComponent> entity.get(this.getComponent(SpriteComponent));
        var teamComponent:TeamComponent = <TeamComponent> entity.get(this.getComponent(TeamComponent));
        this.bulletCollision(spriteComponent, collisionComponent,teamComponent, entity);
    }

    private bulletCollision(spriteComponent:SpriteComponent, projectileCollision:ProjectileCollisionComponent, 
                            teamComponent:TeamComponent, entity:Entity) {
        
        var bullets = this.world.getEntitiesByGroup('bullets');
        
        bullets.forEach((bulletEntity) => {
            var bulletSprite:SpriteComponent = <SpriteComponent> bulletEntity.get(this.getComponent(SpriteComponent));
            var firedBy:FiredByComponent = <FiredByComponent> bulletEntity.get(this.getComponent(FiredByComponent));
            var firedByTeam:TeamComponent = <TeamComponent> firedBy.entity.get(this.getComponent(TeamComponent));
            var soundComponent:SoundComponent = <SoundComponent> entity.get(this.getComponent(SoundComponent));


            if (this.game.physics.isoArcade.overlap(bulletSprite.sprite, spriteComponent.sprite)) {
                if (firedBy.entity.id != entity.id) {


                    if (soundComponent) {
                        if (bulletSprite.sprite.key.toString() == 'smallRock') {
                            soundComponent.addSound('bodyHit', bulletSprite.sprite.position);
                        }
                        if (bulletSprite.sprite.key.toString() == 'sword')
                            soundComponent.addSound('swordHit', bulletSprite.sprite.position);

                    }
                    //Check if on different team
                    if (firedByTeam.team !== teamComponent.team) {
                        // Buffering up all hits in one frame
                        projectileCollision.bulletHits.push(bulletEntity);
                    }
                    bulletEntity.kill();
                }
            }
        });
    }
}