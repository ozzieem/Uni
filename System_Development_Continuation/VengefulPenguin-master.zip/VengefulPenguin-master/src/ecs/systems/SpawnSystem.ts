///<reference path="../base/System.ts"/>
///<reference path="../components/SpawnComponent.ts"/>


class SpawnSystem extends System {

    constructor(state:Phaser.State, game:Phaser.Game, world:EcsWorld) {
        super(state, game, world)
        this.registerComponent(this.getComponent(SpawnComponent));
        this.registerComponent(this.getComponent(HealthComponent));
        this.registerComponent(this.getComponent(SpriteComponent));
    }

    public process(entity:Entity) {
        var health:HealthComponent = <HealthComponent> entity.get(this.getComponent(HealthComponent));
        var spawn:SpawnComponent = <SpawnComponent> entity.get(this.getComponent(SpawnComponent));
        var spriteComponent:SpriteComponent = <SpriteComponent> entity.get(this.getComponent(SpriteComponent));
        var lifeStatus:LifeStatusComponent = <LifeStatusComponent> entity.get(this.getComponent(LifeStatusComponent));

        if (!lifeStatus.alive) {
            if (spawn.startTime < 0) {
                spawn.startTime = this.game.time.now;
                // spriteComponent.sprite.visible = false;
                spriteComponent.sprite.body.enable = false;
            }
        }

        if (this.game.time.now - spawn.startTime > spawn.spawnTime && !lifeStatus.alive) {
            lifeStatus.alive = true;
            lifeStatus.justSpawned = true;
            spriteComponent.sprite.visible = true;
            spriteComponent.sprite.body.enable = true;
            spriteComponent.sprite.body.x = spawn.positionX;
            spriteComponent.sprite.body.y = spawn.positionY;
            spriteComponent.sprite.body.z = 25;
            health.health = health.maxHealth;
            spawn.startTime = -1;
            
        }
    }
}