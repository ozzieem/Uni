/// <reference path="../../definitions/phaser.d.ts"/>
///<reference path="../base/System.ts"/>
///<reference path="../base/EcsWorld.ts"/>

class PlayerInputSystem extends System {
    private oldKeyPresses: {[key:number] : boolean};
    constructor(state:Phaser.State, game:Phaser.Game, world:EcsWorld) {
        super(state, game, world)

        this.registerComponent(this.getComponent(PlayerControlComponent));
        this.registerComponent(this.getComponent(InputComponent));

        this.oldKeyPresses = {};
    }
    
    public process(entity:Entity, elapsed:number) {
        var playerControlComponent:PlayerControlComponent = <PlayerControlComponent> entity.get(
            this.getComponent(PlayerControlComponent));
        var inputComponent:InputComponent = <InputComponent> entity.get(this.getComponent(InputComponent));
        var spriteComponent: SpriteComponent = <SpriteComponent> entity.get(this.getComponent(SpriteComponent));

        var dx = playerControlComponent.cursor.x - spriteComponent.sprite.isoX;
        var dy = playerControlComponent.cursor.y - spriteComponent.sprite.isoY;
        var angle = Math.atan2(dy, dx) + Math.PI;

        //Set global angleValue
        playerControlComponent.angleOfPointer = angle - Math.PI;

        //Set global Look Direction
        if(angle <= Math.PI / 8 || angle >= Math.PI*15 / 8)
        {
            playerControlComponent.lookDirection = LookDirection.NW;
        }
        else if(angle > Math.PI / 8 && angle <= Math.PI*3 / 8)
        {
            playerControlComponent.lookDirection = LookDirection.N;
        }
        else if(angle > Math.PI*3 / 8 && angle <= Math.PI*5 / 8)
        {
            playerControlComponent.lookDirection = LookDirection.NE;
        }
        else if(angle > Math.PI*5 / 8 && angle <= Math.PI*7 / 8)
        {
            playerControlComponent.lookDirection = LookDirection.E;
        }
        else if(angle > Math.PI*7 / 8 && angle <= Math.PI*9 / 8)
        {
            playerControlComponent.lookDirection = LookDirection.SE;
        }
        else if(angle > Math.PI*9 / 8 && angle <= Math.PI*11 / 8)
        {
            playerControlComponent.lookDirection = LookDirection.S;
        }
        else if(angle > Math.PI*11 / 8 && angle <= Math.PI*13 / 8)
        {
            playerControlComponent.lookDirection = LookDirection.SW;
        }
        else if(angle > Math.PI*13 / 8 && angle < Math.PI*15 / 8)
        {
            playerControlComponent.lookDirection = LookDirection.W;
        }

        if (this.game.input.keyboard.isDown(inputComponent.left)) {
            switch (this.checkVertical(inputComponent)) {
                case 0:
                    playerControlComponent.movementState = MovementState.W;
                    break;
                case -1:
                    playerControlComponent.movementState = MovementState.NW;
                    break;
                case 1:
                    playerControlComponent.movementState = MovementState.SW;
                    break;
            }
        }
        else if (this.game.input.keyboard.isDown(inputComponent.right)) {
            switch (this.checkVertical(inputComponent)) {
                case 0:
                    playerControlComponent.movementState = MovementState.E;
                    break;
                case -1:
                    playerControlComponent.movementState = MovementState.NE;
                    break;
                case 1:
                    playerControlComponent.movementState = MovementState.SE;
                    break;
            }
        }
        else if (this.game.input.keyboard.isDown(inputComponent.up)) {
            switch (this.checkHorisontal(inputComponent)) {
                case 0:
                    playerControlComponent.movementState = MovementState.N;
                    break;
                case -1:
                    playerControlComponent.movementState = MovementState.NW;
                    break;
                case 1:
                    playerControlComponent.movementState = MovementState.NE;
                    break;
            }
        }
        else if (this.game.input.keyboard.isDown(inputComponent.down)) {
            switch (this.checkHorisontal(inputComponent)) {
                case 0:
                    playerControlComponent.movementState = MovementState.S;
                    break;
                case -1:
                    playerControlComponent.movementState = MovementState.SW;
                    break;
                case 1:
                    playerControlComponent.movementState = MovementState.SE;
                    break;
            }
        }
        else{
            playerControlComponent.movementState = MovementState.NONE;
        }

        var deathComponent:LifeStatusComponent = <LifeStatusComponent> entity.get(this.getComponent(LifeStatusComponent));
        if (deathComponent) {

            if (this.game.input.keyboard.isDown(inputComponent.fire) && deathComponent.alive) {
                this.game.iso.unproject(this.game.input.activePointer.position, playerControlComponent.cursor);
                playerControlComponent.isFiring = true;
            }
            else {
                this.game.iso.unproject(this.game.input.activePointer.position, playerControlComponent.cursor);
                playerControlComponent.isFiring = false;
            }
        }

        if(this.keyboardPressed(inputComponent.item1)) {
            playerControlComponent.itemSlot = ItemSlot.ONE;
        }
        else if(this.keyboardPressed(inputComponent.item2)) {
            playerControlComponent.itemSlot = ItemSlot.TWO;
        }
        else{
            playerControlComponent.itemSlot = ItemSlot.NONE;
        }

        if (this.game.input.keyboard.isDown(inputComponent.scores)){
            playerControlComponent.showScores = true;
        }
        else
            playerControlComponent.showScores = false;
    }

    private checkVertical(input: InputComponent):number {
        if (this.game.input.keyboard.isDown(input.up)) {
            return -1;
        }
        else if (this.game.input.keyboard.isDown(input.down)) {
            return 1;
        }
        else {
            return 0;
        }
    }

    private checkHorisontal(input: InputComponent):number {
        if (this.game.input.keyboard.isDown(input.left)) {
            return -1;
        }
        else if (this.game.input.keyboard.isDown(input.right)) {
            return 1;
        }
        else {
            return 0;
        }
    }

    private keyboardPressed(key:number): boolean {
        var pressed: boolean;
        if (this.game.input.keyboard.isDown(key) && !this.oldKeyPresses[key]) {
            pressed = true;
        }
        else {
            pressed = false;
        }
        this.oldKeyPresses[key] = this.game.input.keyboard.isDown(key);
        return pressed;
    }

}


