///<reference path="../base/System.ts"/>
///<reference path="../components/SoundComponent.ts"/>


class SoundSystem extends System {
    soundDict:{[soundString:string]:Phaser.Sound};
    private maxDistance: number;

    constructor(state:Phaser.State, game:Phaser.Game, world:EcsWorld) {
        super(state, game, world);

        this.registerComponent(this.getComponent(SoundComponent));

        this.soundDict = {};

        this.soundDict['throwing'] = this.game.add.audio('throwing');
        this.soundDict['bodyHit'] = this.game.add.audio('bodyHit');
        this.soundDict['swordSwing'] = this.game.add.audio('swordSwing');
        this.soundDict['swordHit'] = this.game.add.audio('swordHit');
        this.maxDistance = 600;
    }


    process(entity:Entity) {
        var soundComponent:SoundComponent = <SoundComponent> entity.get(this.getComponent(SoundComponent));
        for (var key in soundComponent.soundList) {
            if (key in this.soundDict)
                this.soundPlayer(soundComponent.soundList[key], key);
        }
        soundComponent.soundList = {};
    }

    soundPlayer(position:Phaser.Point, key:string) {
        var distance = this.game.camera.position.distance(position);
        var volume = 1 - (this.game.math.clamp(distance/this.maxDistance, 0, 1));

        this.soundDict[key].play(null, null, volume);
    }

}