///<reference path="../base/System.ts"/>
///<reference path="../base/EcsWorld.ts"/>
///<reference path="../components/LifespanComponent.ts"/>

class LifespanSystem extends System {
    constructor(state:Phaser.State, game:Phaser.Game, world:EcsWorld) {
        super(state, game, world)
        this.registerComponent(this.getComponent(LifespanComponent));
    }

    public onAdded(entity:Entity){
        var lifespanComponent:LifespanComponent = <LifespanComponent> entity.get(this.getComponent(LifespanComponent));
       lifespanComponent.startTime = this.game.time.now;
    }

    public process(entity:Entity) {
        var lifespanComponent:LifespanComponent = <LifespanComponent> entity.get(this.getComponent(LifespanComponent));
        if (this.game.time.now - lifespanComponent.startTime > lifespanComponent.lifetime) {
            entity.kill();
        }
    }
}