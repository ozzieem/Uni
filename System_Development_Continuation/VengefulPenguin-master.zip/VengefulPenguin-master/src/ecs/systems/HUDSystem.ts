///<reference path="../base/System.ts"/>
///<reference path="../components/InventoryComponent.ts"/>
class HUDSystem extends System {
    timerText:Phaser.Text;
    scoresText:Phaser.Text;
    private redTeamScoreText:Phaser.Text;
    private greenTeamScoreText:Phaser.Text;
    healthbar:Phaser.Graphics;
    healthbarBackpanel:Phaser.Graphics;
    inventoryBackpanel:Phaser.Graphics;
    inventorySelect:Phaser.Graphics;
    swordCooldownBox:Phaser.Graphics;
    rockCooldownBox:Phaser.Graphics;
    topBarImage:Phaser.Sprite;
    bottomItemImage:Phaser.Sprite;
    swordText:Phaser.Text;
    rockText:Phaser.Text;
    SelectionXOffset:number;
    private items:any;
    private rockCooldownBoxCleared : boolean;
    private swordCooldownBoxCleared : boolean;
    private oldHealth : number;

    constructor(state:Phaser.State, game:Phaser.Game, world:EcsWorld) {
        super(state, game, world);
        this.registerComponent(this.getComponent(HealthComponent));
        this.registerComponent(this.getComponent(InventoryComponent));
        this.registerComponent(this.getComponent(MinimapComponent));
        this.registerComponent(this.getComponent(SpriteComponent));
        var style = {font: "16px Segoe UI", fill: "#FFFFFF", wordWrap: true, wordWrapWidth: 200, align: "center"};
        this.items = this.game.cache.getJSON('items');
        this.oldHealth = 0;
        
        //Add top bar graphics
        this.topBarImage = this.game.add.sprite(this.game.width / 2, 0, 'papyrusRoll');
        this.topBarImage.fixedToCamera = true;
        this.topBarImage.anchor.set(0.5, 0.6);
        this.topBarImage.scale.set(0.5);

        //Add bottom item graphics
        this.bottomItemImage = this.game.add.sprite(150, this.game.height, 'papyrusRoll');
        this.bottomItemImage.fixedToCamera = true;
        this.bottomItemImage.anchor.set(0.5, 0.8);
        this.bottomItemImage.scale.set(0.6, 0.5);
        this.bottomItemImage.alpha = 0.5;

        this.healthbarBackpanel = this.game.add.graphics(260, 500);
        this.healthbar = this.game.add.graphics(50, 500);

        //Add Phaser.Graphics
        this.inventoryBackpanel = this.game.add.graphics(40, 520);
        this.rockText = game.add.text(185, 560, "Rock", style);
        this.swordText = game.add.text(75, 560, "Sword", style);
        this.swordCooldownBox = this.game.add.graphics(40, 520);
        this.rockCooldownBox = this.game.add.graphics(40, 520);
        this.inventorySelect = this.game.add.graphics(40, 520);


        this.healthbarBackpanel.fixedToCamera = true;
        this.healthbar.fixedToCamera = true;
        this.inventoryBackpanel.fixedToCamera = true;
        this.inventorySelect.fixedToCamera = true;
        this.swordCooldownBox.fixedToCamera = true;
        this.rockCooldownBox.fixedToCamera = true;

        // Sets the panel behind the actual healthbar
        this.healthbarBackpanel.beginFill(0x564C24);
        this.healthbarBackpanel.lineStyle(14, 0x706433, 1);
        this.healthbarBackpanel.moveTo(0, -5);
        this.healthbarBackpanel.lineTo(-220, -5);
        this.healthbarBackpanel.endFill();

        // Sets the timer text
        var timerStyle = {font: "30px Rouge Script", fill: "#271a0c", wordWrap: true, wordWrapWidth: 200, align: "center"};
        this.timerText = game.add.text(this.game.width/2, 10, '', timerStyle);
        this.timerText.anchor.set(0.5, 0);
        this.timerText.text = (<Play>this.state).timerString;
        this.timerText.fixedToCamera = true;
        this.timerText.stroke = '#000000';
        this.timerText.strokeThickness = 1;

        // Sets the score text
        var scoreStyle = {font: "30px Rouge Script", fill: "#ffffff", wordWrap: false, wordWrapWidth: 200, align: "center"};
        this.scoresText = game.add.text(60, 80, '', scoreStyle);
        this.scoresText.fixedToCamera = true;
        this.scoresText.stroke = '#000000';
        this.scoresText.strokeThickness = 1;
        this.scoresText.fill = '#ffffff';

        // Sets the tob bar score text
        this.redTeamScoreText = game.add.text(this.game.width/2 - 50, 30, '', scoreStyle);
        this.redTeamScoreText.anchor.set(0.5, 0.5);
        this.redTeamScoreText.fixedToCamera = true;
        this.redTeamScoreText.stroke = '#000000';
        this.redTeamScoreText.strokeThickness = 3;
        this.redTeamScoreText.fill = '#ff3333';


        // Sets the tob bar score text
        this.greenTeamScoreText = game.add.text(this.game.width/2 + 50, 30, '', scoreStyle);
        this.greenTeamScoreText.anchor.set(0.5, 0.5);
        this.greenTeamScoreText.fixedToCamera = true;
        this.greenTeamScoreText.stroke = '#000000';
        this.greenTeamScoreText.strokeThickness = 3;
        this.greenTeamScoreText.fill = '#85a329';

        // Sets the panel behind Inventory, hard coded (Why?) crunch time thats why mf
        // this.inventoryBackpanel.beginFill(0x6b6b47);
        // this.inventoryBackpanel.lineStyle(2, 0x999966, 1);
        // this.inventoryBackpanel.drawRect(0, 0, 220, 60);
        // this.inventoryBackpanel.endFill();

        // Writes text on top of the panels
        this.swordText.fixedToCamera = true;
        this.rockText.fixedToCamera = true;

        // Paint a nice sword
        var xOffset = 17;
        var yOffset = -52;

        //Handle
        this.inventoryBackpanel.beginFill(0x994d00);
        this.inventoryBackpanel.lineStyle(2, 0x663300, 1);
        this.inventoryBackpanel.moveTo(20 + xOffset, 80 + yOffset);
        this.inventoryBackpanel.lineTo(20 + xOffset, 85 + yOffset);
        this.inventoryBackpanel.lineTo(30 + xOffset, 85 + yOffset);
        this.inventoryBackpanel.lineTo(30 + xOffset, 90 + yOffset);
        this.inventoryBackpanel.lineTo(50 + xOffset, 90 + yOffset);
        this.inventoryBackpanel.lineTo(50 + xOffset, 85 + yOffset);
        this.inventoryBackpanel.lineTo(60 + xOffset, 85 + yOffset);
        this.inventoryBackpanel.lineTo(60 + xOffset, 80 + yOffset);
        this.inventoryBackpanel.lineTo(20 + xOffset, 80 + yOffset);
        this.inventoryBackpanel.endFill();


        var xOffset = 22;
        var yOffset = -51;
        //Blade
        this.inventoryBackpanel.beginFill(0xbfbfbf);
        this.inventoryBackpanel.lineStyle(2, 0x8c8c8c, 1);
        this.inventoryBackpanel.moveTo(30 + xOffset, 80 + yOffset);
        this.inventoryBackpanel.lineTo(30 + xOffset, 60 + yOffset);
        this.inventoryBackpanel.lineTo(35 + xOffset, 55 + yOffset);
        this.inventoryBackpanel.lineTo(40 + xOffset, 60 + yOffset);
        this.inventoryBackpanel.lineTo(40 + xOffset, 80 + yOffset);
        this.inventoryBackpanel.lineTo(30 + xOffset, 80 + yOffset);
        this.inventoryBackpanel.endFill();

        //Pain a fancy rock here

        var xOffset = 145;
        var yOffset = 22;
        this.inventoryBackpanel.beginFill(0x737373);
        this.inventoryBackpanel.lineStyle(2, 0x595959, 1);
        this.inventoryBackpanel.moveTo(xOffset, yOffset);
        this.inventoryBackpanel.lineTo(20 + xOffset, -10 + yOffset);
        this.inventoryBackpanel.lineTo(30 + xOffset, 4 + yOffset);
        this.inventoryBackpanel.lineTo(32 + xOffset, 8 + yOffset);
        this.inventoryBackpanel.lineTo(28 + xOffset, 12 + yOffset);
        this.inventoryBackpanel.lineTo(15 + xOffset, 16 + yOffset);
        this.inventoryBackpanel.lineTo(xOffset, yOffset);
        this.inventoryBackpanel.endFill();

        //Create overlay
        this.inventorySelect.lineStyle(4, 0x3A362D, 1);
        this.inventorySelect.alpha = 1;
    }

    public onAdded(entity:Entity) {
        //Bootstrap to see which the starting item is
        var inventory:InventoryComponent = <InventoryComponent> entity.get(this.getComponent(InventoryComponent));
        if (inventory.activeItem == "sword") {
            this.SelectionXOffset = 0;
        }
        else if (inventory.activeItem == "rock") {
            this.SelectionXOffset = 110;
        }

        //Print the selection box
        this.inventorySelect.lineStyle(4, 0x3A362D, 1);
        this.inventorySelect.drawRect(this.SelectionXOffset, 0, 110, 60);
    }

    public process(entity:Entity) {
        this.timerText.text = (<Play>this.state).timerString;
        var health:HealthComponent = <HealthComponent> entity.get(this.getComponent(HealthComponent));
        var playControlComp:PlayerControlComponent = <PlayerControlComponent> entity.get(this.getComponent(PlayerControlComponent));
        var fraglist = (<Play>this.state).scoreKeeper.frags;
        var deathlist = (<Play>this.state).scoreKeeper.deaths;
        var playersDict = (<Play>this.state).initPlayers;
        this.updateTeamScore(fraglist);

        if (playControlComp.showScores) {
            var scoretemp:string = "";

            for (var key in fraglist) {
                scoretemp += playersDict[key].name + ": F: " + fraglist[key] + " D: " + deathlist[key];
                if (key == window.vengefulPenguin.game.state.getCurrentState().mySocket)
                    scoretemp += '* \n';
                else
                    scoretemp += '\n';
            }
            this.scoresText.text = scoretemp;
        }
        else {
            this.scoresText.text = "";
        }


        var inventory:InventoryComponent = <InventoryComponent> entity.get(this.getComponent(InventoryComponent));
        var hp = health.health;
        var totalhp = health.maxHealth;

        // Healthbar logic
        // Only update the healthbar if ur hp has changed since last frame.
        if(hp != this.oldHealth)
        {
            this.healthbar.clear();
            var x = ((hp / totalhp) * 100);
            var colour = this.rgbToHex((x > 50 ? 1 - 2 * (x - 50) / 100.0 : 1.0) * 255, (x > 50 ? 1.0 : 2 * x / 100.0) * 255);

            if (health.health <= 0) {
                this.healthbar.endFill();
            }
            else {
                this.healthbar.beginFill(colour);
                this.healthbar.lineStyle(10, colour, 1);
                this.healthbar.moveTo(0, -5);
                this.healthbar.lineTo(200 * hp / totalhp, -5);
                this.healthbar.endFill();
            }
        }
        //Assign oldHealth to hp gathered from this frame
        this.oldHealth = hp;

        //Inventory stuff
         if (inventory.activeItem == "sword" && this.SelectionXOffset == 110) {
            this.inventorySelect.clear();
             this.SelectionXOffset = 0;
             this.inventorySelect.lineStyle(4, 0x3A362D, 1);
             this.inventorySelect.drawRect(this.SelectionXOffset, 0, 110, 60);
         }
        else if (inventory.activeItem == "rock" && this.SelectionXOffset == 0) {
            this.inventorySelect.clear();
            this.SelectionXOffset = 110;
             this.inventorySelect.lineStyle(4, 0x3A362D, 1);
             this.inventorySelect.drawRect(this.SelectionXOffset, 0, 110, 60);
         }
    
    
         if (inventory.cooldownDict["rock"] != undefined) {
             var cooldownRatio = (this.game.time.now - inventory.cooldownDict["rock"]) / (this.items["rock"].cooldown);
             this.rockCooldownBox.clear();
             this.rockCooldownBox.lineStyle(4, 0x003300, 1);
             this.rockCooldownBox.beginFill(0x003300, 0.5);
             this.rockCooldownBox.drawRect(110, 60, 110, -60 * (1 - cooldownRatio));
             this.rockCooldownBox.endFill();
             this.rockCooldownBoxCleared = false;
    
         }
         else{
             if(!this.rockCooldownBoxCleared)
             {
                 this.rockCooldownBox.clear();
                 this.rockCooldownBoxCleared = true;
             }
         }
    
         if (inventory.cooldownDict["sword"] != undefined) {
             var cooldownRatio = (this.game.time.now - inventory.cooldownDict["sword"]) / (this.items["sword"].cooldown);
             this.swordCooldownBox.clear();
            this.swordCooldownBox.lineStyle(4, 0x003300, 1);
             this.swordCooldownBox.beginFill(0x003300, 0.5);
             this.swordCooldownBox.drawRect(0, 60, 110, -60 * (1 - cooldownRatio));
             this.swordCooldownBox.endFill();
             this.swordCooldownBoxCleared = false;
         }
        else {
             if(!this.swordCooldownBoxCleared)
             {
                 this.swordCooldownBox.clear();
                 this.swordCooldownBoxCleared = true;
             }
        }
    }

    oldRed:number = 0;
    oldGreen:number = 0;

    private updateTeamScore(fraglist:{}) {
        var fragList = (<Play>this.state).scoreKeeper.frags;
        var teamScore:{[team:number]:number} = {};
        var playersDict = (<Play>this.state).initPlayers;
        for (var socketID in fragList) {
            if (teamScore[playersDict[socketID].team]) {
                teamScore[playersDict[socketID].team] += fragList[socketID];
            }
            else {
                teamScore[playersDict[socketID].team] = fragList[socketID];
            }
        }
        var redTeamScore = teamScore[0];
        var greenTeamScore = teamScore[1];


        this.redTeamScoreText.text = "" + redTeamScore;
        this.greenTeamScoreText.text = "" + greenTeamScore;

        if(redTeamScore != this.oldRed) {
            this.updateScoreAnimation(this.redTeamScoreText);
            this.oldRed = redTeamScore;
        }
        else if(greenTeamScore != this.oldGreen) {
            this.updateScoreAnimation(this.greenTeamScoreText);
            this.oldGreen = greenTeamScore;
        }
    }

    public rgbToHex(r, g) {
        return +("0x" + ((1 << 24) + (r << 16) + (g << 8)).toString(16).slice(1));
    }

    private updateScoreAnimation(teamText:Phaser.Text){
        teamText.scale.setTo(2, 2);
        var tweeny = this.game.add.tween(teamText.scale);
        tweeny.to({x: 1, y: 1}, 800, Phaser.Easing.Linear.None);
        tweeny.start();
    }

}