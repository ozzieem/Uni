///<reference path="../base/System.ts"/>
///<reference path="../base/EcsWorld.ts"/>
///<reference path="../components/AnimationComponent.ts"/>
class AnimationSystem extends System {
    animations: Phaser.Animation[];

    constructor(state:Phaser.State, game:Phaser.Game, world:EcsWorld) {
        super(state, game, world)
        this.registerComponent(this.getComponent(AnimationComponent));
        this.registerComponent(this.getComponent(PlayerControlComponent));
        this.registerComponent(this.getComponent(SpriteComponent));
    }

    public onAdded(entity:Entity) {
        var animation: AnimationComponent = <AnimationComponent> entity.get(this.getComponent(AnimationComponent));
        var spriteComponent: SpriteComponent = <SpriteComponent> entity.get(this.getComponent(SpriteComponent));

        animation.animations['FORWARD-W'] = { speed: 10, frames: [4, 5, 6, 7, 8, 9, 10, 11] };
        animation.animations['FORWARD-NW'] = { speed: 10, frames: [36, 37, 38, 39, 40, 41, 42, 43] };
        animation.animations['FORWARD-N'] = { speed: 10, frames: [68, 69, 70, 71, 72, 73, 74, 75] };
        animation.animations['FORWARD-NE'] = { speed: 10, frames: [100, 101, 102, 103, 104, 105, 106, 107] };
        animation.animations['FORWARD-E'] = { speed: 10, frames: [132,133,134,135,136,137,138,139] };
        animation.animations['FORWARD-SE'] = { speed: 10, frames: [164,165,166,167,168,169,170,171] };
        animation.animations['FORWARD-S'] = { speed: 10, frames: [196,197,198,199,200,201,202,203] };
        animation.animations['FORWARD-SW'] = { speed: 10, frames: [228,229,230,231,232,233,234,235] };
        animation.animations['BACKWARD-W'] = { speed: 5, frames: [11, 10, 9, 8, 7, 6, 5, 4] };
        animation.animations['BACKWARD-NW'] = { speed: 5, frames: [43, 42, 41, 40, 39, 38, 37, 36] };
        animation.animations['BACKWARD-N'] = { speed: 5, frames: [75, 74, 73, 72, 71, 70, 69, 68] };
        animation.animations['BACKWARD-NE'] = { speed: 5, frames: [107,106,105,104,103,102,101,100] };
        animation.animations['BACKWARD-E'] = { speed: 5, frames: [139,138,137,136,135,134,133,132] };
        animation.animations['BACKWARD-SE'] = { speed: 5, frames: [171,170,169,168,167,166,165,164] };
        animation.animations['BACKWARD-S'] = { speed: 5, frames: [203,202,201,200,199,198,197,196] };
        animation.animations['BACKWARD-SW'] = { speed: 5, frames: [235,234,233,232,231,230,229,228] };
        animation.animations['IDLE-W'] = { speed: 10, frames: [0, 1, 2, 3] };
        animation.animations['IDLE-NW'] = { speed: 10, frames: [32, 33, 34, 35] };
        animation.animations['IDLE-N'] = { speed: 10, frames: [64, 65, 66, 67] };
        animation.animations['IDLE-NE'] = { speed: 10, frames: [96, 97, 98, 99] };
        animation.animations['IDLE-E'] = { speed: 10, frames: [128, 129, 130, 131] };
        animation.animations['IDLE-SE'] = { speed: 10, frames: [160, 161, 162, 163] };
        animation.animations['IDLE-S'] = { speed: 10, frames: [192, 193, 194, 195] };
        animation.animations['IDLE-SW'] = { speed: 10, frames: [224, 225, 226, 227] };
        animation.animations['DIE'] = { speed: 5, frames: [21, 22, 23] };
        animation.animations['DEAD'] = { speed: 10, frames: [23] };


        for (var key in animation.animations) {
            var value = animation.animations[key];

            spriteComponent.sprite.animations.add(key, value.frames, value.speed, true);
        }
    }
    public process(entity:Entity, elapsed:number) {
        var playerControl:PlayerControlComponent = <PlayerControlComponent> entity.get(
            this.getComponent(PlayerControlComponent));
        var animation: AnimationComponent = <AnimationComponent> entity.get(this.getComponent(AnimationComponent));
        var spriteComponent: SpriteComponent = <SpriteComponent> entity.get(this.getComponent(SpriteComponent));

        if(playerControl.lookDirection == LookDirection.NW)
        {
            if(playerControl.movementState == MovementState.NONE)
                animation.currentName = 'IDLE-NW';
            else if(playerControl.movementState == MovementState.N
                || playerControl.movementState == MovementState.NW
                || playerControl.movementState == MovementState.W)
            {
                animation.currentName = 'FORWARD-NW';
            }
            else
                animation.currentName = 'BACKWARD-NW';
        }
        else if(playerControl.lookDirection == LookDirection.N)
        {
            if(playerControl.movementState == MovementState.NONE)
                animation.currentName = 'IDLE-N';
            else if(playerControl.movementState == MovementState.NE
                || playerControl.movementState == MovementState.N
                || playerControl.movementState == MovementState.NW)
            {
                animation.currentName = 'FORWARD-N';
            }
            else
                animation.currentName = 'BACKWARD-N';
        }
        else if(playerControl.lookDirection == LookDirection.NE)
        {
            if(playerControl.movementState == MovementState.NONE)
                animation.currentName = 'IDLE-NE';
            else if(playerControl.movementState == MovementState.N
                || playerControl.movementState == MovementState.NE
                || playerControl.movementState == MovementState.E)
            {
                animation.currentName = 'FORWARD-NE';
            }
            else
                animation.currentName = 'BACKWARD-NE';
        }
        else if(playerControl.lookDirection == LookDirection.E)
        {
            if(playerControl.movementState == MovementState.NONE)
                animation.currentName = 'IDLE-E';
            else if(playerControl.movementState == MovementState.NE
                || playerControl.movementState == MovementState.E
                || playerControl.movementState == MovementState.SE)
            {
                animation.currentName = 'FORWARD-E';
            }
            else
                animation.currentName = 'BACKWARD-E';
        }
        else if(playerControl.lookDirection == LookDirection.SE)
        {
            if(playerControl.movementState == MovementState.NONE)
                animation.currentName = 'IDLE-SE';
            else if(playerControl.movementState == MovementState.E
                || playerControl.movementState == MovementState.SE
                || playerControl.movementState == MovementState.S)
            {
                animation.currentName = 'FORWARD-SE';
            }
            else
                animation.currentName = 'BACKWARD-SE';
        }
        else if(playerControl.lookDirection == LookDirection.S)
        {
            if(playerControl.movementState == MovementState.NONE)
                animation.currentName = 'IDLE-S';
            else if(playerControl.movementState == MovementState.SE
                || playerControl.movementState == MovementState.S
                || playerControl.movementState == MovementState.SW)
            {
                animation.currentName = 'FORWARD-S';
            }
            else
                animation.currentName = 'BACKWARD-S';
        }
        else if(playerControl.lookDirection == LookDirection.SW)
        {
            if(playerControl.movementState == MovementState.NONE)
                animation.currentName = 'IDLE-SW';
            else if(playerControl.movementState == MovementState.S
                || playerControl.movementState == MovementState.SW
                || playerControl.movementState == MovementState.W)
            {
                animation.currentName = 'FORWARD-SW';
            }
            else
                animation.currentName = 'BACKWARD-SW';
        }
        else if(playerControl.lookDirection == LookDirection.W)
        {
            if(playerControl.movementState == MovementState.NONE)
                animation.currentName = 'IDLE-W';
            else if(playerControl.movementState == MovementState.SW
                || playerControl.movementState == MovementState.W
                || playerControl.movementState == MovementState.NW)
            {
                animation.currentName = 'FORWARD-W';
            }
            else
                animation.currentName = 'BACKWARD-W';
        }

        // Death animation
        var lifeStatus:LifeStatusComponent = <LifeStatusComponent> entity.get(this.getComponent(LifeStatusComponent));
        if (lifeStatus) {
            if (!lifeStatus.alive) {
                if (lifeStatus.playDeathAnim)
                    animation.currentName = 'DIE';
                if (spriteComponent.sprite.animations.frame == 23) {
                    lifeStatus.playDeathAnim = false;
                    animation.currentName = 'DEAD'
                }
            }
        }

        if(animation.currentName != 'Stop')
            spriteComponent.sprite.animations.play(animation.currentName);
        else
            spriteComponent.sprite.animations.stop();

    }
}
