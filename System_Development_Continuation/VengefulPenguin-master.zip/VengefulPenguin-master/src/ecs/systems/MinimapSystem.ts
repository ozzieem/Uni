///<reference path="../base/System.ts"/>
///<reference path="../base/EcsWorld.ts"/>
///<reference path="../components/SpriteComponent.ts"/>
///<reference path="../components/MinimapComponent.ts"/>
/**
 * Created by marti on 2016-05-16.
 */
class MinimapSystem extends System {
    private miniMapSprite:Phaser.Sprite;


    constructor(state:Phaser.State, game:Phaser.Game, world:EcsWorld) {
        super(state, game, world)
        this.registerComponent(this.getComponent(SpriteComponent));
        this.registerComponent(this.getComponent(MinimapComponent));
        this.registerComponent(this.getComponent(TeamComponent));

        //Add minimap to HUD
        this.miniMapSprite = this.game.add.sprite(420, 410, 'minimap');
        this.miniMapSprite.alpha = 0.5;
        this.miniMapSprite.bringToTop();
        this.miniMapSprite.fixedToCamera = true;
        
    }

    public onAdded(entity:Entity) {
        var player: Entity = this.world.getEntitiesByGroup('player')[0];
        var myPlayerTeam:number = (<TeamComponent>player.get(this.getComponent(TeamComponent))).team;
        var entityTeam:number = (<TeamComponent>entity.get(this.getComponent(TeamComponent))).team;

        if(entityTeam !== myPlayerTeam) {
            entity.remove(this.world.getRegisteredComponent(MinimapComponent));
        }
    }

    public onRemoved(entity:Entity) {


    }

    public process(entity:Entity, elapsed:number) {
        var spriteComp:SpriteComponent =
            <SpriteComponent> entity.get(this.getComponent(SpriteComponent));
        var miniMapComp:MinimapComponent = <MinimapComponent> entity.get(this.getComponent(MinimapComponent));

        var XandY = this.game.isometric.projector.projectXY(spriteComp.sprite.body.position);
        if(miniMapComp != null)
        {
            miniMapComp.sprite.x = this.miniMapSprite.x + 176 + (XandY.x - 1590) / 7.78;
            miniMapComp.sprite.y = this.miniMapSprite.y + (XandY.y - 1590) / 7.7;
        }

    }
}

