///<reference path="../base/System.ts"/>
///<reference path="../base/EcsWorld.ts"/>
///<reference path="../components/HealthComponent.ts"/>
///<reference path="../components/DamageComponent.ts"/>
///<reference path="../components/FiredByComponent.ts"/>
///<reference path="../components/LifeStatusComponent.ts"/>

class HealthSystem extends System {

    constructor(state:Phaser.State, game:Phaser.Game, world:EcsWorld) {
        super(state, game, world)
        this.registerComponent(this.getComponent(HealthComponent));
        this.registerComponent(this.getComponent(ProjectileCollisionComponent));
    }

    public onAdded(entity:Entity) {
        var healthComponent:HealthComponent = <HealthComponent> entity.get(this.getComponent(HealthComponent));
        // Might be used for regeneration timer
    }

    public process(entity:Entity) {
        var healthComponent:HealthComponent = <HealthComponent> entity.get(this.getComponent(HealthComponent));
        var projectileCollisionComponent:ProjectileCollisionComponent =
            <ProjectileCollisionComponent> entity.get(this.getComponent(ProjectileCollisionComponent));
        
        projectileCollisionComponent.bulletHits.forEach((bullet) => {
            this.removeHealth(healthComponent, entity, bullet);
        });
        projectileCollisionComponent.bulletHits = [];
    }

    public removeHealth(healthComponent:HealthComponent, entity:Entity, bullet:Entity) {
        var damageComponent:DamageComponent = <DamageComponent> bullet.get(this.getComponent(DamageComponent));
        var firedByComponent:FiredByComponent = <FiredByComponent> bullet.get(this.getComponent(FiredByComponent));
        var lifeStatus: LifeStatusComponent = <LifeStatusComponent> entity.get(this.getComponent(LifeStatusComponent));
        if (damageComponent.damage > 0 && lifeStatus.alive) {
            healthComponent.health -= damageComponent.damage;
            
        }

        if (healthComponent.health <= 0) {
            healthComponent.health = 0;

            // Checks who killed local player and signals NetworkSenderSystem to emit msg.
            var players:Entity[] = this.world.getEntitiesByGroup('networkPlayers');
            for (var i in players){
                    if (players[i].id == firedByComponent.entity.id){
                        var netWorkPlayer:NetworkPlayerComponent = <NetworkPlayerComponent> players[i].get(this.getComponent(NetworkPlayerComponent));
                        lifeStatus.killedBy = netWorkPlayer.socketId;
                        lifeStatus.justDied = true;
                        lifeStatus.playDeathAnim = true;
                        lifeStatus.alive = false;
                    }
            }
        }
        
        
    }

    public addHealth(healthComponent:HealthComponent, heal:number) {
        var healthDiff:number;
        healthDiff = healthComponent.maxHealth - healthComponent.health;
        if (healthDiff > heal) {
            healthComponent.health += heal;
            console.log("Player healed for: ", heal);
        }
        else {
            healthComponent.health = healthComponent.maxHealth;
            console.log("Player healed for: ", healthDiff);
        }
    }
}