///<reference path="../base/System.ts"/>
///<reference path="../base/EcsWorld.ts"/>
///<reference path="../components/PositionComponent.ts"/>
///<reference path="../components/DisplayComponent.ts"/>
///<reference path="../../client/app.ts"/>
///<reference path="../components/AnimationComponent.ts"/>
///<reference path="../components/SpriteComponent.ts"/>

import Pointer = Phaser.Pointer;
import Sprite = PIXI.Sprite; //TODO: Check if even necessary

class RenderingSystem extends System {
    sprites:Phaser.Plugin.Isometric.IsoSprite[];
    spriteGroup:Phaser.Group;

    constructor(state:Phaser.State, game:Phaser.Game, world:EcsWorld) {
        super(state, game, world);
        this.sprites = [];
        this.registerComponent(this.getComponent(SpriteComponent));
    }

    public onAdded(entity:Entity) {
        var spriteComp:SpriteComponent = <SpriteComponent> entity.get(this.getComponent(SpriteComponent));
        this.sprites[entity.id] = spriteComp.sprite;
    }
    public onRemoved(entity:Entity) {
        this.sprites[entity.id].destroy();
        this.sprites[entity.id] = undefined;
    }

    public process(entity:Entity, elapsed:number) {
        var spriteComp:SpriteComponent = <SpriteComponent> entity.get(this.getComponent(SpriteComponent));

       

    }
}