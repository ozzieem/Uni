/// <reference path = "../definitions/phaser.d.ts"/>
///<reference path="base/Entity.ts"/>
///<reference path="base/EcsWorld.ts"/>
///<reference path="components/PlayerControlComponent.ts"/>
///<reference path="components/VelocityComponent.ts"/>
///<reference path="components/PositionComponent.ts"/>
///<reference path="components/DisplayComponent.ts"/>
///<reference path="components/NetworkPlayerComponent.ts"/>
///<reference path="components/InputComponent.ts"/>
///<reference path="components/CameraTargetComponent.ts"/>
///<reference path="components/FiredByComponent.ts"/>
///<reference path="components/AnimationComponent.ts"/>
///<reference path="components/GroundTileComponent.ts"/>
///<reference path="components/SpriteComponent.ts"/>
///<reference path="../network/PlayerPositionMessage.ts"/>
///<reference path="components/ItemSpriteComponent.ts"/>
///<reference path="components/ItemAnimationComponent.ts"/>
///<reference path="components/LifespanComponent.ts"/>
///<reference path="components/ProjectileCollisionComponent.ts"/>
///<reference path="components/HealthComponent.ts"/>
///<reference path="components/SpawnComponent.ts"/>
///<reference path="components/InventoryComponent.ts"/>
///<reference path="components/ShadowComponent.ts"/>
///<reference path="components/DamageComponent.ts"/>
///<reference path="components/LifeStatusComponent.ts"/>
///<reference path="components/TeamComponent.ts"/>
///<reference path="components/MinimapComponent.ts"/>
///<reference path="systems/ShadowSystem.ts"/>
///<reference path="components/SoundComponent.ts"/>
///<reference path="components/FlushComponent.ts"/>


import Point3 = Phaser.Plugin.Isometric.Point3;
class Prefab {
    private world:EcsWorld;
    private myTeam:number;
    
    //TODO: Remove constant if possible
    private playerSpeed = 200;
    private game: Phaser.Game;

    public constructor(game: Phaser.Game, world:EcsWorld) {
        this.world = world;
        this.game = game;
    }

    private reUseSprite(x:number, y:number, z:number, key : string, phaserGroup : Phaser.Group) : Phaser.Plugin.Isometric.IsoSprite
    {
        var sprite: Phaser.Plugin.Isometric.IsoSprite;
        sprite = phaserGroup.getFirstDead();

        if(!sprite) {
            sprite = this.game.isometric.addIsoSprite(0,0,0,null,null);
        }
        else {
            sprite.body.reset(x, y, z);
        }

        sprite.key = key;
        sprite.loadTexture(key,0);
        sprite.visible = true;
        sprite.alive = true;
        sprite.isoZ = z;
        sprite.isoX = x;
        sprite.isoY = y;
        phaserGroup.add(sprite);
        return sprite;
    }

    public createPlayer(x:number, y:number, z:number, team:number, speed?:number):Entity {
        this.myTeam = team;

        var tint = ()=> { if(team === 0) return 0xff0000; return 0xb4d455;};
        var player = this.world.create();
        var sprite = this.reUseSprite(x, y, z, 'cube', this.game.state.getCurrentState().objectGroup);

        var itemSprite = this.reUseSprite(x,y,z,'swing',this.game.state.getCurrentState().objectGroup);
        itemSprite.anchor.setTo(0.75, 0.75);
        itemSprite.scale.setTo(.7,.7);
        itemSprite.angle += 45;

        var itemSprite2 = this.reUseSprite(x,y,z,'pew',this.game.state.getCurrentState().objectGroup);
        itemSprite2.anchor.setTo(0.5, 0.5);
        itemSprite2.scale.setTo(.7,.7);

        var minimapsprite = this.game.add.sprite(0,0,'testBullet');
        minimapsprite.tint = tint();
        minimapsprite.anchor.setTo(0.5, 0.5);
        minimapsprite.scale.setTo(1.25,1.25);


        sprite.anchor.setTo(0.5, 0.5);
        this.game.physics.isoArcade.enable(sprite);
        sprite.body.setSize(26,26,30,0,0,-24);
        sprite.body.collideWorldBounds = true;
        sprite.body.immovable = false;
        sprite.tint = tint();
        this.game.camera.follow(sprite);

        player.add(new PlayerControlComponent(speed || this.playerSpeed), this.world.getRegisteredComponent(PlayerControlComponent));
        player.add(new InputComponent(), this.world.getRegisteredComponent(InputComponent));
        player.add(new SpriteComponent(sprite), this.world.getRegisteredComponent(SpriteComponent));
        player.add(new VelocityComponent(), this.world.getRegisteredComponent(VelocityComponent));
        player.add(new CameraTargetComponent(), this.world.getRegisteredComponent(CameraTargetComponent));
        player.add(new AnimationComponent(), this.world.getRegisteredComponent(AnimationComponent));
        player.add(new LifeStatusComponent(), this.world.getRegisteredComponent(LifeStatusComponent));
        player.add(new HealthComponent(100), this.world.getRegisteredComponent(HealthComponent));
        player.add(new SpawnComponent(x, y, 5000), this.world.getRegisteredComponent(SpawnComponent));
        player.add(new SoundComponent(), this.world.getRegisteredComponent(SoundComponent));
        player.add(new ProjectileCollisionComponent(), this.world.getRegisteredComponent(ProjectileCollisionComponent));
        player.add(new InventoryComponent("rock", ["sword", "rock"]), this.world.getRegisteredComponent(InventoryComponent));
        player.add(new ItemSpriteComponent([itemSprite, itemSprite2], this.game.state.getCurrentState().objectGroup),
            this.world.getRegisteredComponent(ItemSpriteComponent));
        player.add(new ItemAnimationComponent(), this.world.getRegisteredComponent(ItemAnimationComponent));
        player.add(new TeamComponent(team), this.world.getRegisteredComponent(TeamComponent));
        player.add(new MinimapComponent(minimapsprite),this.world.getRegisteredComponent(MinimapComponent));
        this.world.addToGroup(player, 'player');

        return player;
    }

    public createNetworkPlayer(x:number, y:number, z:number, socketId: string, team:number, speed?:number):Entity {
        var tint = ()=> { if(team === 0) return 0xff0000; return 0xb4d455;};
        //Sprite info
        var player = this.world.create();
        var sprite = this.reUseSprite(x, y, z, 'cube', this.game.state.getCurrentState().objectGroup);
        this.game.state.getCurrentState().objectGroup.add(sprite);
        sprite.anchor.setTo(0.5, 0.5);
        this.game.physics.isoArcade.enable(sprite);
        sprite.body.setSize(26,26,30,0,0,-24);
        sprite.body.collideWorldBounds = true;
        sprite.body.immovable = false;
        sprite.tint = tint();

        var itemSprite = this.reUseSprite(x, y, z,'swing',this.game.state.getCurrentState().objectGroup);
        itemSprite.anchor.setTo(0.75, 0.75);
        itemSprite.angle += 45;
        
        var itemSprite2 = this.reUseSprite(x,y,z,'pew',this.game.state.getCurrentState().objectGroup);
        itemSprite2.anchor.setTo(0.5, 0.5);
        itemSprite2.scale.setTo(.7,.7);

        player.add(new PlayerControlComponent(speed || this.playerSpeed), this.world.getRegisteredComponent(PlayerControlComponent));
        player.add(new NetworkPlayerComponent(socketId), this.world.getRegisteredComponent(NetworkPlayerComponent));
        player.add(new SpriteComponent(sprite), this.world.getRegisteredComponent(SpriteComponent));
        player.add(new VelocityComponent(), this.world.getRegisteredComponent(VelocityComponent));
        player.add(new AnimationComponent(), this.world.getRegisteredComponent(AnimationComponent));
        player.add(new LifeStatusComponent(), this.world.getRegisteredComponent(LifeStatusComponent));
        //player.add(new HealthComponent(100), this.world.getRegisteredComponent(HealthComponent));
        player.add(new ProjectileCollisionComponent(), this.world.getRegisteredComponent(ProjectileCollisionComponent));
        player.add(new SpawnComponent(x, y, 5000), this.world.getRegisteredComponent(SpawnComponent));
        player.add(new SoundComponent(), this.world.getRegisteredComponent(SoundComponent));
        player.add(new InventoryComponent("rock", ["sword", "rock"]), this.world.getRegisteredComponent(InventoryComponent));
        player.add(new ItemSpriteComponent([itemSprite, itemSprite2], this.game.state.getCurrentState().objectGroup),
            this.world.getRegisteredComponent(ItemSpriteComponent));
        player.add(new ItemAnimationComponent(), this.world.getRegisteredComponent(ItemAnimationComponent));
        player.add(new TeamComponent(team), this.world.getRegisteredComponent(TeamComponent));

        var minimapsprite = this.game.add.sprite(0,0,'testBullet');
        minimapsprite.anchor.setTo(0.5, 0.5);
        minimapsprite.scale.setTo(0.90,0.90);
        minimapsprite.tint = tint();
        minimapsprite.alpha = 0.7;

        player.add(new MinimapComponent(minimapsprite),this.world.getRegisteredComponent(MinimapComponent));
        
        this.world.addToGroup(player, 'networkPlayers');
        return player;
    }
    
    public createRock(x:number, y:number, z:number, phaserGroup : Phaser.Group,
                        velocity:VelocityComponent, firedBy:Entity, lifeSpan:number, damage:number):Entity {
        var bullet = this.world.create();
        //var sprite = this.reUseSprite(x,y,z,'testBullet',phaserGroup);


        var shadowSprite = this.game.isometric.addIsoSprite(x,y,1,'shadow',null);
        shadowSprite.anchor.setTo(0.5,0.5);
        this.game.state.getCurrentState().shadowGroup.add(shadowSprite);


        var sprite = this.game.isometric.addIsoSprite(x,y,z,'smallRock',null);
        sprite.scale.setTo(1.5,1.5,1.5); // Sory tubz
        sprite.anchor.setTo(0.5, 0.5);
        this.game.physics.isoArcade.enable(sprite);

        sprite.checkWorldBounds = true;
        sprite.body.collideWorldBounds = true;
        sprite.body.allowGravity = true;
        sprite.body.drag = new Point3(100,100,0);
        phaserGroup.add(sprite);

        sprite.body.immovable = false;
        sprite.body.moves = true;


        bullet.add(new LifespanComponent(lifeSpan), this.world.getRegisteredComponent(LifespanComponent));
        bullet.add(new SpriteComponent(sprite), this.world.getRegisteredComponent(SpriteComponent));
        bullet.add(new FiredByComponent(firedBy), this.world.getRegisteredComponent(FiredByComponent));
        bullet.add(new DamageComponent(damage), this.world.getRegisteredComponent(DamageComponent));
        bullet.add(new ShadowComponent(shadowSprite),this.world.getRegisteredComponent(ShadowComponent));
        this.world.addToGroup(bullet, 'bullets');
        
        sprite.body.velocity.x = velocity.x;
        sprite.body.velocity.y = velocity.y;
        sprite.body.velocity.z = velocity.z;
        return bullet;
    }

    public createSwordHit(x:number, y:number, z:number, phaserGroup : Phaser.Group,
                        velocity:VelocityComponent, firedBy:Entity, lifeSpan:number, damage:number):Entity {
        var bullet = this.world.create();
        //var sprite = this.reUseSprite(x,y,z,'testBullet',phaserGroup);

        var sprite = this.game.isometric.addIsoSprite(x,y,z,'sword',null);
        sprite.anchor.setTo(0.5, 0.5);
        sprite.scale.set(2.3);
        this.game.physics.isoArcade.enable(sprite);
        sprite.checkWorldBounds = true;
        sprite.body.collideWorldBounds = true;
        sprite.body.allowGravity = true;
        sprite.body.immovable = false;
        sprite.body.moves = true
        sprite.visible = false;
        phaserGroup.add(sprite);

        bullet.add(new LifespanComponent(lifeSpan), this.world.getRegisteredComponent(LifespanComponent));
        bullet.add(new SpriteComponent(sprite), this.world.getRegisteredComponent(SpriteComponent));
        bullet.add(new FiredByComponent(firedBy), this.world.getRegisteredComponent(FiredByComponent));
        bullet.add(new DamageComponent(damage), this.world.getRegisteredComponent(DamageComponent));

        this.world.addToGroup(bullet, 'bullets');
        
        sprite.body.velocity.x = velocity.x;
        sprite.body.velocity.y = velocity.y;
        sprite.body.velocity.z = velocity.z;
        return bullet;
    }
    public createGroundTile(x: number, y: number, z: number, spriteCacheKey : string, groundType : string,
                            phaserGroup : Phaser.Group) {
        var tile = this.world.create();
        var sprite = this.reUseSprite(x,y,z,spriteCacheKey,phaserGroup); // 25 = sprite.height/2
        sprite.anchor.setTo(0.5,0.5);
        this.game.physics.isoArcade.enable(sprite);
        sprite.body.collideWorldBounds = false;
        sprite.body.allowGravity = false;

        tile.add(new PositionComponent(x,y,z), this.world.getRegisteredComponent(PositionComponent));
        tile.add(new DisplayComponent(spriteCacheKey), this.world.getRegisteredComponent(DisplayComponent));
        tile.add(new VelocityComponent(), this.world.getRegisteredComponent(VelocityComponent));
        tile.add(new GroundTileComponent(groundType), this.world.getRegisteredComponent(GroundTileComponent));
        this.world.addToGroup(tile, 'groundTile');
        return tile;
    }
    
    public createCollisionTile(x: number, y: number, z: number, spriteCacheKey : string, phaserGroup : Phaser.Group)
    {
        var tile = this.world.create();
        var sprite = this.reUseSprite(x,y,z,spriteCacheKey,phaserGroup);

        sprite.anchor.setTo(0.5, 0.5);
        this.game.physics.isoArcade.enable(sprite);
        sprite.body.collideWorldBounds = false;
        sprite.body.immovable = true;
        sprite.body.moves = false;

        tile.add(new PositionComponent(x,y,z), this.world.getRegisteredComponent(PositionComponent));
        tile.add(new DisplayComponent(spriteCacheKey), this.world.getRegisteredComponent(DisplayComponent));
        tile.add(new VelocityComponent(), this.world.getRegisteredComponent(VelocityComponent));
        tile.add(new SpriteComponent(sprite), this.world.getRegisteredComponent(SpriteComponent));
        this.world.addToGroup(tile, 'collisionTile');
        return tile;
    }

    // TODO: Player always moves behind the trees, problem with sort or player-sprite?
    public createFoliageTile(x: number, y: number, z: number, spriteCacheKey : string, phaserGroup : Phaser.Group)
    {
        var tile = this.world.create();
        var sprite = this.reUseSprite(x,y,z,spriteCacheKey,phaserGroup);


        sprite.anchor.setTo(0.5,0.5);
       
        tile.add(new PositionComponent(x,y,z), this.world.getRegisteredComponent(PositionComponent));
        tile.add(new DisplayComponent(spriteCacheKey), this.world.getRegisteredComponent(DisplayComponent));
        tile.add(new VelocityComponent(), this.world.getRegisteredComponent(VelocityComponent));
        this.world.addToGroup(tile, 'foliageTile');
        return tile;
    }
}
