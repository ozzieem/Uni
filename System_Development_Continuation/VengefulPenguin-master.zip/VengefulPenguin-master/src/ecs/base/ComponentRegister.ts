class ComponentRegister {
    private nextType: number;
    private ctors: any[];
    private types: number[];

    constructor() {
        this.nextType = 0;
        this.ctors = [];
        this.types = [];
    }

    public register(ctor: any): number {
        var i = this.ctors.indexOf(ctor);
        if (i < 0) {
            this.ctors.push(ctor);
            this.types.push(this.nextType++);
            return this.nextType-1;
        } else {
            return this.types[i];
        }
    }

    public get(ctor: any) {
        var i = this.ctors.indexOf(ctor);
        if (i < 0) {
            throw "Unknown type " + ctor;
        }
        return this.types[i];
    }
}