///<reference path="FastBitSet.ts"/>
///<reference path="BitSet.ts"/>
///<reference path="EcsWorld.ts"/>
class Entity {
    //Private member variables
    private world:EcsWorld;

    //Properties
    private _id:number;
    private _alive:boolean;
    private _waitingForRefresh:boolean;
    private _waitingForRemoval:boolean;
    private _componentMask:IBitSet;
    private _groupMask:IBitSet;
    private _systemMask:IBitSet;

    //Constructor
    constructor(world:EcsWorld, id:number) {
        this.world = world;
        this._id = id;
        
        this._alive = true;
        this._waitingForRefresh = false;
        this._waitingForRemoval = false;

        this._componentMask = this.world.MAX_COMPONENTS <= 32
            ? new FastBitSet()
            : new BitSet(this.world.MAX_COMPONENTS);

        this._groupMask = this.world.MAX_GROUPS <= 32
            ? new FastBitSet()
            : new BitSet(this.world.MAX_GROUPS);

        this._systemMask = this.world.MAX_SYSTEMS <= 32
            ? new FastBitSet()
            : new BitSet(this.world.MAX_SYSTEMS);
    }

    //Public methods
    public get(type:number):Component {
        return this.world.getComponent(this, type);
    }

    public add(component:Component, type:number) {
        this.world.addComponent(this, component, type);
    }

    public remove(type:number):void {
        this.world.removeComponent(this, type);
    }

    public clear():void {
        this.world.removeComponents(this);
    }

    public kill():void {
        this.world.kill(this);
    }

    //Getters and Setters
    get id():number {
        return this._id;
    }

    set id(value:number) {
        this._id = value;
    }

    get alive():boolean {
        return this._alive;
    }

    set alive(value:boolean) {
        this._alive = value;
    }

    get waitingForRemoval():boolean {
        return this._waitingForRemoval;
    }

    set waitingForRemoval(value:boolean) {
        this._waitingForRemoval = value;
    }

    get waitingForRefresh():boolean {
        return this._waitingForRefresh;
    }

    set waitingForRefresh(value:boolean) {
        this._waitingForRefresh = value;
    }

    get groupMask():IBitSet {
        return this._groupMask;
    }

    set groupMask(value:IBitSet) {
        this._groupMask = value;
    }

    get systemMask():IBitSet {
        return this._systemMask;
    }

    set systemMask(value:IBitSet) {
        this._systemMask = value;
    }

    get componentMask():IBitSet {
        return this._componentMask;
    }

    set componentMask(value:IBitSet) {
        this._componentMask = value;
    }

}