interface Component {
    
}
