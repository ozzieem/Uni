///<reference path="IBitSet.ts"/>
class FastBitSet implements IBitSet {
    private bits: number;
    
    constructor() {
        this.bits = 0;
    }

    public set(index: number, value: number): void {
        if (value) {
            this.bits |= 1 << index;
        } else {
            this.bits &= ~(1 << index);
        }
    }

    public get(index: number): boolean {
        return !!(this.bits & (1 << index));
    }

    public reset(): void {
        this.bits = 0;
    }

    public contains(other: FastBitSet): boolean {
        return (this.bits & other.bits) == other.bits;
    }
}