/// <reference path = "../../definitions/phaser.d.ts"/>
///<reference path="Entity.ts"/>
///<reference path="Component.ts"/>
///<reference path="EcsWorld.ts"/>
///<reference path="IBitSet.ts"/>
///<reference path="FastBitSet.ts"/>
///<reference path="BitSet.ts"/>

class System {
    //Private member variables
    protected game: Phaser.Game;
    protected state: Phaser.State;

    //Properties
    private _world: EcsWorld;
    private _componentMask: IBitSet;
    private _entities: Entity[];
    private _enabled: boolean;

    //Constructor
    constructor(state:Phaser.State, game: Phaser.Game, world: EcsWorld){
        this.game = game;
        this._world = world;
        this.state = state;
        this._entities = [];
        this._enabled = true;

        this._componentMask = this._world.MAX_COMPONENTS <= 32
            ? new FastBitSet()
            : new BitSet(this._world.MAX_COMPONENTS);
    }

    //Public methods that should not be overridden
    public registerComponent(type: number): void {
        this._componentMask.set(type, 1);
    }

    public update(elapsed: number): void {
        if (this.enabled) {
            this.onBegin();
            this.processEntities(this._entities, elapsed);
            this.onEnd();
        }
    }

    public addEntity(entity:Entity): void {
        if (this._entities.indexOf(entity) < 0) {
            this._entities.push(entity);
            this.onAdded(entity);
        }
    }

    public removeEntity(entity: Entity): void {

        var i = this._entities.indexOf(entity);
        if (i >= 0) {
            this._entities[i] = this._entities[this._entities.length - 1];
            this._entities.pop();
            this.onRemoved(entity);
        }
        if (this._entities.length === 0)
        {
            this._entities = [];
        }

    }

    public getComponent(component: Component): number {
        return this._world.getRegisteredComponent(component);
    }

    //Public methods that can/should be overridden
    public processEntities(entities: Entity[], elapsed: number): void {
        var i = 0;
        var n = entities.length;
        for (i = 0; i < n; i++) {
            this.process(entities[i], elapsed);
        }
    }
    
    public process(entity: Entity, elapsed: number) {};

    public onRegistered(): void {}

    public onBegin(): void {}

    public onEnd(): void {}

    public onAdded(entity: Entity): void {}

    public onRemoved(entity: Entity): void {}


    //Getters and Setters
    get enabled():boolean {
        return this._enabled;
    }

    set enabled(value:boolean) {
        this._enabled = value;
    }

    get world():EcsWorld {
        return this._world;
    }

    set world(value:EcsWorld) {
        this._world = value;
    }

    get componentMask():IBitSet {
        return this._componentMask;
    }

    set componentMask(value:IBitSet) {
        this._componentMask = value;
    }
}