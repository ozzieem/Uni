interface IBitSet {
    set(index: number, value: number): void;

    get(index: number): boolean;

    reset(): void;

    contains(other: IBitSet): boolean;
}