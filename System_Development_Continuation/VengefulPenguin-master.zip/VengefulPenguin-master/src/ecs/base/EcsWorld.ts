///<reference path="ComponentRegister.ts"/>
///<reference path="Component.ts"/>
///<reference path="../Prefab.ts"/>
///<reference path="Entity.ts"/>
///<reference path="System.ts"/>



class EcsWorld {
    //Definitions
    MAX_COMPONENTS = 32;
    MAX_GROUPS = 32;
    MAX_SYSTEMS = 32;
    
    //Private member variables
    private game:Phaser.Game;
    private componentRegister:ComponentRegister;
    
    //Properties
    private _systems:System[];
    private _nextEntityID:number;
    private _nextGroupId:number;
    private _groups:Entity[][];
    private _groupIDs:{};
    private _alive:Entity[];
    private _dead:Entity[];
    private _removed:Entity[];
    private _refreshed:Entity[];
    private _componentBags:Component[][];
    private _prefab: Prefab;
    
    //Constructor
    constructor(game:Phaser.Game) {
        this.game = game;
        this.componentRegister = new ComponentRegister();
        this._systems = [];
        this._nextEntityID = 0;
        this._nextGroupId = 0;
        this._groups = [];
        this._groupIDs = {};
        this._alive = [];
        this._dead = [];
        this._removed = [];
        this._refreshed = [];
        this._componentBags = [];
        this._prefab = new Prefab(this.game, this);
    }

    //Private methods
    private _refreshEntity(entity:Entity):void {
        // Unset refresh flag
        entity.waitingForRefresh = false;

        var i = 0;
        var n = this._systems.length;
        for (; i < n; i++) {
            var contains = entity.systemMask.get(i);
            var interested = entity.componentMask.contains(this._systems[i].componentMask);

            if (contains && !interested) {
                // Remove entity from the system

                this._systems[i].removeEntity(entity);
                entity.systemMask.set(i, 0);
            } else if (!contains && interested) {
                // Add entity to the system
                this._systems[i].addEntity(entity);
                entity.systemMask.set(i, 1);
            }
        }
    }

    private _removeEntity(entity:Entity):void {
        if (entity.alive) {
            // Unset removal flag
            entity.waitingForRemoval = false;

            // Murder the entity!
            entity.alive = false;

            // Remove from alive entities by swapping with the last entity
            this._alive[this._alive.indexOf(entity)] = this._alive[this._alive.length - 1];
            this._alive.pop();

            // Add to dead entities
            this._dead.push(entity);

            // Reset component mask
            entity.componentMask.reset();

            // Remove from groups
            this.removeFromGroups(entity);

            // Refresh entity
            this._refreshEntity(entity);
        }
    }
    
    //Public methods
    public getRegisteredComponent(component:Component):number {
        return this.componentRegister.get(component);
    }

    public registerComponent(component:Component):number {
        return this.componentRegister.register(component);
    }

    public registerSystem(system:System): void {
        if (this._systems.indexOf(system) >= 0) {
            throw "Cannot register a system twice";
        }

        this._systems.push(system);

        system.world = this;
        system.onRegistered();
    }

    public create():Entity {
        var entity;
        if (this._dead.length > 0) {
            // Revive entity
            entity = this._dead.pop();
            entity.alive = true;
        } 
        else {
            entity = new Entity(this, this._nextEntityID++);
        }

        this._alive.push(entity);
        return entity;
    }

    public kill(entity:Entity):void {
        if (!entity.waitingForRemoval) {
            entity.waitingForRemoval = true;
            this._removed.push(entity);
        }
    }

    public refresh(entity:Entity):void {
        if (!entity.waitingForRefresh) {
            entity.waitingForRefresh = true;
            this._refreshed.push(entity);
        }
    }

    public update(elapsed:number):void {
        // Process entities
        this.loopStart();
        for (var i = 0; i < this._systems.length; i++) {
            this._systems[i].update(elapsed);
        }
    }

    public loopStart():void {
        var i;

        // Process entities queued for removal
        for (i = this._removed.length; i--;) {
            this._removeEntity(this._removed[i]);
        }

        this._removed.length = 0;
        var oldRefreshedLength:number = this._refreshed.length;
        // Process entities queued for refresh
        for (i = this._refreshed.length; i--;) {

            this._refreshEntity(this._refreshed[i]);
        }

        if(this._refreshed.length > oldRefreshedLength){
            var tempRefreshed: Entity[] = [];
            for(var i:any = oldRefreshedLength; i < this._refreshed.length; i++) {
                tempRefreshed.push(this._refreshed[i]);
            }
            this._refreshed = tempRefreshed;
        }
        else {
            this._refreshed.length = 0;
        }

    }

    public addToGroup(entity:Entity, groupName:string):void {
        var group;
        var groupID = this._groupIDs[groupName];
        if (groupID === undefined) {
            groupID = this._groupIDs[groupName] = this._nextGroupId++;
            group = this._groups[groupID] = <Entity[]>[];
        } else {
            group = this._groups[groupID];
        }

        if (!entity.groupMask.get(groupID)) {
            entity.groupMask.set(groupID, 1);
            group.push(entity);
        }
    }

    public removeFromGroup(entity:Entity, groupName:string):void {
        var groupID = this._groupIDs[groupName];
        if (groupID !== undefined) {
            var group = this._groups[groupID];
            if (entity.groupMask.get(groupID)) {
                entity.groupMask.set(groupID, 0);
                group[group.indexOf(entity)] = group[group.length - 1];
                group.pop();
            }
        }
    }

    public removeFromGroups(entity:Entity):void {
        for (var groupID = this._nextGroupId; groupID--;) {
            if (entity.groupMask.get(groupID)) {
                var group = this._groups[groupID];
                group[group.indexOf(entity)] = group[group.length - 1];
                group.pop();
            }
        }

        entity.groupMask.reset();
    }

    public getEntitiesByGroup(groupName:string):Entity[] {
        var groupID = this._groupIDs[groupName];
        return groupID !== undefined ? this._groups[groupID] : [];
    }

    public isInGroup(entity:Entity, groupName:string):boolean {
        var groupID = this._groupIDs[groupName];
        return groupID !== undefined && entity.groupMask.get(groupID);
    }

    public getComponent(entity:Entity, type:number):Component {
        if (entity.componentMask.get(type)) {
            return this._componentBags[entity.id][type];
        }

        return null;
    }

    public addComponent(entity:Entity, component:Component, type:number):void {
        entity.componentMask.set(type, 1);

        this._componentBags[entity.id] || (this._componentBags[entity.id] = []);
        this._componentBags[entity.id][type] = component;

        this.refresh(entity);
    }

    public removeComponent(entity:Entity, type:number) {
        entity.componentMask.set(type, 0);
        this.refresh(entity);
    }

    public removeComponents(entity:Entity):void {
        entity.componentMask.reset();
        this.refresh(entity);
    }
    
    //Getters and Setters
    get prefab():Prefab {
        return this._prefab;
    }

    set prefab(value:Prefab) {
        this._prefab = value;
    }
}