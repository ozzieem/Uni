///<reference path="IBitSet.ts"/>
class BitSet implements IBitSet {
    length: number;
    words: Array<number>;
    constructor(size: number) {
        var length = this.length = Math.ceil(size / 32);
        this.words = new Array(this.length);
        while(length--){
            this.words[length] = 0;
        }
    }

    public set(index: number, value: number): void {
        var wordOffset = index / 32 | 0;
        var bitOffset = index - wordOffset * 32;

        if (value) {
            this.words[wordOffset] |= 1 << bitOffset;
        }
        else {
            this.words[wordOffset] &= ~(1 << bitOffset);
        }
    }

    public get(index: number): boolean {
        var wordOffset = index / 32 | 0;
        var bitOffset = index - wordOffset * 32;

        return !!(this.words[wordOffset] & (1 << bitOffset));
    }

    public reset(): void {
        var words = this.words;
        var i = this.length;

        while (i--) {
            this.words[i] = 0;
        }
    }

    public contains(other: BitSet): boolean {
        var i = this.length;

        if (i != other.length) {
            return false;
        }

        while (i--) {
            if ((this.words[i] & other.words[i]) != other.words[i]) {
                return false;
            }
        }

        return true;
    }
}