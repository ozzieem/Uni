/// <reference path="../base/Component.ts"/>

interface IItemAnim{
    speed: number;
    frames: number[];
}

class ItemAnimationComponent implements Component {

    public animations: { [id: string] : IItemAnim; } = {};
    private _currentName:string;

    constructor() {
    }

    get currentName():string {
        return this._currentName;
    }

    set currentName(value:string) {
        this._currentName = value;
    }
}