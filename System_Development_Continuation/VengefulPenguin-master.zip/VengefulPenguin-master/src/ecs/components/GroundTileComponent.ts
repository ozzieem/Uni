/**
 * Created by vsven on 2016-04-22.
 */
///<reference path="../base/Component.ts"/>
class GroundTileComponent implements Component {
    private _tileType: string;

    constructor(tileType: string) {
        this._tileType = tileType;
    }

    get tileType():string {
        return this._tileType;
    }

    set tileType(value:string) {
        this._tileType = value;
    }

}