///<reference path="../base/Component.ts"/>


class DamageComponent implements Component{
    damage: number;

    constructor(damage:number){
        this.damage = damage;
    }
}