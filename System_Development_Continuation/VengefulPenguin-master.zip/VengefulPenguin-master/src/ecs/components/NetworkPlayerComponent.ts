///<reference path="../base/Component.ts"/>
///<reference path="../../network/PlayerMovementMessage.ts"/>

class NetworkPlayerComponent implements Component {
    get socketId():string {
        return this._socketId;
    }

    set socketId(value:string) {
        this._socketId = value;
    }
    private _socketId: string;

    public prevSyncX: number;
    public prevSyncY: number;

    public prevPosX: number;
    public prevPosY: number;

    public currPosX: number;
    public currPosY: number;

    constructor(socketId: string) {
        this._socketId = socketId;
    }
}