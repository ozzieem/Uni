///<reference path="../base/Component.ts"/>

class CameraTargetComponent implements Component {
    constructor() {}
}