///<reference path="../base/Component.ts"/>

class SpawnComponent implements Component{

    private _spawnX: number;
    private _spawnY: number;
    private _spawnTime: number;
    private _startTime: number;

    constructor(spawnX: number, spawnY: number, spawnTime: number){
        this._spawnX = spawnX;
        this._spawnY = spawnY;
        this._spawnTime = spawnTime;
        this._startTime = -1;
    }

    get positionX(): number{
        return this._spawnX;
    }

    set positionX(Value: number) {
        this._spawnX = Value;
    }

    get positionY(): number{
        return this._spawnY;
    }

    set positionY(Value: number){
        this._spawnY = Value;
    }

    get startTime():number {
        return this._startTime;
    }

    set startTime(value:number) {
        this._startTime = value;
    }

    get spawnTime(): number {
        return this._spawnTime;
    }

    set spawnTime(value: number){
        this._spawnTime = value;
    }
}