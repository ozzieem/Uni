/// <reference path="../base/Component.ts"/>
///<reference path="../../definitions/phaser.d.ts"/>
///<reference path="../../definitions/phaser.plugin.isometric.d.ts"/>

class SpriteComponent implements Component {
    public sprite : Phaser.Plugin.Isometric.IsoSprite;
    
    constructor(sprite : Phaser.Plugin.Isometric.IsoSprite)
    {
        this.sprite = sprite;
    }
}