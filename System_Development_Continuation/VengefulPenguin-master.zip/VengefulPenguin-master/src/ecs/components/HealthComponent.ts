///<reference path="../base/Component.ts"/>


class HealthComponent implements Component{
    private _health: number;
    private _maxHealth: number;
    private _timer: Phaser.Timer;

    constructor(health:number){
        this._health = health;
        this._maxHealth = health;
    }

    get health():number{
        return this._health;
    }

    set health(Value:number){
        this._health = Value;
    }
    
    get maxHealth():number{
        return this._maxHealth;
    }

    set maxHealth(maxHealth:number){
        this._maxHealth = maxHealth;
    }

    get timer():Phaser.Timer{
        return this._timer;
    }

    set timer(timer:Phaser.Timer){
        this._timer = timer;
    }
}