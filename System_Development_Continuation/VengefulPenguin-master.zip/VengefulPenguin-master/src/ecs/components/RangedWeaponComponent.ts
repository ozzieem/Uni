/// <reference path="../base/Component.ts"/>

class RangedWeaponComponent implements Component {

}
