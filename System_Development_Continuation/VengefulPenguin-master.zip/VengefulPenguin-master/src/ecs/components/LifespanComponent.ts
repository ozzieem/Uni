/// <reference path="../base/Component.ts"/>

class LifespanComponent implements Component {
    private _lifetime: number;
    private _startTime: number;

    constructor(lifetime: number) {
        this._lifetime = lifetime;
        this._startTime = 0;
    }

    get lifetime():number {
        return this._lifetime;
    }

    set lifetime(value:number) {
        this._lifetime = value;
    }

    get startTime():number {
        return this._startTime;
    }

    set startTime(value:number) {
        this._startTime = value;
    }


}