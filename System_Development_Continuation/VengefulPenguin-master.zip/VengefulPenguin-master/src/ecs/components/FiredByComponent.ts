/// <reference path="../base/Component.ts"/>
///<reference path="../base/Entity.ts"/>

class FiredByComponent implements Component {
    private _entity:Entity;

    constructor(entity:Entity) {
        this._entity = entity;
    }

    get entity():Entity {
        return this._entity;
    }

    set entity(value:Entity) {
        this._entity = value;
    }
}


