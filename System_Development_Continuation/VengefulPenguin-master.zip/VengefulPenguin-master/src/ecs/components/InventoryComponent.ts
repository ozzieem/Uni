/// <reference path="../base/Component.ts"/>

class InventoryComponent implements Component {

    private _activeItem: string;
    private _lastActiveItem: string;
    private _inventory: string[];
    private _cooldownDict: {[item:string] : number};

    constructor(activeItem: string, inventory: string[]) {
        this._activeItem = activeItem;
        this._lastActiveItem = null;
        this._inventory = inventory;
        this._cooldownDict = {};
    }
    get inventory():string[] {
        return this._inventory;
    }

    set inventory(value: string[]) {
        this._inventory = value;
    }
    get activeItem():string {
        return this._activeItem;
    }

    set activeItem(value:string) {
        this._activeItem = value;
    }
    get cooldownDict(): {[item:string] : number} {
        return this._cooldownDict;
    }

    set cooldownDict(value: {[item:string] : number}) {
        this._cooldownDict = value;
    }
    get lastActiveItem():string {
        return this._lastActiveItem;
    }

    set lastActiveItem(value:string) {
        this._lastActiveItem = value;
    }
}