///<reference path="../base/Component.ts"/>
///<reference path="../base/Entity.ts"/>

class ProjectileCollisionComponent implements Component {
    private _isColliding: boolean;
    bulletHits: Entity[];

    constructor() {
        this._isColliding = false;
        this.bulletHits = [];
    }

    get isColliding() {
        return this._isColliding;
    }

    set isColliding(value:boolean) {
        this._isColliding = value;
    }
}
