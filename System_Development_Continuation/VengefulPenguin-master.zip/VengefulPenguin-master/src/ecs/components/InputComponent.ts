///<reference path="../base/Component.ts"/>
///<reference path="../../definitions/phaser.d.ts"/>

class InputComponent implements Component {

    private _left:number;
    private _right:number;
    private _up:number;
    private _down:number;
    private _fire:number;
    private _item1:number;
    private _item2:number;
    private _scores:number;

    get up():number {
        return this._up;
    }

    set up(value:number) {
        this._up = value;
    }

    get right():number {
        return this._right;
    }

    set right(value:number) {
        this._right = value;
    }

    get left():number {
        return this._left;
    }

    set left(value:number) {
        this._left = value;
    }

    get down():number {
        return this._down;
    }

    set down(value:number) {
        this._down = value;
    }

    get fire():number {
        return this._fire;
    }

    set fire(value:number) {
        this._fire = value;
    }

    get item1():number {
        return this._item1;
    }

    set item1(value:number) {
        this._item1 = value;
    }

    get item2():number {
        return this._item2;
    }

    set item2(value:number) {
        this._item2 = value;
    }

    get scores():number {
        return this._scores;
    }

    set scores(value:number){
        this._scores = value;
    }

    constructor() {
        this._left = Phaser.Keyboard.A;
        this._right = Phaser.Keyboard.D;
        this._up = Phaser.Keyboard.W;
        this._down = Phaser.Keyboard.S;
        this._fire = Phaser.Keyboard.SPACEBAR;
        this.item1 = Phaser.Keyboard.ONE;
        this.item2 = Phaser.Keyboard.TWO;
        this._scores = Phaser.Keyboard.TAB;
    }
}
