/**
 * Created by v01d on 2016-04-21.
 */
/// <reference path="../base/Component.ts"/>
interface IAnim {
    speed: number;
    frames: number[];
}
    
class AnimationComponent implements Component {
    
    public animations: { [id: string] : IAnim; } = {};
    private _currentName:string;
    
    constructor() {
    }

    get currentName():string {
        return this._currentName;
    }

    set currentName(value:string) {
        this._currentName = value;
    }
}