/**
 * Created by vsven on 2016-05-20.
 */
/// <reference path="../base/Component.ts"/>
///<reference path="../../definitions/phaser.d.ts"/>
///<reference path="../../definitions/phaser.plugin.isometric.d.ts"/>

class MinimapComponent implements Component {
    public sprite : Phaser.Sprite;
    constructor(sprite : Phaser.Sprite)
    {
        this.sprite = sprite;
    }
}