///<reference path="../base/Component.ts"/>
///<reference path="../../definitions/phaser.d.ts"/>

//TODO: add weapon state and mouse direction.

enum MovementState {
    N,
    NW,
    NE,
    S,
    SW,
    SE,
    E,
    W,
    NONE
}

enum ItemSlot{
    ONE,
    TWO,
    THREE,
    FOUR,
    FIVE,
    NONE = -1
}

enum LookDirection{
    N,
    NW,
    NE,
    S,
    SW,
    SE,
    E,
    W
}

class PlayerControlComponent implements Component {
    public hasFired: boolean;
    public hasSwitchedItem: boolean;
    public movementState:MovementState;
    public lookDirection:LookDirection;
    public speed:number;
    public isFiring:boolean;
    public cursor: Phaser.Plugin.Isometric.Point3;
    public origin: Phaser.Plugin.Isometric.Point3;
    public itemSlot: number;
    public angleOfPointer: number;
    public showScores: boolean;
    constructor(speed:number) {
        this.hasFired = false;
        this.hasSwitchedItem = false;
        this.speed = speed;
        this.isFiring = false;
        this.movementState = MovementState.NONE;
        this.lookDirection = LookDirection.N;
        this.cursor = new Phaser.Plugin.Isometric.Point3();
        this.origin = new Phaser.Plugin.Isometric.Point3();
        this.itemSlot = ItemSlot.NONE;
        this.showScores = false;
    }


}