/// <reference path="../base/Component.ts"/>

class MeleeWeaponComponent implements Component {

}
