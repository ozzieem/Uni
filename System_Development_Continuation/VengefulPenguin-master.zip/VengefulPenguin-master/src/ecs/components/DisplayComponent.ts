///<reference path="../base/Component.ts"/>

class DisplayComponent implements Component {
    private _sprite: string;

    constructor(sprite: string) {
        this._sprite = sprite;
    }

    get sprite():string {
        return this._sprite;
    }

    set sprite(value:string) {
        this._sprite = value;
    }

}


