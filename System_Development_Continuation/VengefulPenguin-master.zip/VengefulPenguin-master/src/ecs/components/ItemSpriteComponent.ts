/// <reference path="../base/Component.ts"/>
///<reference path="../../definitions/phaser.d.ts"/>
///<reference path="../../definitions/phaser.plugin.isometric.d.ts"/>

class ItemSpriteComponent implements Component {
    public sprite : Phaser.Plugin.Isometric.IsoSprite[];
    public phaserGroup : Phaser.Group;

    constructor(sprite : Phaser.Plugin.Isometric.IsoSprite[], phaserGroup : Phaser.Group)
    {
        this.sprite = sprite;
        this.phaserGroup = phaserGroup;
        this.sprite.forEach(function(item){
            item.visible = false;
        });
    }
}