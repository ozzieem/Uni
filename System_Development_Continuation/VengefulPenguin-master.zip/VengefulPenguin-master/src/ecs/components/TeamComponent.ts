/// <reference path="../base/Component.ts"/>

class TeamComponent implements Component {

    private _team: number;

    constructor(team: number) {
        this._team = team;
    }

    get team():number {
        return this._team;
    }

    set team(value:number) {
        this._team = value;
    }
}
