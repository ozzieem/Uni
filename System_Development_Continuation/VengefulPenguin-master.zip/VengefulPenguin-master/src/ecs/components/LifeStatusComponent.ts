///<reference path="../base/Component.ts"/>
class LifeStatusComponent implements Component {
    public alive: boolean;
    public killedBy: string;
    public justDied: boolean;
    public justSpawned: boolean;
    public playDeathAnim: boolean;
// Tells AnimationSystem when to play animation
    constructor(){
        this.alive = true;
        this.killedBy = "";
        this.justDied = false;
        this.justSpawned = false;
        this.playDeathAnim = false;
    };
}