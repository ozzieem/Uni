///<reference path="../base/Component.ts"/>

class SoundComponent implements Component {

    public soundList:{[soundString:string]:Phaser.Point};
    constructor(){
        this.soundList = {};
    }



    addSound(soundString:string, point:Phaser.Point){
        this.soundList[soundString] = point;
    }
}