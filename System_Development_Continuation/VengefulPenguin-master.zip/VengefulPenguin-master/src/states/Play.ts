///<reference path="../definitions/phaser.d.ts"/>
///<reference path="../ecs/systems/PlayerControlSystem.ts"/>
///<reference path="../ecs/systems/NetworkSenderSystem.ts"/>
///<reference path="../ecs/systems/PlayerInputSystem.ts"/>
///<reference path="../ecs/systems/RenderingSystem.ts"/>
///<reference path="../ecs/systems/RemotePlayerInputSystem.ts"/>
///<reference path="../ecs/systems/AnimationSystem.ts"/>
///<reference path="../ecs/systems/CollisionSystem.ts"/>
///<reference path="../ecs/systems/ItemAnimationSystem.ts"/>
///<reference path="../ecs/base/EcsWorld.ts"/>
///<reference path="../objects/HUD.ts"/>
///<reference path="../client/MapImporter.ts"/>
///<reference path="../ecs/components/CameraTargetComponent.ts"/>
///<reference path="../network/NetworkMessageBuffer.ts"/>
///<reference path="../network/TimerMessage.ts"/>
///<reference path="../ecs/systems/LifespanSystem.ts"/>
///<reference path="../ecs/systems/HealthSystem.ts"/>
///<reference path="../ecs/systems/SpawnSystem.ts"/>
///<reference path="../ecs/systems/HUDSystem.ts"/>
///<reference path="../ecs/systems/InventorySystem.ts"/>
///<reference path="../ecs/systems/MeleeWeaponSystem.ts"/>
///<reference path="../ecs/systems/RangedWeaponSystem.ts"/>
///<reference path="../ecs/systems/PlayerPhysicsSystem.ts"/>
///<reference path="../ecs/systems/MinimapSystem.ts"/>
///<reference path="../ecs/components/TeamComponent.ts"/>
///<reference path="../ecs/systems/ShadowSystem.ts"/>
///<reference path="../ecs/components/TeamComponent.ts"/>
///<reference path="../ecs/components/ShadowComponent.ts"/>
///<reference path="../ecs/components/LifeStatusComponent.ts"/>
///<reference path="../ecs/components/MinimapComponent.ts"/>
///<reference path="../ecs/systems/SoundSystem.ts"/>
///<reference path="../ecs/components/FlushComponent.ts"/>

import ColorStepFilter = PIXI.ColorStepFilter;

var debug = false;
class Play extends Phaser.State {
    timerString: string;
    hudGroup:Phaser.Group;
    groundGroup : Phaser.Group;
    objectGroup : Phaser.Group;
    shadowGroup : Phaser.Group;
    miniMapGroup : Phaser.Group;
    miniMapPlayerGroup : Phaser.Group;
    groundOverlayGroup : Phaser.Group;
    filterGroup : Phaer.Group;
    players:{[socketID:string]:Entity};
    syncBuffer:NetworkMessageBuffer;
    attackBuffer:NetworkMessageBuffer;
    itemSwitchBuffer:NetworkMessageBuffer;
    ecsWorld:EcsWorld;
    scoreKeeper: ScoreKeeper;
    initPlayers: {[socketID:string]:PlayerData};
    initPlayersArray: PlayerData[];
    mySocket:string;
    timer: MatchTimer;

    private battleMusic: any;

    preload() {
        console.log("[State] Play");
        this.syncBuffer = new NetworkMessageBuffer();
        this.attackBuffer = new NetworkMessageBuffer();
        this.itemSwitchBuffer = new NetworkMessageBuffer();
        this.game.stage.backgroundColor = "#333333";
        this.ecsWorld = new EcsWorld(this.game);
        var mapImporter = new MapImporter(this.game);
        mapImporter.LoadImages();
        this.players = {};
        this.scoreKeeper = new ScoreKeeper();
        this.timerString = "Clock";
        this.timer.start();
    }

    init(players:PlayerData[], mySocket:string, timer:TimerMessage) {
        
        this.initPlayersArray = players;
        //Convert array to dictionary
        this.initPlayers = {};
        for (var i in players) {
            this.initPlayers[players[i].id] = players[i];
        }
        
        this.mySocket = mySocket;
        this.timer = new MatchTimer(timer.startMinute, timer.startSecond);
    }

    create() {
        //Create groups
        this.groundGroup = this.game.add.group();
        this.groundOverlayGroup = this.game.add.group();
        this.shadowGroup = this.game.add.group();
        this.objectGroup = this.game.add.group();
        this.hudGroup = this.game.add.group();
        
        //Need to have this for mini map. Rendering order
        this.miniMapGroup = this.game.add.group();
        this.miniMapPlayerGroup = this.game.add.group();

        //Ground dirt
        var groundDirt = this.game.isometric.addIsoSprite(1590/2, 1590/2, 0, 'groundOverlay', null);
        this.groundOverlayGroup.add(groundDirt);
        groundDirt.anchor.set(0.5,0.5);
        groundDirt.blendMode = PIXI.blendModes.MULTIPLY;
        
        //Screen overlay
        this.filterGroup = this.game.add.group();
        var filter = this.game.add.sprite(this.game.width/2, this.game.height/2, 'overlay', 0, this.filterGroup);
        filter.anchor.set(0.5,0.5);
        filter.fixedToCamera = true;
        filter.blendMode = PIXI.blendModes.MULTIPLY;

        for (var index in this.initPlayers){
            this.scoreKeeper.addNewPlayer(this.initPlayers[index].id);
        }

        this.ecsWorld.registerComponent(PlayerControlComponent);
        this.ecsWorld.registerComponent(PositionComponent);
        this.ecsWorld.registerComponent(VelocityComponent);
        this.ecsWorld.registerComponent(DisplayComponent);
        this.ecsWorld.registerComponent(InputComponent);
        this.ecsWorld.registerComponent(NetworkPlayerComponent);
        this.ecsWorld.registerComponent(CameraTargetComponent);
        this.ecsWorld.registerComponent(FiredByComponent);
        this.ecsWorld.registerComponent(AnimationComponent);
        this.ecsWorld.registerComponent(GroundTileComponent);
        this.ecsWorld.registerComponent(SpriteComponent);
        this.ecsWorld.registerComponent(HealthComponent);
        this.ecsWorld.registerComponent(SoundComponent);
        this.ecsWorld.registerComponent(DamageComponent);
        this.ecsWorld.registerComponent(SpawnComponent);
        this.ecsWorld.registerComponent(LifeStatusComponent);
        this.ecsWorld.registerComponent(ProjectileCollisionComponent);
        this.ecsWorld.registerComponent(ItemAnimationComponent);
        this.ecsWorld.registerComponent(ItemSpriteComponent);
        this.ecsWorld.registerComponent(LifespanComponent);
        this.ecsWorld.registerComponent(InventoryComponent);
        this.ecsWorld.registerComponent(RangedWeaponComponent);
        this.ecsWorld.registerComponent(MeleeWeaponComponent);
        this.ecsWorld.registerComponent(TeamComponent);
        this.ecsWorld.registerComponent(ShadowComponent);
        this.ecsWorld.registerComponent(MinimapComponent);

        this.ecsWorld.registerSystem(new RemotePlayerInputSystem(this, this.game, this.ecsWorld));
        this.ecsWorld.registerSystem(new PlayerInputSystem(this, this.game, this.ecsWorld));
        this.ecsWorld.registerSystem(new PlayerControlSystem(this, this.game, this.ecsWorld));
        this.ecsWorld.registerSystem(new InventorySystem(this, this.game, this.ecsWorld));
        this.ecsWorld.registerSystem(new SpawnSystem(this, this.game, this.ecsWorld));
        this.ecsWorld.registerSystem(new LifespanSystem(this, this.game, this.ecsWorld));
        this.ecsWorld.registerSystem(new AnimationSystem(this, this.game, this.ecsWorld));
        this.ecsWorld.registerSystem(new CollisionSystem(this, this.game, this.ecsWorld));
        this.ecsWorld.registerSystem(new MeleeWeaponSystem(this, this.game, this.ecsWorld));
        this.ecsWorld.registerSystem(new RangedWeaponSystem(this, this.game, this.ecsWorld));
        this.ecsWorld.registerSystem(new ItemAnimationSystem(this, this.game, this.ecsWorld));
        this.ecsWorld.registerSystem(new HealthSystem(this, this.game, this.ecsWorld));
        this.ecsWorld.registerSystem(new PlayerPhysicsSystem(this, this.game, this.ecsWorld));
        this.ecsWorld.registerSystem(new HUDSystem(this, this.game, this.ecsWorld));
        this.ecsWorld.registerSystem(new ShadowSystem(this, this.game,this.ecsWorld));
        this.ecsWorld.registerSystem(new SpawnSystem(this, this.game, this.ecsWorld));
        this.ecsWorld.registerSystem(new SoundSystem(this, this.game, this.ecsWorld));
        this.ecsWorld.registerSystem(new RenderingSystem(this, this.game, this.ecsWorld));
        this.ecsWorld.registerSystem(new NetworkSenderSystem(this, this.game, this.ecsWorld));
        this.ecsWorld.registerSystem(new MinimapSystem(this, this.game, this.ecsWorld));

        this.game.time.advancedTiming = true;
        this.game.physics.startSystem(Phaser.Plugin.Isometric.ISOARCADE);

        var mapImporter = new MapImporter(this.game);
        mapImporter.SpawnMap(this.groundGroup,this.objectGroup,this.objectGroup, this.ecsWorld);
        this.game.iso.anchor.setTo(0.5,0.5);
        this.game.physics.isoArcade.gravity.z = -300;

        this.initPlayersArray.forEach((player, i, players)=> {
            var spawnY = ()=> {
                if (player.team === 0) {
                    return this.game.world.bounds.height / 2.0 - 200;
                }
                else {
                    return i * 100 + 40;
                }
            };
            var spawnX = ()=> {
                if (player.team === 0) {
                    return i * 100 + 40;
                }
                else {
                    return this.game.world.bounds.width / 2.0 - 200;
                }
            };

            if (player.id === this.mySocket) {
                this.ecsWorld.prefab.createPlayer(spawnX(), spawnY(), 0, player.team);
            }
            else {
                this.ecsWorld.prefab.createNetworkPlayer(spawnX(), spawnY(), 0, player.id, player.team);
            }
        });

        this.battleMusic = this.game.add.audio('battleMusic');
        this.playBattleMusic();
    }

    update() {
        this.ecsWorld.update(this.game.time.physicsElapsed);
        this.game.physics.isoArcade.collide(this.objectGroup);
        this.game.iso.topologicalSort(this.objectGroup);
        this.updateTimer();
    }

    render() {
        this.game.debug.context.clearRect(0, 0, this.game.width, this.game.height);
        this.game.debug.text(this.game.time.fps || '--', 2, 14, "#00ff00");
        if (debug) {
           this.groundGroup.forEach((object) => {
               this.game.debug.body(object, null, true, false);
           }, this, false);
           this.objectGroup.forEach((tile) => {
               this.game.debug.body(tile, null, true, false);
           }, this, false);
        }
    }

    private updateTimer() {
        if(this.timer.seconds < 10) {
            this.timerString = this.timer.minutes.toString() + ':0' + this.timer.seconds.toString();
        }
        else {
            this.timerString = this.timer.minutes.toString() + ':' + this.timer.seconds.toString();
        }
    }

    onDeletePlayer(socketID:string) {
        this.players[socketID].kill();
        delete this.players[socketID];
    }

    public onGameOver() {
        this.timer.reset();
        this.battleMusic.mute = true;
        this.game.state.start('GameOver', true,false,this.initPlayersArray,this.mySocket,this.scoreKeeper);
    }

    private playBattleMusic(){
        this.battleMusic.play(null, null, 0.3);
    }
}