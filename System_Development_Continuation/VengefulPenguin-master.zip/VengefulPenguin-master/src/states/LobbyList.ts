///<reference path="../definitions/phaser.d.ts"/>

import {LobbyData} from "../network/LobbyData";
import {LobbyListMessage} from "../network/LobbyListMessage";
class LobbyList extends Phaser.State {
    public rooms:LobbyData[];
    public roomSlots:{ [roomID:number]:Phaser.Text} = {};
    private maxRooms:number = 4;

    preload() {
        console.log("[State] LobbyList");
        this.game.stage.backgroundColor = "#b4d455";
        window.vengefulPenguin.socket.socket.emit('getLobbies');
    }

    create() {
        this.rooms = [];
        // this.roomSlots = [];
        this.createBackground();
        this.createButton(this.game.width / 3, this.game.height / 2 - 50, 'Create Game', this.onCreateGame);
        this.createButton(this.game.width / 3, this.game.height / 2 + 50, 'Quit', this.onMainMenu);

        for (var i = 0; i < this.maxRooms; ++i) {
            var roomBtn = this.createButton(this.game.width / 2 + 200, this.game.height / 8 * 2 + i * 50, "-", ()=> {
            });
            this.roomSlots[i] = roomBtn;
        }
    }

    update() {
        this.drawRoomList();
    }

    private createButton(x:number, y:number, text:string, event:Function) {
        var button = this.game.add.text(Math.round(x), Math.round(y), text, {
            font: '40px Rouge Script',
            fill: '#271a0c'
        });
        this.setFlooredCenterAnchor(button);
        button.position.floor();
        button.inputEnabled = true;
        button.input.useHandCursor = true;
        button.events.onInputUp.add(event, this);
        return button;
    }

    private createBackground() {
        var background = this.game.add.sprite(0, 0, 'background', 0);
        background.height = this.game.height;
        background.width = this.game.width;
    }

    public onLobbyList(rooms:LobbyListMessage) {
        this.rooms = rooms.list;
        this.rooms.forEach((room)=> {
            this.roomSlots[room.id].events.onInputUp.add(()=> this.onJoinRoom(room), this);
        });
        console.log("[INFO] Available Games", this.rooms);
    }

    public onPlayerJoinRoom(room:LobbyData) {
        console.log("[DEBUG] PlayerJoinRoom:", room);
        this.rooms[room.id].nrPlayers = room.nrPlayers;
        this.rooms[room.id].id = room.id;
        this.rooms[room.id].state = room.state;
    }

    public onPlayerLeaveRoom(room:LobbyData) {
        console.log("[DEBUG] PlayerLeaveRoom:", room);
        this.rooms[room.id].nrPlayers = room.nrPlayers;
        this.rooms[room.id].id = room.id;
        this.rooms[room.id].state = room.state;
    }

    public setRoomState(room:LobbyData) {
        this.rooms[room.id].state = room.state;
    }

    public onGameAdded(room:LobbyData) {
        this.rooms.push(room);
        this.roomSlots[room.id].text = room.id + "";
        this.roomSlots[room.id].events.onInputUp.add(()=> this.onJoinRoom(room), this);
    }

    private onCreateGame() {
        this.game.state.start('CreateGame');
        console.log("[INFO] LobbyList -> Create Game");
    }

    private onJoinRoom(room:LobbyData) {
        var index = this.rooms.indexOf(room, 0);
        if (index > -1) {
            if (this.rooms[index].nrPlayers < this.rooms[index].size) {
                window.vengefulPenguin.socket.socket.emit('joinRoom', this.rooms[index].id);
                console.log("[DEBUG] Joined game", this.rooms[index].id);
                this.game.state.start('Lobby', true, false, this.rooms[index].size);
            }
        }
    }

    public onRoomRemoved(roomID:number) {
        this.rooms.forEach((room, i)=> {
            if (room.id === roomID) {
                console.log("[DEBUG] OnRoomRemoved: Removing room", roomID);
                this.rooms.splice(i,1);
                // TODO: Perhaps make rooms a dictionary ?
                this.roomSlots[roomID].setText("-");
                console.log("[DEBUG] Roomslots:", this.roomSlots);
            }
        });
    }

    private onMainMenu() {
        this.game.state.start('MainMenu');
    }

    public drawRoomList() {
        this.rooms.forEach((room)=> {
            if (room !== null) {
                var roomString:string;
                if(room.nrPlayers === room.size || room.state === 1 || room.state === 2) {
                    this.roomSlots[room.id].inputEnabled = false;
                    this.roomSlots[room.id].input.useHandCursor = false;
                    this.roomSlots[room.id].alpha = 0.5;
                    if(room.state === 1 || room.state === 2) {
                        roomString = this.generateRoomString(room.state) + "[" + room.nrPlayers + "/" + room.size + "]";
                    }
                    else {
                        roomString = "Full [" + room.nrPlayers + "/" + room.size + "]";
                    }
                }
                else {
                    this.roomSlots[room.id].inputEnabled = true;
                    this.roomSlots[room.id].input.useHandCursor = true;
                    this.roomSlots[room.id].alpha = 1;
                    roomString = this.generateRoomString(room.state) + " [" + room.nrPlayers + "/" + room.size + "]";
                }

                this.roomSlots[room.id].setText(roomString);
                this.roomSlots[room.id].fill = '#271a0c';
                this.roomSlots[room.id].x = this.game.width - this.game.width / 4;
            }
        });
    }

    private generateRoomString(roomstate:number) {
        switch (roomstate) {
            case 0:
                return "Open";
            case 1:
            case 2:
                return "Closed";
        }
    }

    private setFlooredCenterAnchor(text:Phaser.Text) {
        text.anchor.x = Math.round(text.width * 0.5) / text.width;
        text.anchor.y = Math.round(text.height * 0.5) / text.height;
    }
}