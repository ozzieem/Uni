///<reference path="../definitions/phaser.d.ts"/>

import {PlayerData} from "../network/PlayerData";
import {PlayerDataMessage} from "../network/PlayerDataMessage";
import {ScoreKeeper} from "../ScoreKeeper";
class GameOver extends Phaser.State {
    public readyBtn: Phaser.Text;
    public nrReadyPlayers:number;
    public mySocket:string;
    public players:PlayerData[];
    public PlayerDataFromGame:PlayerData[];
    public roomSize:number = 6;
    private scoreKeeperDict:ScoreKeeper;

    preload() {
        console.log("[State] GameOver");
        this.game.stage.backgroundColor = "#b4d455";
        window.vengefulPenguin.socket.socket.emit('loadGameOver');
    }

     init(players:PlayerData[], mySocket:string, score:ScoreKeeper) {
        this.PlayerDataFromGame = players;
        this.mySocket = mySocket;
         this.scoreKeeperDict = score;
     }
    
    create() {
        this.players = [];
        this.nrReadyPlayers = 0;
        this.createBackground();
        this.createGameOverText();
        this.readyBtn = this.createButton(this.game.width / 2, this.game.height-this.game.height/4, 'Ready', this.onReadyBtn);
        this.createButton(this.game.width / 2, this.game.height - this.game.height/6, 'Return to main menu', this.onQuitBtn);

        //Find out which team won
        var result = this.whichTeamWon(this.PlayerDataFromGame,this.scoreKeeperDict);
        console.log(result);

        //Print out which team won
        this.printWinningTeam(result);

        //Calculate and sort the score, print on screen
        this.printScore(this.PlayerDataFromGame,this.scoreKeeperDict,this.mySocket);

    }

    update() {
        this.readyBtn.setText("Ready (" + this.nrReadyPlayers + "/" + this.players.length + ")");
    }

    private createBackground() {
        var background = this.game.add.sprite(0, 0, 'background', 0);
        background.height = this.game.height;
        background.width = this.game.width;
    }

    private createGameOverText() {
        var gameOverText = this.game.add.text(this.game.width / 2, this.game.height /10, 'Game over',
            {font: '45px Rouge Script', fill: '#271a0c'});
        this.setFlooredCenterAnchor(gameOverText);
    }

    private createButton(x:number, y:number, text:string, event:Function) {
        var button = this.game.add.text(Math.round(x), Math.round(y), text, {font: '34px Rouge Script', fill: '#271a0c'});
        this.setFlooredCenterAnchor(button);
        button.inputEnabled = true;
        button.input.useHandCursor = true;
        button.events.onInputUp.add(event, this);
        return button;
    }

    public onPlayerLeft(socketID:string) {
        var i = 0;
        for(var player in this.players) {
            if(this.players[player].id === socketID) {
                this.players.splice(i);
            }
            i++;
        }
        console.log("Removed player", socketID, "from room.");
    }

    public onLoadGameOver(players: PlayerDataMessage, socketID:string, roomSize:number) {
        this.players = players.list;
        this.mySocket = socketID;
        this.roomSize = roomSize;
    }

    private onReadyBtn(){
        window.vengefulPenguin.socket.socket.emit('playerReady');
        this.readyBtn.inputEnabled = false;
        this.readyBtn.input.useHandCursor = false;
        this.readyBtn.alpha = 0.2;
    }

    public onReady(playerid: string) {
        for(var player in this.players) {
            if(this.players[player].id === playerid && !this.players[player].ready) {
                this.players[player].ready = true;
            }
        }
    }

    public onRematch() {
        console.log("[DEBUG] Starting rematch with", this.nrReadyPlayers, "players");
        this.nrReadyPlayers = 0;
        this.game.state.start('Lobby', true, false, this.roomSize);
    }

    private onQuitBtn(){
        window.vengefulPenguin.socket.socket.emit('playerQuit');
        console.log("[DEBUG] Player", this.mySocket, "quit to main menu");
        this.game.state.start('MainMenu');
    }

    public setReadyPlayers(readyPlayers: number) {
        this.nrReadyPlayers = readyPlayers;
    }
    
    private setFlooredCenterAnchor(text:Phaser.Text) {
        text.anchor.x = Math.round(text.width * 0.5) / text.width;
        text.anchor.y = Math.round(text.height * 0.5) / text.height;
    }

    private whichTeamWon(players: PlayerData[], scorekeeper: ScoreKeeper) : string
    {
        var teamRedScore = 0;
        var teamGreenScore = 0;

        //For every player in players list
        for(var index in players)
        {
            var socketID = players[index].id;

            if(players[index].team == 0)
            {

                teamRedScore += scorekeeper.frags[socketID];
            }
            else
            {
                teamGreenScore += scorekeeper.frags[socketID];
            }
        }

        if(teamRedScore > teamGreenScore)
        {
            return "red";
        }
        else if(teamGreenScore > teamRedScore)
        {
            return "green";
        }
        else
        {
            return "draw";
        }
    }

    private printWinningTeam(gameResult:string)
    {
        var winningTeamText;

        if(gameResult == "red")
        {
            winningTeamText = this.game.add.text(this.game.width / 2, this.game.height / 5, 'Red team won!',
                {font: '36px Rouge Script', fill: '#271a0c'});
        }

        else if(gameResult == "green")
        {
            winningTeamText = this.game.add.text(this.game.width / 2, this.game.height / 5, 'Green team won!',
                {font: '36px Rouge Script', fill: '#271a0c'});
        }

        else
        {
            winningTeamText = this.game.add.text(this.game.width / 2, this.game.height / 5, 'Its a draw!',
                {font: '36px Rouge Script', fill: '#271a0c'});
        }

        winningTeamText.anchor.setTo(0.5);
    }

    private decideSpacing(myString:string) : string
    {
        var emptySpaces = "";

        for(var i = myString.length; i < 10; i++)
        {
            emptySpaces = emptySpaces.concat(" ");
        }

        return emptySpaces;
    }

    private printScore(players:PlayerData[],score:ScoreKeeper,mySocket:string)
    {
        var scoreArray = [];

        //Gather information
        for(var index in players)
        {
            var scoreRow = {};
            var socketID = players[index].id;

            scoreRow.name = players[index].name;
            scoreRow.team = players[index].team;
            scoreRow.frags = score.frags[socketID];
            scoreRow.deaths = score.deaths[socketID];
            scoreArray.push(scoreRow);
        }

        // Sort the score array by frags
        scoreArray.sort(function(a,b){return b.frags-a.frags});

        console.log(scoreArray);

        var verticalDistanceOffset = 0;

        var header = this.game.add.text(this.game.width/2-this.game.width/8, this.game.height/3+verticalDistanceOffset, "Name",
            {font: '28px Rouge Script', fill: '#271a0c'});
        header.anchor.setTo(0.5,0.5);

        var header2 = this.game.add.text(this.game.width/2, this.game.height/3+verticalDistanceOffset, "Frags",
            {font: '28px Rouge Script', fill: '#271a0c'});
        header2.anchor.setTo(0.5,0.5);


        var header3 = this.game.add.text(this.game.width/2+ this.game.width/8, this.game.height/3+verticalDistanceOffset, "Deaths",
            {font: '28px Rouge Script', fill: '#271a0c'});
        header3.anchor.setTo(0.5,0.5);
        
        verticalDistanceOffset += 50;
        // Print the array, put a special notion on the score that is yours
        console.log(scoreArray);
        for(var i = 0; i < scoreArray.length; i++)
        {
            //Build the string
            var stringRow = i.toString().concat(". ");
            stringRow = scoreArray[i].name.concat(this.decideSpacing(scoreArray[i].name));
            stringRow = stringRow.concat(scoreArray[i].frags.toString().concat(this.decideSpacing(scoreArray[i].frags.toString())));
            stringRow = stringRow.concat(scoreArray[i].deaths.toString().concat(this.decideSpacing(scoreArray[i].deaths.toString())));

            //Print the string
            if(scoreArray[i].team == 0)
            {
                var name = this.game.add.text(this.game.width/2- this.game.width/8, this.game.height/3+verticalDistanceOffset, scoreArray[i].name,
                    {font: '28px Rouge Script', fill: '#ff3333'});
                name.anchor.setTo(0.5,0.5);
                name.stroke = "#000000";
                name.strokeThickness = 1;
                var frags = this.game.add.text(this.game.width/2, this.game.height/3+verticalDistanceOffset, scoreArray[i].frags.toString(),
                    {font: '28px Rouge Script', fill: '#ff3333'});
                frags.anchor.setTo(0.5,0.5);
                frags.stroke = "#000000";
                frags.strokeThickness = 1;
                var deaths = this.game.add.text(this.game.width/2 + this.game.width/8, this.game.height/3+verticalDistanceOffset, scoreArray[i].deaths.toString(),
                    {font: '28px Rouge Script', fill: '#ff3333'});
                deaths.anchor.setTo(0.5,0.5);
                deaths.stroke = "#000000";
                deaths.strokeThickness = 1;

            }

            else
            {
                var name = this.game.add.text(this.game.width/2- this.game.width/8, this.game.height/3+verticalDistanceOffset, scoreArray[i].name,
                    {font: '28px Rouge Script', fill: '#85a329'});
                name.anchor.setTo(0.5,0.5);
                name.stroke = "#000000";
                name.strokeThickness = 1;

                var frags = this.game.add.text(this.game.width/2, this.game.height/3+verticalDistanceOffset, scoreArray[i].frags.toString(),
                    {font: '28px Rouge Script', fill: '#85a329'});
                frags.anchor.setTo(0.5,0.5);
                frags.stroke = "#000000";
                frags.strokeThickness = 1;
                var deaths = this.game.add.text(this.game.width/2 + this.game.width/8, this.game.height/3+verticalDistanceOffset, scoreArray[i].deaths.toString(),
                    {font: '28px Rouge Script', fill: '#85a329'});
                deaths.anchor.setTo(0.5,0.5);
                deaths.stroke = "#000000";
                deaths.strokeThickness = 1;
            }
            verticalDistanceOffset += 34;
        }
    }

}