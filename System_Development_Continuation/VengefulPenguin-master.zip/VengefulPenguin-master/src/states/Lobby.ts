///<reference path="../definitions/phaser.d.ts"/>

import {PlayerDataMessage} from "../network/PlayerDataMessage";
import {PlayerData} from "../network/PlayerData";
import {TimerMessage} from "../network/TimerMessage";


class Lobby extends Phaser.State {
    public background:Phaser.Sprite;
    private playerSlots:Phaser.Text[];
    public readyBtn:Phaser.Text;
    public infoText: Phaser.Text;
    public nrReadyPlayers:number;
    public mySocket:string;
    public players:PlayerData[];
    public roomSize:number = 6;
    private lobbyMusic: any;

    preload() {
        console.log("[State] Lobby");
        this.game.stage.backgroundColor = "#85a329";
        window.vengefulPenguin.socket.socket.emit('joinedLobby');
    }

    init(roomSize:number) {
        this.roomSize = roomSize;
    }

    create() {
        this.nrReadyPlayers = 0;
        this.playerSlots = [];
        this.players = [];
        this.background = this.game.add.sprite(0, 0, 'background', 0);
        this.background.height = this.game.height;
        this.background.width = this.game.width;

        this.readyBtn = this.createButton(
            this.game.width - this.game.width / 8,
            this.game.height - this.game.height / 8,
            'Ready', 40,
            this.onReadyBtn);

        this.createButton(this.game.width / 8, this.game.height - this.game.height / 8, 'Leave', 35, this.onLeaveLobby);

        var redTeam = this.createButton(this.game.width / 4, this.game.height / 8, 'Join Team Red', 40, this.onJoinA);
        redTeam.fill = '#271a0c';
        redTeam.stroke = '#ff3333';
        redTeam.strokeThickness = 1;

        var greenTeam = this.createButton(this.game.width - this.game.width / 4, this.game.height / 8, 'Join Team Green', 40, this.onJoinB);
        greenTeam.fill = '#271a0c';
        greenTeam.stroke = '#85a329';
        greenTeam.strokeThickness = 1;

        for (var i = 0; i < this.roomSize; ++i) {
            this.playerSlots.push(this.game.add.text(Math.floor(this.game.width / 2), Math.floor(this.game.height / 8 * 2 + i * 50),
                "-", {font: '34px Rouge Script'}));
            this.setFlooredCenterAnchor(this.playerSlots[i]);
        }

        this.lobbyMusic = this.game.add.audio('lobbyMusic');
        this.playLobbyMusic();
    }

    update() {
        this.drawPlayerList();
        this.updateReadyButton();
    }

    private updateReadyButton() {
        this.readyBtn.setText("Ready (" + this.nrReadyPlayers + "/" + this.players.length + ")");

        for (var player in this.players) {
            if (this.players[player].id === this.mySocket) {
                if (this.players[player].team !== -1 && !this.players[player].ready) {
                    this.readyBtn.inputEnabled = true;
                    this.readyBtn.input.useHandCursor = true;
                    this.readyBtn.alpha = 1;
                }
                else {
                    this.readyBtn.inputEnabled = false;
                    this.readyBtn.input.useHandCursor = false;
                    this.readyBtn.alpha = 0.5;
                }
            }
        }
    }

    private createButton(x:number, y:number, text:string, size:number, event:Function) {
        var button = this.game.add.text(Math.round(x), Math.round(y), text, {font: size + 'px Rouge Script', fill: '#271a0c'});
        this.setFlooredCenterAnchor(button);
        button.inputEnabled = true;
        button.input.useHandCursor = true;
        button.events.onInputUp.add(event, this);
        return button;
    }


    private onReadyBtn() {
        //See how many players there are in each team and if there are any undecided players
        var teamOne = 0;
        var teamTwo = 0;
        var undecided = 0;

        IterateEveryPlayer:
            for (var player in this.players) {
                switch (this.players[player].team) {
                    case 0:
                        teamOne++;
                        break;
                    case 1:
                        teamTwo++;
                        break;
                    case -1:
                        undecided++;
                        break IterateEveryPlayer;
                }
            }

        for (var player in this.players) {
            if (this.players[player].id === this.mySocket && this.players[player].team !== -1
                && teamOne !== 0 && teamTwo !== 0) {
                window.vengefulPenguin.socket.socket.emit('playerReady');
                this.readyBtn.inputEnabled = false;
                this.readyBtn.input.useHandCursor = false;
                this.readyBtn.alpha = 0.5;
            }
        }

        // if(teamOne === 0 || teamTwo === 0) {
        //     this.infoText = this.game.add.text(this.game.world.centerX, this.game.world.centerY + 200,
        //         'Invalid teams', {font: '24px Calibri', fill: '#fff'});
        // }
        // else{
        //     this.infoText.setText("");
        // }
    }

    public onReady(playerid:string) {
        for (var player in this.players) {
            if (this.players[player].id === playerid && !this.players[player].ready) {
                console.log("[DEBUG] Lobby players: ", this.players);
                console.log("[DEBUG] Player ready:", this.players[player].id);
                this.players[player].ready = true;
            }
        }
        this.lobbyMusic.mute = true;
    }

    public onStartGame(timer:TimerMessage) {
        this.nrReadyPlayers = 0;
        for (var player in this.players) {
            this.players[player].ready = false;
        }
        this.game.state.start('Play', true, false, this.players, this.mySocket, timer);
        this.lobbyMusic.mute = true;
    }

    public onLeaveBtn() {
    }

    public onLeaveLobby() {
        window.vengefulPenguin.socket.socket.emit('leaveRoom');
        this.game.state.start('LobbyList');
        this.lobbyMusic.mute = true;
    }

    public onPlayerList(players:PlayerDataMessage) {
        this.players = players.list;
    }

    public onPlayerJoined(player:PlayerData) {
        this.players.push(player);
        this.playerSlots[this.players.length - 1].text = player.name;
    }

    public onPlayerLeft(socketID:string) {
        console.log('[INFO] Player', socketID, "left the room.")
        console.log("[DEBUG] Removing player", socketID, "from room.");
        this.players.forEach((player, i, players)=> {
            if (player.id === socketID) {
                this.playerSlots[this.players.length - 1].setText("-");
                players.splice(i,1);
            }
        });
    }

    private onJoinA() {
        window.vengefulPenguin.socket.socket.emit('joinTeam', 0);
    }

    private onJoinB() {
        window.vengefulPenguin.socket.socket.emit('joinTeam', 1);
    }

    public onTeamUpdate(player:PlayerData) {
        this.players.forEach((p, i, players)=> {
            if (p.id === player.id) {
                this.players[i].team = player.team;
                this.players[i].ready = false;
            }
        });
        console.log("[INFO]", player.id, "joined team", player.team);
    }

    public setMySocket(playerSocket:string) {
        this.mySocket = playerSocket;
    }

    public setReadyPlayers(readyPlayers: number) {
        this.nrReadyPlayers = readyPlayers;
    }

    public drawPlayerList() {
        this.players.forEach((player, i)=> {
            this.playerSlots[i].setText(player.name);

            if (player.team === 0) {
                this.playerSlots[i].fill = '#ff3333';
                this.playerSlots[i].x = Math.floor(this.game.width / 4);
            }
            else if (player.team === 1) {
                this.playerSlots[i].fill = '#85a329';
                this.playerSlots[i].x = Math.floor(this.game.width - this.game.width / 4);
            }
            else {
                this.playerSlots[i].fill = '#271a0c';
                this.playerSlots[i].x = Math.floor(this.game.width / 2);
            }
            if (player.id === this.mySocket) {
                //	Stroke color and thickness
                this.playerSlots[i].stroke = '#000000';
                this.playerSlots[i].strokeThickness = 1;
            }
        });
    }

    private setFlooredCenterAnchor(text:Phaser.Text) {
        text.anchor.x = Math.round(text.width * 0.5) / text.width;
        text.anchor.y = Math.round(text.height * 0.5) / text.height;
    }

    private playLobbyMusic(){
        this.lobbyMusic.play(null, null, 0.7);
    }
}
