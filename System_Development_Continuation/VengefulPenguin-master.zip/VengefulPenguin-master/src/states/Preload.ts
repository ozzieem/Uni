///<reference path="../definitions/phaser.d.ts"/>
///<reference path="../client/MapImporter.ts"/>

class Preload extends Phaser.State {
    preload() {
        console.log("[State] Preload");

        var background = this.game.add.sprite(0, 0, 'background', 0);
        background.height = this.game.height;
        background.width = this.game.width;

        // var logo = this.add.sprite(0, 0, 'preloadLogo');    // Optional logo
        // logo.alpha = 0.5;

        var loadingText = this.game.add.text(this.game.world.centerX, this.game.world.centerY - 25, 'Loading',
            {fill: '#271a0c', font: '24px Rouge Script'});
        loadingText.anchor.setTo(0.5);

        var loadingBar = this.add.sprite(this.game.world.centerX - 125, this.game.world.centerY, 'loadingBar');
        this.load.setPreloadSprite(loadingBar);

        //this.game.load.image('cube', 'assets/sprites/cube.png'); // Load cube image
        this.game.load.spritesheet('cube', '../../assets/sprites/player/player.png', 128, 128);
        this.game.load.spritesheet('swing', '../../assets/sprites/item/swing@0,6x.png', 120, 90);
        this.game.load.spritesheet('shoot', '../../assets/sprites/shoot.png', 200, 200);
        this.game.load.spritesheet('pew', '../../assets/sprites/pew.png', 128, 128);
        this.game.load.image('grass', '../../assets/sprites/grass.png'); // Load ground image
        this.game.load.image('testBullet', '../../assets/sprites/Test/smallRock.png'); // Load Bullet
        this.game.load.image('smallRock', '../../assets/sprites/Test/smallRock.png'); // Load Bullet
        this.game.load.image('sword', '../../assets/sprites/Test/smallRock.png'); // Load Bullet
        this.game.load.image('shadow','../../assets/sprites/shadow.png');

        // Images for Lobby
        this.game.load.image('bg', '../../assets/sprites/lobby/oldPaper.jpg'); // Load Background image
        this.game.load.image('TeamFrames', '../../assets/sprites/Test/LobbyTeamFrames.png'); // Load TeamFrames image
        this.game.load.image('PlayerFrame', '../../assets/sprites/Lobby/LobbyPlayerFrame.png'); // Load PlayerFrame image
        this.game.load.image('ChatMapFrame', '../../assets/sprites/Lobby/LobbyChatMapFrame.png'); // Load ChatMapFrame image
        this.game.load.spritesheet('TempAvat', '../../assets/sprites/Lobby/TempAvatars.png', 146, 146);

        this.game.load.image('Team1', '../../assets/sprites/Test/CA.png');
        this.game.load.image('Team2', '../../assets/sprites/Test/DP.png');
        
        // Sounds
        this.game.load.audio('throwing', '../../assets/sounds/throwingSound.mp3');
        this.game.load.audio('bodyHit', '../../assets/sounds/bodyhit1.mp3');
        this.game.load.audio('swordSwing', '../../assets/sounds/swordSwing.mp3');
        this.game.load.audio('lobbyMusic', '../../assets/sounds/lobbyMusic.mp3');
        this.game.load.audio('swordHit', '../../assets/sounds/bloodHit.mp3');
        this.game.load.audio('battleMusic', '../../assets/sounds/battleMusic.mp3');

        var mapImporter = new MapImporter(this.game);
        mapImporter.LoadJSON('final_map_v2.json');

        this.game.load.json('items', '../../assets/Items/Items.json'); //Load item stats file to cache
        this.game.load.image('minimap','../../assets/maps/minimaps/forest_minimap.png');
        this.game.load.image('papyrusRoll', '../../assets/sprites/papyrusRoll.png');
        this.game.load.image('overlay', '../../assets/sprites/overlay.png');
        this.game.load.image('groundOverlay', '../../assets/sprites/groundDirt.png');
        
    }

    create() {
        this.game.sound.decode('lobbyMusic');
        this.game.sound.decode('battleMusic')
        this.game.sound.setDecodedCallback(['lobbyMusic', 'battleMusic'], ()=> this.game.state.start('MainMenu'), this);
    }

    update() {
    }

    render() {
    }
}