///<reference path="../definitions/phaser.d.ts"/>

class MainMenu extends Phaser.State {

    public background:Phaser.Sprite;
    public playButton:Phaser.Text;
    private font = 'Rouge Script';
    private fontSize = '128px';

    preload() {
        console.log("[State] Main Menu");
        this.game.stage.backgroundColor = "#b4d455";
    }
    create() {
        this.background = this.game.add.sprite(0,0,'background',0);
        this.background.height = this.game.height;
        this.background.width = this.game.width;

        this.createPlayButton();
    }
    update() {
    }
    render() {
    }

    private createPlayButton() {
        this.playButton = this.game.add.text(Math.round(this.game.width / 2), Math.round(this.game.height / 2), 'Play',
            {font: this.fontSize + ' ' + this.font, fill: '#271a0c'});
        this.setFlooredCenterAnchor(this.playButton);
        this.playButton.inputEnabled = true;
        this.playButton.input.useHandCursor = true;
        this.playButton.events.onInputUp.add(this.startPreLobby, this);
    }

    private startPreLobby() {
        this.destroyMenu();
        this.game.state.start('LobbyList');
    }

    private destroyMenu() {
        this.playButton.destroy();
        this.background.destroy();
    }

    private setFlooredCenterAnchor(text:Phaser.Text) {
        text.anchor.x = Math.round(text.width * 0.5) / text.width;
        text.anchor.y = Math.round(text.height * 0.5) / text.height;
    }
}
