/**
 * Created by v01d on 2016-04-15.
 */
/**
 * Created by v01d on 2016-04-15. Fnizzz
 */
///<reference path="../definitions/phaser.d.ts"/>

class OldLobby extends Phaser.State {

    avatarSelection: number[];
    avatarGroup: Phaser.Group;

    preload() {
        console.log("[State] OldLobby");
        this.game.stage.backgroundColor = "#b4d455";
    }
    create() {

        this.avatarSelection = [3,1,14,2,24,8];

        this.loadTeamAvatars();
        this.loadStaticImages();
        this.loadPlayerAvatars();
        this.game.time.events.loop(Phaser.Timer.SECOND * 5, this.loadPlayerAvatars, this);
        this.loadPlayerText();
        this.showCharSelection();
    }
    update() {

    }
    render() {
        this.game.debug.text(this.avatarSelection.toString(), 10, 10);
    }
    loadTeamAvatars() {
        var team1 = this.game.add.sprite(-20, 0, 'Team1');
        team1.width = 400;
        team1.height = 80;

        var team2 = this.game.add.sprite(420, 0, 'Team2');
        team2.width = 450;
        team2.height = 80;
    }
    loadStaticImages() {
        var bg = this.game.add.sprite(0,0,'bg',0);
        bg.height = this.game.height;
        bg.width = this.game.width;


        var teamFrame = this.game.add.sprite(0, 10, 'TeamFrames', 0);
        teamFrame.height = this.game.height / 10;
        teamFrame.width = this.game.width - 20;
        teamFrame.x = (this.game.width / 2) - (teamFrame.width / 2); // Changes pic to show im middle of screen
        //teamFrame.y = this.game.height / 100;


        for(var i = 0; i < 3; i++)
        {
            for(var j = 0; j < 2; j++)
            {
                var playerFrame = this.game.add.sprite(this.game.width / 50 ,(this.game.height / 5.7) + (i * this.game.height / 6.5), 'PlayerFrame', 0);
                playerFrame.height = this.game.height / 7.5;
                playerFrame.width = this.game.width / 4;
                if(j == 1)
                {
                    playerFrame.x = this.game.width - this.game.width / 50 - playerFrame.width;
                }
            }
        }

        var chatFrame = this.game.add.sprite(this.game.width / 50, this.game.height - (this.game.height / 3), 'ChatMapFrame', 0);
        chatFrame.height = this.game.height / 3.5;
        chatFrame.width = this.game.width / 2.5;

        var mapFrame = this.game.add.sprite(this.game.width / 2, this.game.height / 2, 'ChatMapFrame', 0);
        mapFrame.height = this.game.height / 3.5;
        mapFrame.width = this.game.width / 2.5;

        mapFrame.anchor.setTo(1, 0);
        mapFrame.x = 49 * this.game.width / 50;
        mapFrame.y = 2 * this.game.height / 3;
    }
    loadPlayerAvatars() {
        var avatarInt = 0;
        for(var i = 0; i < 3; i++)
        {
            for(var j = 0; j < 2; j++)
            {
                var avatar = this.game.add.sprite(this.game.width / 46 ,
                    (this.game.height / 5.6) + (i * this.game.height / 6.5),
                    'TempAvat', this.avatarSelection[avatarInt++]);
                avatar.height = this.game.height / 8.1;
                avatar.width = this.game.width / 8.6;
                if(j == 1)
                {
                    avatar.x = this.game.width - this.game.width / 40 - avatar.width;
                }
            }
        }
    }
    loadPlayerText() {
        var t = 1;
        for(var i = 0; i < 3; i++){
            for(var j = 0; j < 2; j++){
                var text = this.game.add.text(this.game.width / 7, (this.game.height / 5.5) + (this.game.height / 6.5 * i), 'Player' + t++);
                text.fill = '#ef329c';
                if(j == 1){
                    text.x = 3.1 * this.game.width / 4.2
                }
            }
        }
    }
    showCharSelection() {
        var avatSelection = 0;
        for(var i = 0; i < 6; i++){
            for(var j = 0; j < 7; j++){
                var avatar = this.game.add.sprite(this.game.width / 2.9 + (i * 42),
                    this.game.height / 6.5 + (j * 42),
                    'TempAvat', avatSelection++, this.avatarGroup);
                avatar.height = this.game.height / 15;
                avatar.width = this.game.width / 20;
                avatar.inputEnabled = true;
                avatar.events.onInputDown.add(this.clickAvatar, this);
                //this.avatarGroup.add(avatar);
            }
        }
    }
    clickAvatar(sprite, pointer) {
        //console.log(sprite.group.getIndex(this));
        //this.avatarSelection[0] = this.avatarGroup.getIndex(sprite);
        //this.loadPlayerAvatars();
        this.game.state.start('Play');
    }
}