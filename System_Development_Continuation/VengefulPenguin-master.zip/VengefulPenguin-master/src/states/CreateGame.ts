///<reference path="../definitions/phaser.d.ts"/>

class CreateGame extends Phaser.State {
    public nrPlayer:number;
    public createBtn: Phaser.Sprite;
    public sizeBtn:Phaser.Sprite[];
    preload() {
        console.log("[State] CreateGame");
        this.game.stage.backgroundColor = "#b4d455";
    }

    create() {
        this.createBackground();
        this.sizeBtn = [];
        this.createRoomSizeButtons();
        this.createButton(this.game.width / 2, this.game.height / 2 + 150, 'Cancel', ()=> this.onCancel());
        this.createBtn = this.createButton(this.game.width / 2, this.game.height / 2 + 100, 'Create', ()=> this.onCreate());
        this.createBtn.inputEnabled = false;
        this.createBtn.input.useHandCursor = false;
        this.createBtn.alpha = 0.2;
    }

    private onCreateBtn() {
        // TODO: Add a server acknowledgement
    }

    private onCreate() {
        // window.vengefulPenguin.socket.socket.emit('gameAdded');
        window.vengefulPenguin.socket.socket.emit('createGame', this.nrPlayer);
        this.game.state.start('Lobby', true, false, this.nrPlayer);
    }

    private createRoomSizeButtons() {
        var text = this.createText(this.game.width / 2, this.game.height / 2 - 200, 'Choose Room Size:');
        this.setFlooredCenterAnchor(text);
        
        var buttonPosition = -1.5;
        for (var i = 2; i <= 8; i += 2) {
            this.sizeBtn.push(this.createButton(this.game.width / 2 + buttonPosition * 50, this.game.height / 2 - 150, i + "",
                (nr) => {
                    this.nrPlayer = nr;
                    this.createBtn.inputEnabled = true;
                    this.createBtn.input.useHandCursor = true;
                    this.createBtn.alpha = 1;

                    //set scale to show what has been selected.
                    this.sizeBtn.forEach((button, i, buttons)=> {
                        if ((i+1)*2 === nr)
                            button.scale.setTo(1);
                        else
                            button.scale.setTo(0.5);
                    });
                }));
            buttonPosition++;
        }
    }

    private createButton(x:number, y:number, text:string, event:Function) {
        var button = this.createText(x, y, text);
        this.setFlooredCenterAnchor(button);
        button.inputEnabled = true;
        button.input.useHandCursor = true;
        button.events.onInputUp.add(()=> event(parseInt(text)), this);
        return button;
    }

    private createText(x:number, y:number, text:string) {
        return this.game.add.text(Math.floor(x), Math.floor(y), text, {font: '40px Rouge Script', fill: '#271a0c'});
    }

    private createBackground() {
        var background = this.game.add.sprite(0, 0, 'background', 0);
        background.height = this.game.height;
        background.width = this.game.width;
    }

    private onCancel() {
        this.game.state.start('LobbyList', true);
    }

    private setFlooredCenterAnchor(text:Phaser.Text) {
        text.anchor.x = Math.round(text.width * 0.5) / text.width;
        text.anchor.y = Math.round(text.height * 0.5) / text.height;
    }
}
