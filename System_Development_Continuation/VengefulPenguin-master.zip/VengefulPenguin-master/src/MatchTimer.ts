export class MatchTimer {
    public minutes: number;
    public seconds: number;
    public initMinutes: number;
    public initSeconds: number;
    public id_message_sending: number;
    public id_counter: number;

    constructor(minutes:number, seconds:number) {
        this.minutes = minutes;
        this.seconds = seconds;
        this.initMinutes = minutes;
        this.initSeconds = seconds;
        this.id_message_sending = 0;
        this.id_counter = 0;
    }

    // Starts the timer and counts down to 0, using timing events.
    public start() {
        this.id_counter = setInterval(function() {
            if (this.seconds > 0)
                this.seconds--;
            else if (this.minutes > 0) {
                this.seconds = 59;
                this.minutes--;
            }
        }.bind(this), 1000);
    }

    public reset() {
        clearInterval(this.id_counter);
        this.minutes = this.initMinutes;
        this.seconds = this.initSeconds;
    }
}