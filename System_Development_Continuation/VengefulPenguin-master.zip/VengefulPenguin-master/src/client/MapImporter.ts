///<reference path="../ecs/base/EcsWorld.ts"/>
/**
 * Created by vsven on 2016-04-18.
 */
///<reference path="../definitions/phaser.d.ts"/>
class MapImporter
{
    private game : Phaser.Game;
    private world : EcsWorld;

    constructor(game: Phaser.Game)
    {
        this.game = game;
    }


    //This should be placed in ex PRELOAD->preload() 
    public LoadJSON(json:string)
    {
        this.game.load.json('level', 'assets/maps/'.concat(json)); //Load map json file to cache
    }

    //This should be placed in ex PLAY->preload() (As long as its atleast 1 state efter json is loaded
    public LoadImages()
    {
        //Fetch json file from cache
        var map_json = this.game.cache.getJSON('level');

        // Go through the json file and fetch Tilesets and the Tiles belonging to them
        // Tileset = group of tiles for easier access in tiled editor

        var TileSetIndex; //Index to for loop
        var TileIndex;

        //For each set of tiles (GroundTiles, PropTiles etc..)
        for(TileSetIndex = 0; TileSetIndex < map_json.tilesets.length; TileSetIndex++)
        {
            for(var key in map_json.tilesets[TileSetIndex].tiles)
            {
                var value = map_json.tilesets[TileSetIndex].tiles[key].image;
                var PathArray = value.split("/");
                PathArray = PathArray.pop();
                var Filename = 'assets/tiles/'.concat(PathArray);
                this.game.load.image(PathArray.split(".")[0],Filename); //Loads in the correct image in the cache
            }
        }
        // The code above goes through all different tiles in map project and loads them in to the phaser
        // cache, the key to each image is the filename excluding file extension. ex. grass.png have key 'grass' in cache
    }

    public SpawnMap(groundGroup : Phaser.Group,collisionGroup : Phaser.Group, foliageGroup : Phaser.Group, world: EcsWorld)
    {
        // Go through all coordinates and drop the correct tiles at each coordinate
        var map_json = this.game.cache.getJSON('level');

        //var TileSets = []; //Object containing TileSets
        var TileSetIndex; //Index to for loop
        var TileIndex;
        var cacheStringDict = {};

        //For each set of tiles (GroundTiles, PropTiles etc..)
        //This loop could be removed if class is refactored in to a static class
        for(TileSetIndex = 0; TileSetIndex < map_json.tilesets.length; TileSetIndex++)
        {
            for(var TileIndex in map_json.tilesets[TileSetIndex].tiles)
            {
                var Tile = {};
                Tile.ID = Number(TileIndex) + Number(map_json.tilesets[TileSetIndex].firstgid);
                var Path = map_json.tilesets[TileSetIndex].tiles[TileIndex].image;
                var PathArray = Path.split("/");
                PathArray = PathArray.pop();
                Tile.CacheString = PathArray.split(".")[0];
                cacheStringDict[Tile.ID] = Tile.CacheString;
            }
        }

        //Floor because floating point numbers seems to mess up map rendering
        var tileDistance = Math.floor(Math.sqrt(Math.pow(map_json.tileheight/2,2) + Math.pow(map_json.tilewidth/2,2)));
        var XLength = map_json.height * tileDistance;
        var YLength = map_json.width * tileDistance;
        this.game.world.setBounds(0, 0, XLength*2, YLength*2); // Set world size

        console.log("MapXLength: ", XLength);
        console.log("MapYLength: ", YLength);

        //Loop variables
        var X;
        var Y;
        var DataIndex = 0;
        var CurrentLayer = 0;
        var CurrentMultiplier = 0;
        var TileStack = [];

        //Start with first layer then repeat for all layers
        for(CurrentLayer = 0; CurrentLayer < map_json.layers.length;CurrentLayer++)
        {
            for (Y = 0; Y < YLength; Y += tileDistance) {
                for (X = 0; X < YLength; X += tileDistance) {
                    var current_id = map_json.layers[CurrentLayer].data[DataIndex];
                    if(current_id != 0) // 0 means no tile (ex. layer 2 doesnt have tree on every tile, some tiles are "empty" for layer 2
                    {
                        switch(CurrentLayer)
                        {
                            case 0:
                                world.prefab.createGroundTile(X,Y,0,cacheStringDict[current_id],"default",groundGroup);
                                break;
                            case 1:
                                world.prefab.createCollisionTile(X,Y,0,cacheStringDict[current_id],collisionGroup);
                                break;
                            case 2:
                                world.prefab.createFoliageTile(X,Y,0,cacheStringDict[current_id],foliageGroup);
                                break;
                            default:
                                console.log("Layer out of scope. Please use only 3 layers in Tiled.");
                        }
                    }
                    DataIndex++;
                }
            }
            DataIndex = 0;
        }
    }
}
