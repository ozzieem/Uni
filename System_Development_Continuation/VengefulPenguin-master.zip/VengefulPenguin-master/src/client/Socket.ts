/// <reference path="../definitions/socket.io.d.ts"/>
///<reference path="../network/PlayerMovementMessage.ts"/>
///<reference path="../ecs/components/PositionComponent.ts"/>
///<reference path="../ecs/components/NetworkPlayerComponent.ts"/>
///<reference path="../network/PlayerPositionMessage.ts"/>
///<reference path="../network/AttackMessage.ts"/>
///<reference path="../ecs/base/Entity.ts"/>
///<reference path="../MatchTimer.ts"/>
///<reference path="../ScoreKeeper.ts"/>
///<reference path="../network/LobbyListMessage.ts"/>

import SpriteBatch = Phaser.SpriteBatch;
import {LobbyListMessage} from "../network/LobbyListMessage";
import {PlayerDataMessage} from "../network/PlayerDataMessage";
import {MatchTimer} from "../MatchTimer";
import {ScoreMessage} from "../network/ScoreMessage";
import {TimerMessage} from "../network/TimerMessage";
import {read} from "fs";
import {LobbyData} from "../network/LobbyData";
class Socket {
    public socket:any;
    count:number;

    constructor() {
        this.socket = io();

        this.socket.on('login', (socketID:string, position:PlayerPositionMessage)=> {
            var world = window.vengefulPenguin.game.state.getCurrentState().ecsWorld;
            console.log("[INFO] Player", socketID, "connected.");
            world.prefab.createNetworkPlayer(position.x, position.y, position.z, socketID);
            var player = world.getEntitiesByGroup('player')[0];
            var sprite:SpriteComponent = world.getComponent(player, world.getRegisteredComponent(SpriteComponent));
            var myPosition = new PlayerPositionMessage(
                sprite.sprite.isoX,
                sprite.sprite.isoY,
                sprite.sprite.isoZ - sprite.sprite.height / 2);
        });

        this.socket.on('lobbyList', (rooms:LobbyListMessage)=> {
            if (window.vengefulPenguin.game.state.getCurrentState().key == "LobbyList") {
                window.vengefulPenguin.game.state.getCurrentState().onLobbyList(rooms);
            }
        });

        this.socket.on('playersInRoom', (players:PlayerDataMessage, socketId:string)=> {
            if (window.vengefulPenguin.game.state.getCurrentState().key == "Lobby") {
                window.vengefulPenguin.game.state.getCurrentState().onPlayerList(players);
                window.vengefulPenguin.game.state.getCurrentState().setMySocket(socketId);
            }
        });

        this.socket.on('clientJoined', (players:PlayerDataMessage)=> {
            if (window.vengefulPenguin.game.state.getCurrentState().key == "Lobby") {
                console.log('[INFO] Player', players.list[0].id, "joined the room.")
                window.vengefulPenguin.game.state.getCurrentState().onPlayerJoined(players.list[0]);
            }
        });

        this.socket.on('clientLeft', (socketID:string)=> {
            if (window.vengefulPenguin.game.state.getCurrentState().key == "Lobby") {
                window.vengefulPenguin.game.state.getCurrentState().onPlayerLeft(socketID);
            }
            else if (window.vengefulPenguin.game.state.getCurrentState().key == "Play") {
                //TODO remove player
            }
            else if (window.vengefulPenguin.game.state.getCurrentState().key == "GameOver") {
                window.vengefulPenguin.game.state.getCurrentState().onPlayerLeft(socketID);
            }
        });

        this.socket.on('clientJoinedRoom', (room:LobbyData)=> {
            if (window.vengefulPenguin.game.state.getCurrentState().key == "LobbyList") {
                window.vengefulPenguin.game.state.getCurrentState().onPlayerJoinRoom(room);
            }
        });

        this.socket.on('clientLeftRoom', (room:LobbyData)=> {
            if (window.vengefulPenguin.game.state.getCurrentState().key == "LobbyList") {
                window.vengefulPenguin.game.state.getCurrentState().onPlayerLeaveRoom(room);
            }
        });

        this.socket.on('roomState', (room:LobbyData)=> {
            if (window.vengefulPenguin.game.state.getCurrentState().key == 'LobbyList') {
                window.vengefulPenguin.game.state.getCurrentState().setRoomState(room);
            }
        });


        this.socket.on('roomRemoved', (roomID:number)=> {
            if (window.vengefulPenguin.game.state.getCurrentState().key == "LobbyList") {
                console.log("[DEBUG] Socket:roomRemoved activated");
                window.vengefulPenguin.game.state.getCurrentState().onRoomRemoved(roomID);
            }
        });

        this.socket.on('gameAdded', (rooms:LobbyListMessage)=> {
            if (window.vengefulPenguin.game.state.getCurrentState().key == "LobbyList") {
                console.log('[INFO] Room', rooms.list[0].id, "added to Lobbylist.")
                window.vengefulPenguin.game.state.getCurrentState().onGameAdded(rooms.list[0]);
            }
        });

        this.socket.on('teamUpdate', (players:any)=> {
            if (window.vengefulPenguin.game.state.getCurrentState().key == "Lobby") {
                window.vengefulPenguin.game.state.getCurrentState().onTeamUpdate(players);
            }
        });

        this.socket.on('deletePlayer', (socketID) => {
            var world = window.vengefulPenguin.game.state.getCurrentState().ecsWorld;
            var players = world.getEntitiesByGroup('networkPlayers');
            for (var player in players) {
                var network:NetworkPlayerComponent = world.getComponent(players[player],
                    world.getRegisteredComponent(NetworkPlayerComponent));
                if (network.socketId == socketID && players[player] != null) {
                    players[player].kill();
                    break;
                }
            }
        });

        this.socket.on('postGameInfo', (players:PlayerDataMessage, socketId:string, roomSize:number)=> {
            if (window.vengefulPenguin.game.state.getCurrentState().key == "GameOver") {
                window.vengefulPenguin.game.state.getCurrentState().onLoadGameOver(players, socketId, roomSize);
            }
        });

        this.socket.on('startGame', (timer:TimerMessage)=> {
            if (window.vengefulPenguin.game.state.getCurrentState().key == 'Lobby') {
                window.vengefulPenguin.game.state.getCurrentState().onStartGame(timer);
            }
        });

        this.socket.on('gameOver', ()=> {
            if (window.vengefulPenguin.game.state.getCurrentState().key == 'Play') {
                window.vengefulPenguin.game.state.getCurrentState().onGameOver();
            }
        });

        this.socket.on('startRematch', ()=> {
            if (window.vengefulPenguin.game.state.getCurrentState().key == 'GameOver') {
                console.log("[DEBUG] Rematch run in socket");
                window.vengefulPenguin.game.state.getCurrentState().onRematch();
            }
        });


        this.socket.on('playerReady', (playerId:string)=> {
            if (window.vengefulPenguin.game.state.getCurrentState().key == 'GameOver') {
                window.vengefulPenguin.game.state.getCurrentState().onReady(playerId);
            }
            else if (window.vengefulPenguin.game.state.getCurrentState().key == 'Lobby') {
                window.vengefulPenguin.game.state.getCurrentState().onReady(playerId);
            }
        });

        this.socket.on('readyPlayers', (nrReadyPlayers:number)=> {
            if (window.vengefulPenguin.game.state.getCurrentState().key == 'Lobby') {
                window.vengefulPenguin.game.state.getCurrentState().setReadyPlayers(nrReadyPlayers);
            }
            else if (window.vengefulPenguin.game.state.getCurrentState().key == 'GameOver') {
                window.vengefulPenguin.game.state.getCurrentState().setReadyPlayers(nrReadyPlayers);
            }
        });

        this.socket.on('syncPosition', (socketID:string, position:PlayerPositionMessage) => {
            if (window.vengefulPenguin.game.state.getCurrentState().key == 'Play') {
                window.vengefulPenguin.game.state.getCurrentState().syncBuffer.onReceivedMessage(socketID, position);
            }
        });

        this.socket.on('scores', (scoreMessage:ScoreMessage) => {
            if (window.vengefulPenguin.game.state.getCurrentState().key == 'Play') {
                window.vengefulPenguin.game.state.getCurrentState().scoreKeeper = scoreMessage.scoreKeeper;
            }
        });

        this.socket.on('attack', (socketID:string, message:AttackMessage) => {
            if (window.vengefulPenguin.game.state.getCurrentState().key == 'Play') {
                window.vengefulPenguin.game.state.getCurrentState().attackBuffer.onReceivedMessage(socketID, message);
            }
        });

        this.socket.on('itemSwitch', (socketID:string, message:number) => {
            if (window.vengefulPenguin.game.state.getCurrentState().key == 'Play') {
                window.vengefulPenguin.game.state.getCurrentState().itemSwitchBuffer.onReceivedMessage(socketID, message);
            }
        });

        this.socket.on('playerDied', (socketID:string) => {
            var world = window.vengefulPenguin.game.state.getCurrentState().ecsWorld;
            var players:Entity[] = world.getEntitiesByGroup('networkPlayers');
            for (var i in players) {
                var network:NetworkPlayerComponent = world.getComponent(players[i],
                    world.getRegisteredComponent(NetworkPlayerComponent));
                if (network.socketId == socketID) {
                    var lifeStatus:LifeStatusComponent = world.getComponent(players[i],
                        world.getRegisteredComponent(LifeStatusComponent));
                    lifeStatus.alive = false;
                    lifeStatus.playDeathAnim = true;
                }
            }
        });

        // Plays deathanimation on disconnected player in Play-state
        this.socket.on('playerDisconnected', (socketID:string) => {
            if (window.vengefulPenguin.game.state.getCurrentState().key == 'Play') {
                var world = window.vengefulPenguin.game.state.getCurrentState().ecsWorld;
                var players:Entity[] = world.getEntitiesByGroup('networkPlayers');
                for (var i in players) {
                    var network:NetworkPlayerComponent = world.getComponent(players[i],
                        world.getRegisteredComponent(NetworkPlayerComponent));
                    if (network.socketId == socketID) {
                        var sprite:SpriteComponent = world.getComponent(players[i],
                            world.getRegisteredComponent(SpriteComponent));
                        var lifeStatus:LifeStatusComponent = world.getComponent(players[i],
                            world.getRegisteredComponent(LifeStatusComponent));
                        lifeStatus.playDeathAnim = true;
                        world.removeComponent(players[i],
                            world.getRegisteredComponent(ProjectileCollisionComponent));
                    }
                }
            }
        });

        this.socket.on('playerSpawned', (socketID:string) => {
            var world = window.vengefulPenguin.game.state.getCurrentState().ecsWorld;
            var players:Entity[] = world.getEntitiesByGroup('networkPlayers');
            for (var i in players) {
                var network:NetworkPlayerComponent = world.getComponent(players[i],
                    world.getRegisteredComponent(NetworkPlayerComponent));
                if (network.socketId == socketID) {
                    var lifeStatus:LifeStatusComponent = world.getComponent(players[i],
                        world.getRegisteredComponent(LifeStatusComponent));
                    lifeStatus.alive = true;
                }
            }
        });

    }
}
