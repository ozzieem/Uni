/// <reference path = "../definitions/phaser.d.ts"/>

module VP {
    class Camera {
        game:Phaser.Game;

        constructor(game:Phaser.Game) {
            this.game = game;
        }
        
        //TODO Ändra till vår egen Entity istället för Phaser.Sprite (RA)
        followObject(objectToFollow:Phaser.Sprite) {
            this.game.camera.follow(objectToFollow);
        }

        setPosition(Position: Phaser.Sprite){
            this.game.camera.setPosition(Position.x, Position.y);
        }

    }
}