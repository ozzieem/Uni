/// <reference path = "../definitions/phaser.d.ts"/>
/// <reference path = "../definitions/phaser.plugin.isometric.d.ts"/>
/// <reference path = "../states/Play.ts"/>
/// <reference path = "../states/Preload.ts"/>
///<reference path="Socket.ts"/>
///<reference path="../states/Lobby.ts"/>
///<reference path="../states/GameOver.ts"/>
///<reference path="../states/LobbyList.ts"/>
///<reference path="../states/MainMenu.ts"/>

module VP {
    import IsoSprite = Phaser.Plugin.Isometric.IsoSprite;
    export class VengefulPenguin {
        public game: Phaser.Game;
        private width: number;
        private height: number;
        public socket: any;
        constructor(width:number, height:number) {
            this.width = width;
            this.height = height;
            var canvas = document.getElementById('canvas');
            canvas.style.width = this.width.toString() + "px";
            canvas.style.height = this.height.toString() + "px";
            this.game = new Phaser.Game(this.width, this.height, Phaser.AUTO, 'canvas', {
                preload: this.preload, create: this.create, update: this.update, render: this.render
            });
            this.socket = new Socket(this.game);
        }
        preload() {
            this.game.isometric = this.game.plugins.add(Phaser.Plugin.Isometric);
            this.game.stage.disableVisibilityChange = true;
            this.game.load.image('loadingBar', 'assets/sprites/loadingBar.png');
            this.game.load.image('preloadLogo', 'assets/sprites/preloadLogo.png');
            this.game.load.image('background', 'assets/sprites/Lobby/oldPaper.jpg');
        }
        create() {
            this.game.load.script('webfont', '//ajax.googleapis.com/ajax/libs/webfont/1.4.7/webfont.js');
            this.game.state.add('Preload', Preload, true);
            this.game.state.add('Lobby', Lobby);
            this.game.state.add('LobbyList', LobbyList);
            this.game.state.add('MainMenu', MainMenu);
            this.game.state.add('CreateGame', CreateGame);
            this.game.state.add('Play', Play);
            this.game.state.add('GameOver', GameOver);
        }
        update() {
        }
        render() {
        }
    }
};

vengefulPenguin: VP.VengefulPenguin;

window.onload = () => {
    vengefulPenguin = new VP.VengefulPenguin(800, 600);
}