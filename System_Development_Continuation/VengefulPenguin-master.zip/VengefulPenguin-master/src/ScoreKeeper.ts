export class ScoreKeeper{
    frags: {[socketID:string]: number};
    deaths: {[socketID:string]: number};

    constructor() {
        this.frags = {};
        this.deaths = {};
    }

    addNewPlayer(socketID: string){
        this.frags[socketID] = 0;
        this.deaths[socketID] = 0;
    }
}