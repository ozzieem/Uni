/// <reference path="src/definitions/node.d.ts"/>
/// <reference path="src/definitions/socket.io.d.ts"/>
///<reference path="src/network/PlayerMovementMessage.ts"/>
///<reference path="src/ecs/components/PositionComponent.ts"/>
///<reference path="src/network/PlayerPositionMessage.ts"/>
///<reference path="src/network/AttackMessage.ts"/>
///<reference path="src/MatchTimer.ts"/>
///<reference path="src/network/ScoreMessage.ts"/>
///<reference path="src/ScoreKeeper.ts"/>
///<reference path="Room.ts"/>
///<reference path="src/network/LobbyListMessage.ts"/>
///<reference path="src/network/DeathMessage.ts"/>

import {MatchTimer} from "./src/MatchTimer";
import {ScoreMessage} from "./src/network/ScoreMessage";
import {ScoreKeeper} from "./src/ScoreKeeper";
import {Room} from "./Room";
import {LobbyListMessage} from "./src/network/LobbyListMessage";
import {PlayerDataMessage} from "./src/network/PlayerDataMessage";
import {PlayerData} from "./src/network/PlayerData";
import {createSecureContext} from "tls";
import {LobbyData} from "./src/network/LobbyData";
var express = require('express');
var app = express();
var server = require('http').Server(app);

app.get('/', function (req, res) {
    res.sendFile(__dirname + '/index.html');
});
app.use('/src', express.static(__dirname + '/src'));
app.use('/css', express.static(__dirname + '/css'));
app.use('/lib', express.static(__dirname + '/lib'));
app.use('/assets', express.static(__dirname + '/assets'));

server.listen(4000);
console.log("Server started.");

// var rooms = [];
var rooms:{ [nrRoom:number]:Room } = {};
var socketInRoom:{ [socket:string]:Room } = {};
var rooms_length = 0;

var io = require('socket.io')(server, {});

io.sockets.on('connection', (socket)=> {
    console.log("[INFO] Client:", socket.id, "connected.");
    socket.emit('welcome', socket.id);

    socket.on('createGame', (roomSize)=> {
        var room = new Room(rooms_length++, io, roomSize);
        socket.join(room.id + "");
        rooms[room.id] = room;

        room.players[socket.id] = new PlayerData(socket.id, room.generateName(), -1, false);
        socketInRoom[socket.id] = room;

        // Sending new room to all connected clients lobbylist
        var newRoomMessage = new LobbyListMessage();
        newRoomMessage.add(room.id, room.name, room.size, room.getAvailablePlayers(), room.state);
        io.sockets.emit('gameAdded', newRoomMessage);
        console.log("[INFO] Client:", socket.id, "created room:", room.id);
    });

    socket.on('getLobbies', ()=> {
        console.log("[INFO] Client:", socket.id, "requested lobbylist.");
        var lobbyListMessage = new LobbyListMessage();
        for (var room in rooms) {
            lobbyListMessage.add(rooms[room].id, rooms[room].name, rooms[room].size, rooms[room].getAvailablePlayers(), rooms[room].state);
        }
        socket.emit('lobbyList', lobbyListMessage);
    });

    // Sends a list of clients in the joined room and the socket-ID of the client that joined
    socket.on('joinedLobby', ()=> {
        if (socketInRoom[socket.id]) {
            var players = socketInRoom[socket.id].players;
            console.log("[DEBUG] Players in room", socketInRoom[socket.id].id, ": ", socketInRoom[socket.id].getAvailablePlayers());

            var message = new PlayerDataMessage();
            for (var player in players) {
                message.add(players[player].id, players[player].name, players[player].team, false);
            }
            socket.emit('playersInRoom', message, socket.id);
        }
    });

    socket.on('joinRoom', (nrGame:number)=> {
        console.log("[INFO] Client:", socket.id, "attempting to join room:", nrGame);
        if (rooms[nrGame]) {
            if (rooms[nrGame].state === 0) {                // Check if room is in lobby-state
                socket.join(nrGame);
                socketInRoom[socket.id] = rooms[nrGame];
                socketInRoom[socket.id].players[socket.id] = new PlayerData(socket.id, socketInRoom[socket.id].generateName(), -1, false);

                var message = new PlayerDataMessage();
                message.add(socket.id, socketInRoom[socket.id].players[socket.id].name, socketInRoom[socket.id].players[socket.id].team, false);
                socketInRoom[socket.id].broadcast(socket.id, 'clientJoined', message);

                var socketRoom = socketInRoom[socket.id];
                var roomMessage = new LobbyData(socketRoom.id, socketRoom.name, socketRoom.size, socketRoom.getAvailablePlayers(), socketRoom.state);
                io.sockets.emit('clientJoinedRoom', roomMessage);
                console.log("[INFO] Client:", socket.id, "joined room:", nrGame);
            }
        }
        else {
            console.log("[INFO] Client:", socket.id, "denied to join room:", nrGame);
        }
    });

    // Notifies other clients within the same room that other client left the lobby
    socket.on('leaveRoom', ()=> {
        extractClientfromRoom();
    });

    // Forces clients within the same room to start Play-state
    socket.on('startGame', ()=> {
        if (socketInRoom[socket.id].readyPlayers >= socketInRoom[socket.id].getAvailablePlayers()) {
            socketInRoom[socket.id].onStartGame();
            console.log("[INFO] Game started in Room:", socketInRoom[socket.id].id);
        }
    });

    socket.on('iDied', (deathMessage:DeathMessage) => {
        socketInRoom[socket.id].scoreKeeper.deaths[socket.id]++;
        socketInRoom[socket.id].scoreKeeper.frags[deathMessage.killedBy]++;
        socketInRoom[socket.id].broadcast(null, 'scores', new ScoreMessage(socketInRoom[socket.id].scoreKeeper));
        socketInRoom[socket.id].broadcast(null, 'playerDied', socket.id);
    });

    socket.on('iSpawned', () => {
        socketInRoom[socket.id].broadcast(null, 'playerSpawned', socket.id);
    });

    // Response from connected player on 'newPlayer' message.
    // The message contains player position data which is sent to a newly connected player.
    socket.on('syncPosition', (position:PlayerPositionMessage)=> {
        if (socketInRoom[socket.id]) {
            var players = socketInRoom[socket.id].players;
            for (var i in players) {
                if (players[i].id !== socket.id) {
                    io.to(players[i].id).emit('syncPosition', socket.id, position);
                }
            }
        }
    });

    socket.on('disconnect', ()=> {
        console.log("[INFO] Client: " + socket.id + " disconnected.");
        if (socketInRoom[socket.id]) {
            // Plays death animation on disconnected player in play-state
            socketInRoom[socket.id].broadcast(null, 'playerDisconnected', socket.id);
            extractClientfromRoom();
        }
    });

    socket.on('attack', (attack:AttackMessage)=> {
        var players = socketInRoom[socket.id].players;
        for (var i in players) {
            if (players[i].id !== socket.id) {
                io.to(players[i].id).emit('attack', socket.id, attack);
            }
        }
    });

    socket.on('itemSwitch', function (itemSlot:number) {
        var players = socketInRoom[socket.id].players;
        for (var i in players) {
            if (players[i].id !== socket.id) {
                io.to(players[i].id).emit('itemSwitch', socket.id, itemSlot);
            }
        }
    });

    socket.on('joinTeam', (nr:number)=> {
        socketInRoom[socket.id].joinRoom(socket.id, nr);
    });

    // Sends current information about the room for gameover-state
    socket.on('loadGameOver', ()=> {
        var players = socketInRoom[socket.id].players;
        var message = new PlayerDataMessage();
        for (var player in players) {
            message.add(players[player].id, "", players[player].team, false);
        }
        socket.emit('postGameInfo', message, socket.id, socketInRoom[socket.id].size);
        socketInRoom[socket.id].updateReadyPlayers();
        socketInRoom[socket.id].onGameOver();
    });

    // If player pressed ready button, send out to all other clients in room and compare total readyplayers
    socket.on('playerReady', ()=> {
        var currentPlayer = socketInRoom[socket.id].players[socket.id];
        if (!currentPlayer.ready) {
            currentPlayer.ready = true;
            socketInRoom[socket.id].broadcast(null, 'playerReady', socket.id);
        }
        socketInRoom[socket.id].checkReady();
    });

    // If players quits in GameOver-state, check if remaining players are all ready and start rematch
    socket.on('playerQuit', ()=> {
        // TODO: Can possibly be refactored into room::checkReady. Mind the socket.id in broadcast.
        socketInRoom[socket.id].updateReadyPlayers();
        if (socketInRoom[socket.id].readyPlayers <= socketInRoom[socket.id].getAvailablePlayers()) {
            socketInRoom[socket.id].resetReadyPlayers();
            socketInRoom[socket.id].state = 0;
            socketInRoom[socket.id].broadcast(socket.id, 'startRematch');
            socketInRoom[socket.id].sendRoomState();
            console.log("[INFO] Starting rematch with ", socketInRoom[socket.id].getAvailablePlayers());
        }
        extractClientfromRoom();
    });

    // Removes a client from socketInRoom[socket.id] and the room itself if no clients are in it
    var extractClientfromRoom = function () {
        var roomID = socketInRoom[socket.id].id;
        console.log("[INFO] Client:", socket.id, "leaving room", roomID);
        console.log("[DEBUG] Clients in room", roomID, "before socket-leave:", socketInRoom[socket.id].getAvailablePlayers());
        socket.leave(roomID + "");
        delete socketInRoom[socket.id].players[socket.id];  // Removes player from players dict in room
        console.log("[DEBUG] Clients in room:", roomID, "after socket-leave:", socketInRoom[socket.id].getAvailablePlayers());

        var socketRoom = socketInRoom[socket.id];
        var roomMessage = new LobbyData(socketRoom.id, socketRoom.name, socketRoom.size, socketRoom.getAvailablePlayers(), socketRoom.state);
        io.sockets.emit('clientLeftRoom', roomMessage);
        socketInRoom[socket.id].updateReadyPlayers();       // Updates ready players in lobby and gameover

        console.log("[INFO] Client:", socket.id, "left room", roomID);
        socketInRoom[socket.id].broadcast(null, 'clientLeft', socket.id);
        delete socketInRoom[socket.id];                     // Removes the socket from the room

        var clientsInRoom = rooms[roomID].getAvailablePlayers();
        if (rooms[roomID].getAvailablePlayers() <= 0 || clientsInRoom <= 0) {
            console.log("[INFO] Removing room", roomID, "- No clients connected:", clientsInRoom <= 0, "(", clientsInRoom, ")");
            console.log("[DEBUG] Rooms-list pre-removal:", rooms_length);
            rooms[roomID].timer.reset();
            rooms[roomID].onGameOver();
            delete rooms[roomID];
            if (rooms_length > 0) {
                rooms_length--;
            }
            console.log("[DEBUG] Rooms-list post-removal:", rooms_length);
            io.sockets.emit('roomRemoved', roomID);         // Updating lobbylist for clients
            console.log("[INFO] Room", roomID, "removed. Remaining rooms on server:", rooms);
        }
    };
});