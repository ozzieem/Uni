import {MatchTimer} from "./src/MatchTimer";
import {ScoreKeeper} from "./src/ScoreKeeper";
import {PlayerData} from "./src/network/PlayerData";
import {TimerMessage} from "./src/network/TimerMessage";
import {LobbyData} from "./src/network/LobbyData";

enum roomState {
    lobby,
    play,
    gameOver
}

export class Room {
    state:roomState;
    name:string;
    id:number;
    io:any;
    size:number;
    timer:MatchTimer;
    scoreKeeper:ScoreKeeper;
    readyPlayers:number;
    players:{ [socket:string]:PlayerData };

    names:any[] = [
        "Mikael", "Tobias", "Özgun", "Martin", "Victor", "Robin", "Simon",
        "Jon Snow", "Daenerys", "Ramsay", "Rickon", "Gregor", "The Mountain",
        "Sansa", "Theon", "Jorah", "Arya", "High Sparrow", "Joffrey", "Tormund",
        "Tyrion", "Melisandre", "Cersei", "Drogo", "Brienne", "Jaqen", "Ygritte",
        "Tywin", "Oberyn", "Euron", "Varys", "Olly", "Davos", "Mance", "Hodor"
    ];


    constructor(gameID:number, io:any, size:number) {
        this.id = gameID;
        this.io = io;
        this.size = size;
        this.scoreKeeper = new ScoreKeeper();
        this.players = {};
        this.timer = new MatchTimer(3,0);           // Duration of match timer
        this.readyPlayers = 0;
        this.state = roomState.lobby;
    }

    // Starts the timer and the game for the room
    public onStartGame() {
        this.timer.start();
        this.timer.id_message_sending = setInterval(() => {
            if (this.timer.seconds == 0 && this.timer.minutes == 0) {
                clearInterval(this.timer.id_message_sending);
                clearInterval(this.timer.id_counter);
                // TODO: Move this out of here. Causes the function to be called three times...
                this.onGameOver();
            }
            if ((this.timer.minutes === 1 && this.timer.seconds === 0) ||
                (this.timer.minutes === 2 && this.timer.seconds === 0)) {
                console.log("[INFO] Timer in room:", this.id, "===", this.timer.minutes + ":" + this.timer.seconds);
            }
            // TODO: (Bug) Timer keeps counting even after clearInterval.
            // console.log("[INFO] Timer in room:", this.id, "===", this.timer.minutes +":"+this.timer.seconds);
        }, 1000);

        var timerMessage = new TimerMessage(this.timer.minutes, this.timer.seconds);
        this.broadcast(null, 'startGame', timerMessage);

        // Adds a new scorekeeper to each player
        for (var player in this.players) {
            this.scoreKeeper.addNewPlayer(player);
        }
        this.resetReadyPlayers();
        this.state = roomState.play;
        this.sendRoomState();
    }

    // Resets timer when game ends
    public onGameOver() {
        this.timer.reset();
        this.broadcast(null, 'gameOver');
        this.state = roomState.gameOver;
        console.log("[INFO] Room", this.id, "game ended. Play -> GameOver");
    }

    // Checks how many players are ready and starts the specific state
    public checkReady() {
        this.updateReadyPlayers();
        if (this.state === roomState.lobby) {
            if (this.readyPlayers >= this.getAvailablePlayers()) {
                console.log("[INFO] Room", this.id, "game started with",
                    this.getAvailablePlayers(), "players. Lobby -> Play");
                this.onStartGame();
            }
        }
        else if (this.state === roomState.gameOver) {
            if (this.readyPlayers >= this.getAvailablePlayers()) {
                this.resetReadyPlayers();
                this.state = roomState.lobby;
                this.broadcast(null, 'startRematch');
                this.sendRoomState();
                console.log("[INFO] Room", this.id, "starting rematch with",
                    this.getAvailablePlayers(), "players. GameOver -> Lobby");
            }
        }
    }

    public sendRoomState() {
        var message = new LobbyData(this.id, this.name, this.size, this.getAvailablePlayers(), this.state);
        this.io.sockets.emit('roomState', message);
    }

    public getAvailablePlayers() {
        return Object.keys(this.players).length;
    }

    // Should not be used. Use this.players instead.
    private getClients() {
        var res = [];
        var room = this.io.sockets.adapter.rooms[this.id];
        if (room) {
            for (var socket in room.sockets) {
                res.push(socket);
            }
        }
        return res;
    }

    public broadcast(socket:string = null, eventName:string, arg:any = null) {
        for (var player of this.getClients()) {
            if (player !== socket) {
                this.io.to(player).emit(eventName, arg);
            }
        }
    }

    public joinRoom(playerid:string, nr:number) {
        this.players[playerid].team = nr;
        this.players[playerid].ready = false;
        this.broadcast(null, 'teamUpdate',
            new PlayerData(playerid, this.players[playerid].name,
                this.players[playerid].team, false));
        this.updateReadyPlayers();
        console.log("[INFO] Client:", playerid, "joined team:", this.players[playerid].team);
    }

    public generateName():string {
        var rand = Math.floor((Math.random() * this.names.length));
        if (this.names.length > 0) {
            var  randName = this.names.splice(rand, 1)[0];
            console.log("[DEBUG] Available names in room:", this.names.length);
            return randName;
        }
        else {
            return "Name";
        }
    }

    public updateReadyPlayers() {
        this.readyPlayers = 0;
        for (var player in this.players) {
            if (this.players[player].ready) {
                this.readyPlayers++;
            }
        }
        console.log("[DEBUG] Updated ready players:", this.readyPlayers, "in room:", this.id);
        this.broadcast(null, 'readyPlayers', this.readyPlayers);
    }

    public resetReadyPlayers() {
        for (var player in this.players) {
            this.players[player].ready = false;
        }
        this.readyPlayers = 0;
    }
}